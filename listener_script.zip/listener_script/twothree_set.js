var twothree_set = [
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "cool",
    "row": 5076,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 1088980
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "dark, gloomy",
    "row": 5077,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 1106424
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "muted, colourless, cold",
    "row": 5078,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 1176485
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurred, warm",
    "row": 5079,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 1193343
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "strong colour, high contrast, psychedelic, dark",
    "row": 5080,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 1228701
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "bright colour, cool",
    "row": 5081,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 1249946
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "warm, muted",
    "row": 5082,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 1267833
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "lighter, warm, suntanned, vintage",
    "row": 5043,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 2563760
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "warm, earthy, sunset, fiery, rich",
    "row": 5044,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 2721694
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "fine, sharp, light, contrasting, colorful, daytime",
    "row": 5045,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 2770067
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "comic, smooth, light, muted, stone, pale, geometric, blended",
    "row": 5046,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 2891669
  },
  {
    "target_image": "23Pollock2.jpg",
    "responses": "aquatic, marine, oceanic, lively, messy, active",
    "row": 5047,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 2987522
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "cold, dark, wintery",
    "row": 5048,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23the-row.jpg!Large.jpg",
    "time_elapsed": 3107441
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "bright, fluorescent, sunny",
    "row": 5049,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 3171716
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "calming, renewing, nature, lush, leafy",
    "row": 5010,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 2387904
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "dark, gloomy, deep, somber, dull",
    "row": 5011,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 2433445
  },
  {
    "target_image": "23the-pink-candle-1910.jpg!Large.jpg",
    "responses": "Pastel, cool, soft, blurry, muted",
    "row": 5012,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 2476985
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "colored, cool, warm, inky, tinted, hued, dappled",
    "row": 5013,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 2520636
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "cold, inky, sombre, sooty, dappled",
    "row": 5014,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 2584526
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "flaming, fiery, grainy, blotchy",
    "row": 5015,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 2631663
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "sepia, drab, rustic",
    "row": 5016,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 2662572
  },
  {
    "target_image": "23mary-magdalene.jpg!Large.jpg",
    "responses": "warm, blurred, lonely",
    "row": 4977,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 599790
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "cold, snowy, bloody",
    "row": 4978,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 610344
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "glassy, chromatic, stripes",
    "row": 4979,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 632885
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "dark, wintery, vast",
    "row": 4980,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "23Kline1.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 665496
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "blurry, snowy, mazy",
    "row": 4981,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 699555
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "watery, primary, bold",
    "row": 4982,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 742516
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "rainbow, frosty, colorful",
    "row": 4983,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 769800
  },
  {
    "target_image": "23Pollock2.jpg",
    "responses": "chaotic, dark, consistent",
    "row": 4944,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 1976333
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "dark, crinkled, unfocused",
    "row": 4945,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 2113661
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "chaotic, vibrant, undefined",
    "row": 4946,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 2224322
  },
  {
    "target_image": "23madonna-casini.jpg",
    "responses": "old-timey, photographic, autumn, natural",
    "row": 4947,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 2292054
  },
  {
    "target_image": "23mary-magdalene.jpg!Large.jpg",
    "responses": "dark, crinkled, wavy, focused",
    "row": 4948,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 2360377
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "clear, pastel, bright, sharp, defined",
    "row": 4949,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 2384571
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "clear, bright, pastel, defined",
    "row": 4950,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23Rothko2.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 2453879
  },
  {
    "target_image": "23still-life.jpg",
    "responses": "mystic, warmth, sunset",
    "row": 4911,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23Rothko2.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 1881334
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "absence of warmth, cold winter,",
    "row": 4912,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 1930994
  },
  {
    "target_image": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "smeared, arura lights",
    "row": 4913,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "23Picasso.jpg",
    "distractorTwo": "23Kline2.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 1965860
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "cold, absence of light, gloomy",
    "row": 4914,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 2005779
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "flakey, choppy, flicky, earthy",
    "row": 4915,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 2057212
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "warm, centered energy, speckle",
    "row": 4916,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 2099384
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "definitively blurry, sharp, bold",
    "row": 4917,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 2143660
  },
  {
    "target_image": "23Pollock2.jpg",
    "responses": "indistinct, abstract, oceanic, splashy",
    "row": 4878,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 1587856
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "dark, drab, overcast",
    "row": 4879,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 1707985
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "bright, neon, abstract, indefinable, blobby",
    "row": 4880,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 1750207
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "soft, pastels, minimal, shapes, blurry, highlights",
    "row": 4881,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 1849044
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "batik texture, dark, dusk, mottled, smeared, layered, feathery, snowy",
    "row": 4882,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 1974331
  },
  {
    "target_image": "23still-life.jpg",
    "responses": "dark, jewel tone, kaleidoscopic",
    "row": 4883,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "23Cezanne.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 2045533
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "streaky, highlighted, blurry, outlined",
    "row": 4884,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 2100283
  },
  {
    "target_image": "23Pollock2.jpg",
    "responses": "polar",
    "row": 4845,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1628678
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "pencil, sketch",
    "row": 4846,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 1669787
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "stained glass, modern",
    "row": 4847,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1734530
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "vintage, polaroid, dusk",
    "row": 4848,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 1774215
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "tipsy, unsteady",
    "row": 4849,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 1921447
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "eerie, dark",
    "row": 4850,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-daughter-1912.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 2005049
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "mysterious, confused",
    "row": 4851,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 2041349
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "Sketchy, blizzard, wet, cold,",
    "row": 4812,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23Cezanne.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 1671674
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "Sharp, lined, focused",
    "row": 4813,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 1742026
  },
  {
    "target_image": "23Klee2.jpg",
    "responses": "Opposite, light, warm, sunlight,",
    "row": 4814,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 1789373
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "Night light, warm, blended, snowy, calm",
    "row": 4815,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "23JeanDupas.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 1831149
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "Urgency, lonely, travelled, memory, enclosed",
    "row": 4816,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 1892932
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Flickered, bright, harsh, windy",
    "row": 4817,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 1930114
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "Sketchy, block like, retro, squared,",
    "row": 4818,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 1996833
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "wintery pattern,snowy,",
    "row": 4779,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "23Kline1.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1498124
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "evening walk,sunburst,",
    "row": 4780,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23Pollock2.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 1627556
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "jagged outline,circular",
    "row": 4781,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 1686824
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "seasonal lighting, colourful,swirly clouds",
    "row": 4782,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 1803471
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "wintery,lonely,sharp,focused",
    "row": 4783,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1898753
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "pixels, blotchy",
    "row": 4784,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23portrait-of-daughter-1912.jpg",
    "distractorThree": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 1936262
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "evening light, isolated,sharp colours,",
    "row": 4785,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23pissaro.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 2021916
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "warm, drawn, almost even-toned",
    "row": 4746,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 1443942
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "pastel, outlined, light",
    "row": 4747,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 1469526
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "warm, subdued, blended, snowy, light",
    "row": 4748,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23the-row.jpg!Large.jpg",
    "time_elapsed": 1561519
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "colorful, abstract, horizontally flowing, chalky, moderately light, bright",
    "row": 4749,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 1620276
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "darkened but colorful, slightly wrinkled",
    "row": 4750,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 1708115
  },
  {
    "target_image": "23Pollock2.jpg",
    "responses": "half cool, half warm, contrasting, very abstract, slightly wavy, vibrant, tri-toned",
    "row": 4751,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "23grablegung.jpg",
    "distractorTwo": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 1827674
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "nearly monochromatic, contrasting, soft glows, dreary",
    "row": 4752,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 1896486
  },
  {
    "target_image": "23portrait-of-daughter-1912.jpg",
    "responses": "cityscape, downtown shopping, busy urban, bus stop,",
    "row": 4713,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 1488063
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "blurred, camouflaged, waiting, cityscape, urban,",
    "row": 4714,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 1551891
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "urban, fantasy, confused, camouflaged, cityscape,",
    "row": 4715,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "23grablegung.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 1607164
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "Yuletide, green, verdant, Christmas, personal security, senset,",
    "row": 4716,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 1677128
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "cityscape, snowscape, urbanscape, downtown snow, winterscape,",
    "row": 4717,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "23Richter.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 1750832
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "unfocused, ground floral, urban setting,",
    "row": 4718,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23Cezanne.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 1816315
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "sharper focus, awaiting, urban loneliness, downtown, signage,",
    "row": 4719,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 1885330
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "pastel, foggy, soft, gentle, muted, delicate",
    "row": 4680,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23Rothko2.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 1412836
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "clear, warm, sharp, atmospheric, painting-like, sepia, faded",
    "row": 4681,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 1534966
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "bold, wrinkled, crumpled, windy",
    "row": 4682,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 1579925
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "warm, defined, striking",
    "row": 4683,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 1630106
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "defined, rock-like, cracked, crumbly",
    "row": 4684,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23dd101419.jpg!Large.jpg",
    "time_elapsed": 1689233
  },
  {
    "target_image": "23Klee2.jpg",
    "responses": "warm, blurry, washed-out, bright, light",
    "row": 4685,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 1713016
  },
  {
    "target_image": "23Klimt1.jpg",
    "responses": "grainy, klimt, pixelated, defined, clear",
    "row": 4686,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "23Mucha.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 1779116
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "very detailed, warm, contrast",
    "row": 4647,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 1224440
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "light, quite bright, defined lines",
    "row": 4648,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1276793
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "light, bright, detailed lines, warm",
    "row": 4649,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 1330351
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "cool, light, bright, clearly defined",
    "row": 4650,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 1370534
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "clearly defined, detailed, busy",
    "row": 4651,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 1432215
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "striking, bright,",
    "row": 4652,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 1462516
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "bright, light, warm",
    "row": 4653,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 1501992
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "cold, colourful, vibrant",
    "row": 4614,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1218568
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "sketchy, dim",
    "row": 4615,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 1254952
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "indistinct, hectic, vibrant",
    "row": 4616,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "23Richter.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1278536
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "smooth, sunny, textured",
    "row": 4617,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23Ingleside.jpg",
    "time_elapsed": 1303807
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "dark, textured, eerie",
    "row": 4618,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 1347014
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "light, consistent, grainy",
    "row": 4619,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 1383855
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "textured, dark",
    "row": 4620,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1418600
  },
  {
    "target_image": "23portrait-of-daughter-1912.jpg",
    "responses": "Lisa frank, chameleon, neon, swirled, dark",
    "row": 4581,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 1014705
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "Low res, low fidelity, monochrome, static,",
    "row": 4582,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 1047849
  },
  {
    "target_image": "23the-pink-candle-1910.jpg!Large.jpg",
    "responses": "Warm, blurred, 90s book cover, sepia",
    "row": 4583,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "23Mucha.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 1085641
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "Cloudy, cozy, blurred, overcast, smoothed",
    "row": 4584,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 1160729
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "Dark, sepia, colored pencil, tinged",
    "row": 4585,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "23JeanDupas.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 1251473
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "Dark, scary, chameleon, cold",
    "row": 4586,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 1308408
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "AI, warped, deep fried, corrupted, bright",
    "row": 4587,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 1349408
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "deathly, scary",
    "row": 4548,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 1075660
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "dynamic, strong",
    "row": 4549,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 1102545
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "chaotic, mess",
    "row": 4550,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1117238
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "fainty, blurry",
    "row": 4551,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 1158481
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "warm, lonely",
    "row": 4552,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 1199691
  },
  {
    "target_image": "23portrait-of-daughter-1912.jpg",
    "responses": "messy, colourful",
    "row": 4553,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "23JeanDupas.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1234243
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "burning, heat wave",
    "row": 4554,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 1269345
  },
  {
    "target_image": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "Bright, light,",
    "row": 4515,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 1018317
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "Warm, Abstract",
    "row": 4516,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1045941
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "Light, blurred, pastel",
    "row": 4517,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 1070248
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "lifelike, realistic",
    "row": 4518,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 1095726
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "trippy, patterned",
    "row": 4519,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "23Kline1.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 1173363
  },
  {
    "target_image": "23portrait-of-daughter-1912.jpg",
    "responses": "Colourful, pastel",
    "row": 4520,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1203417
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "Abstract, fiery",
    "row": 4521,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 1228954
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "bright, abstract, blocky,",
    "row": 4482,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 741007
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "abstract, surreal, harsh, blended,",
    "row": 4483,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 802344
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "bright, light, clear, soft, peaceful,",
    "row": 4484,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 839421
  },
  {
    "target_image": "23still-life.jpg",
    "responses": "colourful, blended, darkish, harsh",
    "row": 4485,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 892705
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "colourful, blurry, faded,",
    "row": 4486,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 939539
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "dull, blended, soft, light",
    "row": 4487,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 966149
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "surreal, abstract, colourful, confusing, harsh, overwhelming",
    "row": 4488,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 991247
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "cold. winter, ice",
    "row": 4449,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 733360
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "colourful, manic, detailed cold",
    "row": 4450,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 750665
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "warm neutral colourful",
    "row": 4451,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 761035
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "bright, warm",
    "row": 4452,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "23Remebrandt.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 779677
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dark, warm",
    "row": 4453,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "23Richter2.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 793110
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "neutral, day, warm",
    "row": 4454,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "23Mucha.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 805345
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "hot, splash of colour",
    "row": 4455,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23Kline2.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 820901
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "Warm, peaceful, bright",
    "row": 4416,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 1033731
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "Whimsical, pastel, sunny",
    "row": 4417,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "23Picasso.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 1049623
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "blurry, fuzzy, futuristic",
    "row": 4418,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 1059308
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "underwater, naturish, outerdoorsy",
    "row": 4419,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23Pollock2.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 1080764
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "Warm, chill, relaxing",
    "row": 4420,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23dd101419.jpg!Large.jpg",
    "time_elapsed": 1090271
  },
  {
    "target_image": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "Bright, fun, popping, exciting",
    "row": 4421,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 1104225
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "Dark, moody, gloomy",
    "row": 4422,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 1115217
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "Dreary, Dark, Depressing, Neutral, Timid",
    "row": 4383,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 996913
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "Unusual, bright, happiness",
    "row": 4384,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 1013898
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "Dark, Deep, Scary, Mystique",
    "row": 4385,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 1027959
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "Colorful, Rainbow",
    "row": 4386,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23the-row.jpg!Large.jpg",
    "time_elapsed": 1041859
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "Old Fashioned, Abstract, Dark and Neutral",
    "row": 4387,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 1055495
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "Confusing, unclear, out of focus",
    "row": 4388,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23pissaro.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 1067250
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "Unique, brightness",
    "row": 4389,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1089382
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "Cold, Dull, Beautiful",
    "row": 4350,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 972147
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "Unique, Colourful",
    "row": 4351,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23pissaro.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 985217
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "Weird, Abnormal Colours",
    "row": 4352,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1012073
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "Nice Pallet of Colours, More like a painting",
    "row": 4353,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23Mondrian3.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 1039341
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "Bright, Colourful, Abstract",
    "row": 4354,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 1059524
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "Picturesque, Nice Colours",
    "row": 4355,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 1078800
  },
  {
    "target_image": "23still-life.jpg",
    "responses": "Rainbow Effect, Nice",
    "row": 4356,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "23Mucha.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 1095179
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "muted, blurry, deep",
    "row": 4317,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 818033
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "blurred, clashing, stripes",
    "row": 4318,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 856434
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "grass, dull, leaves",
    "row": 4319,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 890689
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "sandstorm, blurry, muted",
    "row": 4320,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 908729
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "pastel, washed out, patchwork",
    "row": 4321,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 945665
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "vivid, blurred, burning",
    "row": 4322,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 972729
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "dull, cloudy, muted",
    "row": 4323,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23Kline2.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 1002745
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "cool, dank, pale, fading",
    "row": 4284,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 754540
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "warm, bright, blurred, kaleidoscope, city, peeking cold",
    "row": 4285,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 808692
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "etched, strong, parking, sharp.",
    "row": 4286,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 826060
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "gilded, Klimt, blurred, farsighted",
    "row": 4287,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 856956
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "plain, uninspiring, medium, cloudy",
    "row": 4288,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 877219
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "sharp, etched, angular, strong.",
    "row": 4289,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23portrait-of-daughter-1912.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 887803
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "smooth, dawn",
    "row": 4290,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 905140
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "surreal, colourful",
    "row": 4253,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 692143
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "distorted, colourful",
    "row": 4254,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 701055
  },
  {
    "target_image": "23portrait-of-daughter-1912.jpg",
    "responses": "dynamic, colourful",
    "row": 4255,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 749596
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "surreal, pastel",
    "row": 4256,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 840494
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "off colour, shaded",
    "row": 4257,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 853495
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "blurred, abstract, pastel, colourful",
    "row": 4218,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 747897
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "chaos, colourful, sharp, grainy",
    "row": 4219,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 785943
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "dark, gloomy, mysterious, miserable",
    "row": 4220,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23Rodchenko1.jpg",
    "time_elapsed": 798157
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "sharp, abstract, gloomy, light",
    "row": 4221,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 819159
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "sharp, abstract, glowing, tasteful",
    "row": 4222,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 846640
  },
  {
    "target_image": "23Klimt1.jpg",
    "responses": "grainy",
    "row": 4223,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 861638
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "grainy, dark, mysterious",
    "row": 4224,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 878196
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "lines, swirls, high contrast, dark, night time, jagged",
    "row": 4185,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 692689
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dark, sand storm, bush fire, apocalypse, danger, heat",
    "row": 4186,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "23Remebrandt.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 717585
  },
  {
    "target_image": "23Mondrian3.jpg",
    "responses": "cool, sandy, beach, blurred, soft, pastel",
    "row": 4187,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23Rodchenko1.jpg",
    "time_elapsed": 744345
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "roses, flowers, pastel, loving, soft, caressing, mother, wife",
    "row": 4188,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 773274
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "dark, intense, lurid, love, affair, wine, lust.",
    "row": 4189,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 795537
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "bright, aura, blurred, broad brush, washed out, pastel",
    "row": 4190,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "23Mucha.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 823009
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "heat waves, heat, warm, hot, desert, blurrred, broard brush, radiating",
    "row": 4191,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 844377
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "abstract, surrealism, portrait, outdoor, cityscape, wintery, nighttime, evening, commute",
    "row": 4152,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 750792
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "abstract, surrealism, portrait, outdoor, cityscape, wintery, nighttime, evening, commute",
    "row": 4153,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23Pollock2.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 755959
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "abstract, surrealism, portrait, outdoor, cityscape, wintery, nighttime, evening, commute, warm, rustic, tonal,",
    "row": 4154,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 774164
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "abstract, surrealism, portrait, outdoor, cityscape, wintery, nighttime, evening, commute, soft, pastel, warm, deep, tonal",
    "row": 4155,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23kateryna-1951.jpg!Large.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 794587
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "abstract, surrealism, portrait, outdoor, cityscape, wintery, nighttime, evening, commute",
    "row": 4156,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 800346
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "bright, airy, light, sunny, optimistic, abstract, surreal, landscape, distorted, sketch,",
    "row": 4157,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 804626
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "abstract, surrealism, portrait, outdoor, cityscape, wintery, nighttime, evening, commute",
    "row": 4158,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23Rothko2.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 808217
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "snowy, classic",
    "row": 4119,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 700288
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "low contrasted, dark",
    "row": 4120,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "23girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 719990
  },
  {
    "target_image": "23Klimt1.jpg",
    "responses": "scraped, dried out, musty",
    "row": 4121,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 751551
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "smugged",
    "row": 4122,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 769839
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "doubled, blurry",
    "row": 4123,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23Ingleside.jpg",
    "time_elapsed": 791626
  },
  {
    "target_image": "23the-pink-candle-1910.jpg!Large.jpg",
    "responses": "creamy",
    "row": 4124,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 799752
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "chaotic, maddening, firery",
    "row": 4125,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 822950
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "bright, pastle colors, sharp lines, P looks like an R",
    "row": 4086,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "23JeanDupas.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 643281
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "clear, bright, colorful, clear P",
    "row": 4087,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 676823
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "slight color, splashes of color, color on left, quite dark",
    "row": 4088,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 731979
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "abstract, pastle colors, boxey, cracked",
    "row": 4089,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 751815
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "bright, clear P, strong colors, fire, burning colors",
    "row": 4090,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 771287
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "abstract, furry, lighter areas, not very clear P",
    "row": 4091,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23portrait-of-daughter-1912.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 801983
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "dark, abstract, cracked, mutiple colors, boxy",
    "row": 4092,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 824200
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "cool toned, hazy, object is clearly seen",
    "row": 4053,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 648161
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "almost monotone, dreary",
    "row": 4054,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 683963
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "dark filter, hazy, blurry, dark, low brightness",
    "row": 4055,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 702799
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark cool toned,",
    "row": 4056,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23Pollock2.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 723024
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "cooler toned, clear imaging, contrasted",
    "row": 4057,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23Klee1.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 743301
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "cool toned, dark",
    "row": 4058,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "23ManRay.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 755154
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "hazy, warm toned, light, warm filter",
    "row": 4059,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 771965
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "abstract, cool",
    "row": 4020,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 514757
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "monochrome, busy, blocky, abstract",
    "row": 4021,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 569984
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "warm, bright",
    "row": 4022,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 580906
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "muted, minimalist, cool",
    "row": 4023,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 595493
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "wavy, blured",
    "row": 4024,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 606278
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "cool, realistic",
    "row": 4025,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 615221
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "cool, bright",
    "row": 4026,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 627189
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "dark, sad, burnt",
    "row": 3987,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "23Kline1.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 581156
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "neon, dark, sponged, crinkled",
    "row": 3988,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 610238
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "simple, blotchy",
    "row": 3989,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 650808
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dark, wrinkled, toxic, scary",
    "row": 3990,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 682712
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "crunchy. dark, night, glow",
    "row": 3991,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23Klee1.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 703025
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "night, sponged, glowy",
    "row": 3992,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 725295
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "simple, blotchy, nighttime",
    "row": 3993,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23Cezanne.jpg",
    "distractorThree": "23girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 740078
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "broken, crazy, dark, sharp",
    "row": 3954,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 527577
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "soft, crumpled, dim",
    "row": 3955,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 552975
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "unfinished, warm, warped",
    "row": 3956,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 579551
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "warm, bright, blotted, messy",
    "row": 3957,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "23Picasso.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 602579
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "warmth, mild, torn",
    "row": 3958,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 630256
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "chilled, dark, warped, quiet",
    "row": 3959,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 658671
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, blurred, cold",
    "row": 3960,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 680678
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "dark, dull",
    "row": 3921,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 519208
  },
  {
    "target_image": "23mary-magdalene.jpg!Large.jpg",
    "responses": "clear",
    "row": 3922,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "23Remebrandt.jpg",
    "distractorTwo": "23portrait-of-daughter-1912.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 531664
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "geometrical, infused",
    "row": 3923,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 547984
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "cool, clear, bloody",
    "row": 3924,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 589730
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "pastal, nature",
    "row": 3925,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 603358
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "infered light,",
    "row": 3926,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23Mondrian3.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 625253
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "clear, warm",
    "row": 3927,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 662816
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "Sharp, descriptive, clear",
    "row": 3888,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 533276
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "Discolored, stained, focused",
    "row": 3889,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 562714
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "Water, shimmering, dark, afternoon",
    "row": 3890,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 580172
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "Snowy, expressive, cold",
    "row": 3891,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 594581
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "Scale, snake-skin, iridescent",
    "row": 3892,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 615434
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "Nostalgic, streetlamps, night-time",
    "row": 3893,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 640205
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "Implied, expressionist, shaped",
    "row": 3894,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 666354
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "sepia,pastel",
    "row": 3855,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 514377
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "edgy,funky",
    "row": 3856,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "23Remebrandt.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23Rodchenko1.jpg",
    "time_elapsed": 530903
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "60s,winter,sunrise",
    "row": 3857,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 555381
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "bright, vibrant, traffic light",
    "row": 3858,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 573840
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "royalty,money",
    "row": 3859,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 590885
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "rainow, vibrant, bright",
    "row": 3860,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 602948
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "dark,shaded,blurry,edgy",
    "row": 3861,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 614059
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "bright, cool, blurred",
    "row": 3822,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "23Picasso.jpg",
    "distractorTwo": "23Mondrian3.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 523235
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "neutral, monotone, messy, varied",
    "row": 3823,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 540132
  },
  {
    "target_image": "23ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "warm, overlay, layered, soft",
    "row": 3824,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 552914
  },
  {
    "target_image": "23Pollock2.jpg",
    "responses": "cool, abstract, bright, layered",
    "row": 3825,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23Ingleside.jpg",
    "time_elapsed": 566357
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "detailed, layered, playful, varied colorful",
    "row": 3826,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23portrait-of-daughter-1912.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 583107
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dull, cool-toned, simple",
    "row": 3827,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 591545
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "cubic, neutral, moving",
    "row": 3828,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 600039
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "saturated, dim, blurry",
    "row": 3789,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "23Remebrandt.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 418499
  },
  {
    "target_image": "23the-pink-candle-1910.jpg!Large.jpg",
    "responses": "soft, dark, colorful",
    "row": 3790,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 430737
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "bright, sharp",
    "row": 3791,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 484723
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "dark, sharp, melancholy",
    "row": 3792,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 510855
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "dark, monochrome, sharp",
    "row": 3793,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 521653
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, dim, colorful",
    "row": 3794,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 534155
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "bright, sharp, colorful",
    "row": 3795,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 547362
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "clear, cool",
    "row": 3756,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 445354
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "warm clear",
    "row": 3757,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 454498
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "hazy, vintage",
    "row": 3758,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "23Mucha.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 469530
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "bold, dark, abstract",
    "row": 3759,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23Ingleside.jpg",
    "time_elapsed": 480972
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dark, cook",
    "row": 3760,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 491430
  },
  {
    "target_image": "23ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "firey, warm",
    "row": 3761,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 502557
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "autumnal, warm, bright.",
    "row": 3762,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 522731
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "distorted, harsh",
    "row": 3723,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 403777
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "stylized, blurry",
    "row": 3724,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 417941
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "colorful. blurry",
    "row": 3725,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 432156
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "pixelated, dark",
    "row": 3726,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 469233
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "muted, blurry",
    "row": 3727,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 479469
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "soft, muted",
    "row": 3728,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "23Picasso.jpg",
    "distractorTwo": "23Pollock2.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 489173
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "distorted, stylized",
    "row": 3729,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 500063
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "abstract, blocky",
    "row": 3690,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 202419
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "cool, wintery",
    "row": 3691,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 206901
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "abstract",
    "row": 3692,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 212901
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "textured, fuzzy",
    "row": 3693,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 218939
  },
  {
    "target_image": "23Chirico.jpg",
    "responses": "wavy, ridged",
    "row": 3694,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 222723
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "fuzzy, blurred",
    "row": 3695,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 231987
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "cool, wintery",
    "row": 3696,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 240795
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "orange, green",
    "row": 3657,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 449987
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "gray, purple",
    "row": 3658,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 457287
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "light, blue",
    "row": 3659,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 462329
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "orange, red",
    "row": 3660,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 467370
  },
  {
    "target_image": "23Chirico.jpg",
    "responses": "tinted, red",
    "row": 3661,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 473825
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "realistic",
    "row": 3662,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 480433
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "saturated, bright",
    "row": 3663,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 485858
  },
  {
    "target_image": "23still-life.jpg",
    "responses": "realistic, warm, colourful",
    "row": 3624,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 381395
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "clear, warm, bright",
    "row": 3625,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 400509
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "abstract, unintelligible, confusing, colourful",
    "row": 3626,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "23Kline1.jpg",
    "distractorTwo": "23Rothko2.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 421678
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurred, warm, dreamy",
    "row": 3627,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 437295
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "clear, bright, warm",
    "row": 3628,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "23Richter.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 445919
  },
  {
    "target_image": "23ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "monotonous, fiery, angry",
    "row": 3629,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 463530
  },
  {
    "target_image": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "warm, bright, sunny",
    "row": 3630,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23kateryna-1951.jpg!Large.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 469479
  },
  {
    "target_image": "23the-pink-candle-1910.jpg!Large.jpg",
    "responses": "neo-impressionist",
    "row": 3591,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 438930
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "neo-impressionist",
    "row": 3592,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 448082
  },
  {
    "target_image": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "abstract, neo-impressionist",
    "row": 3593,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 459145
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "expressionist, neo-impressionist, watercolor",
    "row": 3594,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 501341
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "neo-impressionist",
    "row": 3595,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 511681
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "neo-impressionist",
    "row": 3596,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 520572
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "neo-impressionist, pastel",
    "row": 3597,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 534038
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "warm, saturated, snowy",
    "row": 3558,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "23Rodchenko1.jpg",
    "time_elapsed": 437832
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "dark, nighttime, cool",
    "row": 3559,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23pissaro.jpg",
    "distractorThree": "23the-row.jpg!Large.jpg",
    "time_elapsed": 445539
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "stylized, desaturated, bright, outline",
    "row": 3560,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "23grablegung.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 463834
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "toxic, dark, night",
    "row": 3561,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23Rothko2.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 480973
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "midtone, painterly, brushstroke",
    "row": 3562,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 501805
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "desaturated, papery, illustrative",
    "row": 3563,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 515080
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "stylized, abstract, bright, colorful",
    "row": 3564,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 526900
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "Paper",
    "row": 3525,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23portrait-of-daughter-1912.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 352717
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "Pencil",
    "row": 3526,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23Rodchenko1.jpg",
    "time_elapsed": 364111
  },
  {
    "target_image": "23Pollock2.jpg",
    "responses": "Distorted, cold",
    "row": 3527,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23kateryna-1951.jpg!Large.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 377835
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "Sketched",
    "row": 3528,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 385234
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "Sketched",
    "row": 3529,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 399748
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "Distorted",
    "row": 3530,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "23ManRay.jpg",
    "distractorTwo": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 410856
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "Blurry",
    "row": 3531,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 416692
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "hazy, foggy, smoky",
    "row": 3492,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 328451
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "dusty, grimey, dirty",
    "row": 3493,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 348987
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "rigid, boxlike, etched",
    "row": 3494,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 360705
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "abstract, minimalistic, dreary",
    "row": 3495,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 370365
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "bold, smeared",
    "row": 3496,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 382855
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "pastel, drawn, smooth",
    "row": 3497,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 397242
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, nightlike, faded",
    "row": 3498,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 404617
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "warm",
    "row": 3459,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 186640
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "multicoloured",
    "row": 3460,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 192418
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "polaroid",
    "row": 3461,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 197313
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "unclear",
    "row": 3462,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23porch-ii-1947.jpg",
    "time_elapsed": 202760
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "dark",
    "row": 3463,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23portrait-of-daughter-1912.jpg",
    "distractorThree": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 209476
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "look like its from thr 1960's",
    "row": 3464,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 234361
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "kalaediscope",
    "row": 3465,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 241922
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "abstract art style, slight blurry,",
    "row": 3426,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 2224304
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "darkened contrast, distorted shapes, harsh lines",
    "row": 3427,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 2241458
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "darkened contrast, shapes,grey",
    "row": 3428,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 2296146
  },
  {
    "target_image": "23still-life.jpg",
    "responses": "abstract art style, slight blurry, animated",
    "row": 3429,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23Richter2.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 2365157
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "darkened contrast, harsh lines, unrealist",
    "row": 3430,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "23JeanDupas.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 2438917
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "darkened contrast, distorted shapes, harsh lines",
    "row": 3431,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 2463160
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "abstract art style, slight blurry, animated",
    "row": 3432,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 2481958
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "crystaline",
    "row": 3393,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 674168
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "shapey",
    "row": 3394,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 682594
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurred",
    "row": 3395,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 696749
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "grainy",
    "row": 3396,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 703857
  },
  {
    "target_image": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "light",
    "row": 3397,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 710217
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "freezy",
    "row": 3398,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 720692
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "hazy",
    "row": 3399,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23Mondrian3.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 726690
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "Drawn, Faded, cold",
    "row": 3360,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 1941497
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "overexposed, low contrast, faint",
    "row": 3361,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1983641
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "Blocky, hot bag",
    "row": 3362,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 2035648
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "hot, hat, bad, painting",
    "row": 3363,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 2076566
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "hot scarf, hazy, windy",
    "row": 3364,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 2146715
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "cold scarf, Night,",
    "row": 3365,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 2210474
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "pixelated, warmish colours,",
    "row": 3366,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 2258249
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "cold, wintery, harsh, impressionistic, hazy",
    "row": 3327,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 2008672
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "dark, menacing, glowing",
    "row": 3328,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 2045720
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "otherworldly, surreal, glowing, windy, cold, colourful, snowy",
    "row": 3329,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 2080642
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "abstract, colourful, popart, surreal, bright",
    "row": 3331,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 2125354
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "snowy, cold, freezing, icy, wintery, windy",
    "row": 3332,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 2163903
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "rainbow, colourful, klimt, abstract, swirling",
    "row": 3333,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 2216064
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "frosty, cold, icy, azure",
    "row": 3294,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "23grablegung.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 1722427
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "musty, aged, foggy, muted, glow, dim",
    "row": 3295,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 1776281
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "bright, vivid, sunny, warm,",
    "row": 3296,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 1809486
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "blurred, vivid, rainbow, shades",
    "row": 3297,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 1859670
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "glow, night, dark, mystic, mysterious, warm",
    "row": 3298,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1896875
  },
  {
    "target_image": "23the-pink-candle-1910.jpg!Large.jpg",
    "responses": "hazey, summer, warm,",
    "row": 3299,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 1955625
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "cold, vivid, bold, wavy, sea",
    "row": 3300,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 2022296
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "cool",
    "row": 3261,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 1858452
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "warm",
    "row": 3262,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 1863068
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "abstract",
    "row": 3263,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 1874516
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "warm",
    "row": 3264,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 1879116
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "cool",
    "row": 3265,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 1882596
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "cool",
    "row": 3266,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 1886688
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "abstract",
    "row": 3267,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23Pollock2.jpg",
    "distractorThree": "23girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 1892526
  },
  {
    "target_image": "23Klimt1.jpg",
    "responses": "grainy, fuzzy, hazy",
    "row": 3228,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 1566244
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "stripes, dark lines, vein like, stretch marks",
    "row": 3229,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1630503
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "rocky, bright, warm",
    "row": 3230,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 1716468
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "binary, boxed,",
    "row": 3231,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 1747226
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "deep, distinct",
    "row": 3232,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 1767917
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "fuzzy, haze",
    "row": 3233,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 1789502
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "simple, hazy",
    "row": 3234,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "23Kline1.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 1836903
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "dark, sinister, cinematic, warm, high contrast",
    "row": 3195,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23Mondrian3.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 1524087
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "Stylized, shapes,dark edges,vibrant, sharp, Cubism",
    "row": 3196,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1595688
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "Highlight edges, sharp, high contrast",
    "row": 3197,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 1638429
  },
  {
    "target_image": "23Klimt1.jpg",
    "responses": "warm, sepia, tinted",
    "row": 3198,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 1670713
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "Cubisim, 2D outline, warm, sharp, cartoony",
    "row": 3199,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 1702316
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "warm,sepia,filtered,vibrant",
    "row": 3200,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 1727191
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "dark, cool, sharp, stretched edge strokes",
    "row": 3201,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "23Rothko2.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 1791383
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "blurred, indistinct dreamy, wistful",
    "row": 3162,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 1351274
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "hat, dark, defined, pack",
    "row": 3163,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1434923
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "P. defined, female hat, tree,",
    "row": 3164,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "23Remebrandt.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 1514079
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "fuzzy, pale, indistinct, faded",
    "row": 3165,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 1573080
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "sharp, defined, clearer, involved",
    "row": 3166,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 1597240
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "busy, colourful, muddled, defined",
    "row": 3167,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 1653894
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "confused, jumbled, colourless, undefined",
    "row": 3168,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 1693358
  },
  {
    "target_image": "23Klee2.jpg",
    "responses": "blurry, raw, pastel",
    "row": 3129,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 1058026
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "cold, christmas card, dark",
    "row": 3130,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1087550
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "crayon, depressed",
    "row": 3131,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 1118608
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "dark, depressed, sad.",
    "row": 3132,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23Ingleside.jpg",
    "time_elapsed": 1139464
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "colorful, pastel, palette",
    "row": 3133,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1173288
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dark, communist, revolutionary",
    "row": 3134,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 1225070
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "light, modern,",
    "row": 3135,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 1248574
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "Cartoon ish, scrapbook, the image looks as if it has been made up of paper cut out and placed together",
    "row": 3096,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "23girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 997177
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "Blurred photo lines, the colours have all changed and it looks as if the photo has been developed early as it is missing the cooler shades",
    "row": 3097,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 1037901
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "There is hardly any light in the photo, it has been developed so that the photo has very few bright itms in it, all the colour seems to merge into one",
    "row": 3098,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1079998
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "A mixture of colours shown, style looks to be done using pastels",
    "row": 3099,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 1109137
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "This looks like a sun faded photo, all the features are there apart from the fact it looks washed out",
    "row": 3100,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 1131429
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "More new age, modernist, colours are contrasting and are found in different places on the pictre to provide contrast and make you look at the picture",
    "row": 3101,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23Richter2.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 1167476
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "Contrasing colours again, sharp images",
    "row": 3102,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 1182724
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "warm, semi blurry",
    "row": 3063,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 546301
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "animated, warm, shadows",
    "row": 3064,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 562663
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "animated, graphic, warm, shadows",
    "row": 3065,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23Rodchenko1.jpg",
    "time_elapsed": 580188
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "cold, light, semi blurry",
    "row": 3066,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 594834
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "semi clear, light",
    "row": 3067,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 613199
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "graphic, animated, cold, dark",
    "row": 3068,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 627620
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "graphic, colourful, animated",
    "row": 3069,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 643242
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "saturated, messy",
    "row": 3030,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 916547
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "abstract, cubic, bright,",
    "row": 3031,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23pissaro.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 940292
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "sketchy, bright, harsh",
    "row": 3032,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23Ingleside.jpg",
    "time_elapsed": 984044
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "blurry, hazy, cool",
    "row": 3033,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 1006780
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "dark, eerie",
    "row": 3034,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 1029875
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "warm, dim",
    "row": 3035,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23Mondrian3.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 1079818
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "summery, mellow",
    "row": 3036,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 1133242
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "dark, blurry, bloody, disturbing, mono-chrome, mono-tone",
    "row": 2997,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 912797
  },
  {
    "target_image": "23Chirico.jpg",
    "responses": "explicit, singular, mono-tone, mono-chrome, sand-like, multigrain",
    "row": 2998,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 944421
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "bright, explicit, warm, happy, liveable",
    "row": 2999,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 980182
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "blurry, mono-chrome, mono-tone, singular, vivid",
    "row": 3000,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 1015401
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "bright, mono-tone, mono-chrome, summer-like, warm",
    "row": 3001,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23Kline2.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 1036482
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "dark, winter-like, depressing, disturbing, gloomy",
    "row": 3002,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "23Cezanne.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 1071900
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "multi-grain, multi-coloured, dark, unnatural, explicit",
    "row": 3003,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 1105053
  },
  {
    "target_image": "23Mondrian3.jpg",
    "responses": "snow, light, plain",
    "row": 2964,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 891387
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "jigsaw like, bright",
    "row": 2965,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 914462
  },
  {
    "target_image": "23still-life.jpg",
    "responses": "dark, chunky",
    "row": 2966,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 942178
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "flowerlike, plain colour",
    "row": 2967,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 971455
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "bright,",
    "row": 2968,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 996035
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "rustic, mellow",
    "row": 2969,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1021331
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "bright, in focus",
    "row": 2970,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 1068792
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "washed, lacking colour",
    "row": 2931,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23Pollock2.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 675137
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "subtle bright colour, sketch",
    "row": 2932,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 717722
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "bright, abstract",
    "row": 2933,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "23Remebrandt.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 734030
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "abstract, mono,",
    "row": 2934,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 789797
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "dark, windy, blustery",
    "row": 2935,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 811857
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "pastel shades",
    "row": 2936,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23Mondrian3.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 822893
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "burnt tones, citrus",
    "row": 2937,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23pissaro.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 843215
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "picasso-esque, burnt, breakdown of lines, complex",
    "row": 2898,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 640823
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "snowy, more sepia, sharp but with artistic flair",
    "row": 2899,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23Klee1.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 699813
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "pointed, oversaturated,",
    "row": 2900,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 725953
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "evening, dark, quite clear despite this",
    "row": 2901,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 752569
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "crumpled, colors where they shouldnt be",
    "row": 2902,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23Rodchenko1.jpg",
    "time_elapsed": 821393
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "void of color or shape. Breakdown of lines,",
    "row": 2903,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 859004
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "wavy, distorted, retains its color, morning",
    "row": 2904,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 880763
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "sunstreaked, over exposed,",
    "row": 2865,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 683327
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "evening gloom, realism",
    "row": 2866,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 699104
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "distorted, evening, wavy",
    "row": 2867,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 717120
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "floral, dappled, spongy textured",
    "row": 2868,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 741647
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "grass, brush stroked, vernal",
    "row": 2869,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 754320
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "fire glow, blurred, warm",
    "row": 2870,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-daughter-1912.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 777280
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "spot lit, clear, dappled",
    "row": 2871,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 797088
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "pastel, drawn",
    "row": 2832,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 533152
  },
  {
    "target_image": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "bizarre, wavy",
    "row": 2833,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 539640
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "jagged, blocky",
    "row": 2834,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 556207
  },
  {
    "target_image": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "night, dark,",
    "row": 2835,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 567547
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "autumnal, unique, soft",
    "row": 2836,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 594385
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "soft, pale, dark",
    "row": 2837,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 605973
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "pastel, smeared",
    "row": 2838,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23dd101419.jpg!Large.jpg",
    "time_elapsed": 628007
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "dusk, blurred, interesting",
    "row": 2799,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 294541
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "cubism, sharp, distorted, mars",
    "row": 2800,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 310242
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "cubed, distorted, sharp, faded",
    "row": 2801,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 326771
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "pastel, faded, light, similar",
    "row": 2802,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 337774
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "colourful, distinctive, mixture, loud",
    "row": 2803,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 348019
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "colourful, mixed, sharp, interesting",
    "row": 2804,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 361538
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "soft, dark, mixed, faded, loud",
    "row": 2805,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23the-row.jpg!Large.jpg",
    "time_elapsed": 377967
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "Wintery, freezing, subzero sunlight, midnight sun, dreamlike",
    "row": 2766,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 5637562
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "Dark, warm, threatening evening, pulsing headache",
    "row": 2767,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "23Picasso.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 5673085
  },
  {
    "target_image": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "Smooth, calm, vibrant, disco, vibin',",
    "row": 2768,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 5733016
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "intense, saturated, twilight, watercolours, fuzzy",
    "row": 2769,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 5822477
  },
  {
    "target_image": "23madonna-casini.jpg",
    "responses": "blurry, dark, shadowy, old-world, cardboard",
    "row": 2770,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 5897723
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "Snowfall, dark, cold, depressed, pessimistic",
    "row": 2771,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 5977016
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "Dreamy, nostalgic, happy, blurry, memory, lovey, butterflies",
    "row": 2772,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 6016882
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "desert",
    "row": 2733,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23Pollock2.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 213491
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "vibes",
    "row": 2734,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 217695
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "pastel",
    "row": 2735,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 223785
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "blurred",
    "row": 2736,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "23Richter.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 227184
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "soft",
    "row": 2737,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 240883
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "realistic",
    "row": 2738,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 251280
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "wavy",
    "row": 2739,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 267502
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "sharp, polaroid, postcard",
    "row": 2700,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 2476979
  },
  {
    "target_image": "23Mondrian3.jpg",
    "responses": "vintage, sepia, filter, comforting",
    "row": 2701,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 2572116
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "birch, abstract, jigsaw, monotone",
    "row": 2702,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 2634991
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "chalk, focused, winter",
    "row": 2703,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23pissaro.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 2699277
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "8mm, old photo, dark, underexposed",
    "row": 2704,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 2835348
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "photo, quiet, eerie, sad",
    "row": 2705,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 2896505
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "clean, oil painting, flames",
    "row": 2706,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 3049699
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "Cool, cold, blurred, smeared, bright",
    "row": 2667,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 1508836
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "simple, thick, impressionistic, smooth, suggestive, flowing",
    "row": 2668,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 1587774
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "dark, blotchy, monochromatic, harsh, dreary",
    "row": 2669,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 1738876
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "Smooth, colorful, mixed, moderate, filled, slightly stylized,",
    "row": 2670,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 1916973
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "dark, shadowed, cold",
    "row": 2671,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 1988004
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "colorful,  bright, cool, blended, splattered",
    "row": 2672,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 2137058
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "tinted, muted, aged, impressionist",
    "row": 2673,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 2253219
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "Hot colours, the shapes identifiable but slightly abstracted, with 3D effects which make the image look a bit like a collage with stuck-on elements",
    "row": 2634,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 1713726
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "Bright sugared-almond style but watery colours as if the pigments had been floated on liquid, elemtns of the picture otherwise close to the original",
    "row": 2635,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 1855680
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "Realistic, fairly sharp, colours dark but saturated with a slight stained-glass effect, and streaked horizontally with dark and light",
    "row": 2636,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 1932042
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "Mostly near-monochrome and broken up with fine dark and light stripes, overlaid with aptches of colour some of which derive from the original photo' and some of which are random",
    "row": 2637,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 2040559
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "Fairly close to original but ovelaid with deep warmish colours, looking as if tinted with coloured inks",
    "row": 2638,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 2129606
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "Similar to original photo', but overexposed and faded and then washed with pastel colours",
    "row": 2639,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 2190739
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "Quite busy and abstracted making the original forms hard to identify, lined as if drawn in with pencil, then coloured with blotches of hot colours not all of which follow the lines",
    "row": 2640,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 2278342
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "brewing, hot, glowing, hidden",
    "row": 2601,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23Rothko2.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 1622665
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "warm, glowing",
    "row": 2602,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 1709134
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "disco, illuminated, beautiful, breath-taking, relaxing",
    "row": 2603,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 1813862
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "hazy, calm, serene",
    "row": 2604,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1864838
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "broody, scary, frightening",
    "row": 2606,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 1920235
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "summer, clear, day, wet",
    "row": 2607,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 1989198
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "dots, multi-colored, dark, fuzzy",
    "row": 2568,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23Ingleside.jpg",
    "time_elapsed": 1569855
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "watercolor, blurred, warm colors, tranquil",
    "row": 2569,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 1599620
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "hazy, blurred, muted, earth tones",
    "row": 2570,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 1634713
  },
  {
    "target_image": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "abstract, bold colors, dark, ashy",
    "row": 2571,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 1705621
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "multi-colored, distinct lines, bold colors",
    "row": 2572,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 1742075
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "hazy, fuzzy, blurred, warm tones, monochromatic",
    "row": 2573,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 1777030
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "multi-colored, blurred, muted, warm and cool tones",
    "row": 2574,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "23Rothko2.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 1840367
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "dark, multicolored, clear, clean, lifelike, warm and pretty in a bright way",
    "row": 2535,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 1444510
  },
  {
    "target_image": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "electronic, Neon",
    "row": 2536,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 1456483
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "ugly, completely unclear, collage, crazy",
    "row": 2537,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 1479066
  },
  {
    "target_image": "23madonna-casini.jpg",
    "responses": "warm, blurry, simple, mysterious, detective Story cover",
    "row": 2538,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 1507355
  },
  {
    "target_image": "23the-pink-candle-1910.jpg!Large.jpg",
    "responses": "children's book cover, basic, clean and clear, appropriate for a college office",
    "row": 2539,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 1541479
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "who turn the lights off, Dreadful",
    "row": 2540,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 1561756
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "grass has clung to everything and everyone, someone took a comb and scraped over half of it",
    "row": 2541,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23Cezanne.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 1588963
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dark, lifelike",
    "row": 2502,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 1275338
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "bright, sharp, colourful",
    "row": 2503,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 1323972
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "dull, colourless, abstract, smudged",
    "row": 2504,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1364611
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "dark, sharp, multicolour",
    "row": 2505,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23Klee1.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1399352
  },
  {
    "target_image": "23portrait-of-daughter-1912.jpg",
    "responses": "bright, colourful",
    "row": 2506,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1431776
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "dark, dull, muted",
    "row": 2507,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 1459674
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "pale, blocky,",
    "row": 2508,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 1502944
  },
  {
    "target_image": "23still-life.jpg",
    "responses": "happy",
    "row": 2469,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 878780
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "icy, rough",
    "row": 2470,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 904628
  },
  {
    "target_image": "23mary-magdalene.jpg!Large.jpg",
    "responses": "chiselled, modern",
    "row": 2471,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "23JeanDupas.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 987315
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "morphed, blended, flowing",
    "row": 2472,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 1035356
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "mysterious",
    "row": 2473,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 1115172
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "winter, misty",
    "row": 2474,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 1147532
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "uncertain, weird",
    "row": 2475,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 1186620
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "painted, cartoon-like, fuzzy, Impressionist",
    "row": 2436,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 869397
  },
  {
    "target_image": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "monochromatic, bright, faded, seeping",
    "row": 2437,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 904885
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "realistic, drab, delineated",
    "row": 2438,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 921029
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "realistic, cool, sepia, drab, monochromatic, blurred",
    "row": 2439,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 951133
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "highlighted, delineated, cartoonish, realistic",
    "row": 2440,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 1000870
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "drab, dull, blurred, realistic, photographic",
    "row": 2441,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "23Mucha.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 1025036
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "bold, cubist, modern, vibrant",
    "row": 2442,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 1043655
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "CLEAR",
    "row": 2403,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 772637
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "BLURRED, SHADOW, COLOUR, BRIGHT, SCARY",
    "row": 2404,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 796177
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "CLEAR, BEAUTIFUL, PRIMARY",
    "row": 2405,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 908593
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "GLOOMY, BLURRED, PIXALATED, PRIMARY",
    "row": 2406,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 927878
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "BRIGHT",
    "row": 2407,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 936973
  },
  {
    "target_image": "23Pollock2.jpg",
    "responses": "COVERED, GLOOMY",
    "row": 2408,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 959404
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "CLEAR, COLOURFUL",
    "row": 2409,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 1026100
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "shaky, vibrant, flat",
    "row": 2370,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 562345
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "shiny, earthy, dark",
    "row": 2371,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 597512
  },
  {
    "target_image": "23ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "warm, hot, hellish",
    "row": 2372,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 617729
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "realistic, amateurish",
    "row": 2373,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 646692
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "messy, washed out, blocky",
    "row": 2374,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 681067
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "vibrant, flowy, blurry",
    "row": 2375,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "23Remebrandt.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 753906
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "pale, washed out, metallic",
    "row": 2376,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 800800
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "winter",
    "row": 2337,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 781382
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "artistic",
    "row": 2338,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 790179
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "pastel",
    "row": 2339,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 799324
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "colorful",
    "row": 2340,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 813444
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "winter",
    "row": 2341,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 826102
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "winter",
    "row": 2342,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 864581
  },
  {
    "target_image": "23Klee2.jpg",
    "responses": "blurry",
    "row": 2343,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 869848
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "old time memories",
    "row": 2304,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 759013
  },
  {
    "target_image": "23Mondrian3.jpg",
    "responses": "rose colored glasses",
    "row": 2305,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 777461
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "distorted",
    "row": 2306,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23Rodchenko1.jpg",
    "time_elapsed": 830289
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "layered",
    "row": 2307,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 864648
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "evergreen",
    "row": 2308,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 877982
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "desert trek",
    "row": 2309,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 895537
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "grainy, blurred",
    "row": 2271,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 683695
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "colorful, holiday, vibrant",
    "row": 2272,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23Rodchenko1.jpg",
    "time_elapsed": 700963
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "fractal, factured,",
    "row": 2273,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 720758
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "vibrant, detailed, colorful,",
    "row": 2274,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 748681
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "muted, drab, sharp",
    "row": 2275,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 782166
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "sickly, muted, dull",
    "row": 2276,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 811043
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "crackled, scaly, bumpy, defined",
    "row": 2277,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 845436
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "Nausea, clear, deep, ominous",
    "row": 2238,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 663760
  },
  {
    "target_image": "23Chirico.jpg",
    "responses": "Rippled, water, deep, forest",
    "row": 2239,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23Richter2.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 704209
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "Chaotic, colourful, surreal, winter",
    "row": 2240,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 755703
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "Splotchy, poison, bruised",
    "row": 2241,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 780306
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "Warm, autumn, strange",
    "row": 2242,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 821249
  },
  {
    "target_image": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "Warm, desert, heatwave, bruised",
    "row": 2243,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 850322
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "Sickly, splotchy",
    "row": 2244,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23Pollock2.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 874575
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "dotty, blurry, dark, dull",
    "row": 2205,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 690854
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "vibrant, colorful, rainbow",
    "row": 2206,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 704756
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "abstract, warm,",
    "row": 2207,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23dd101419.jpg!Large.jpg",
    "time_elapsed": 726497
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "colorful, realistic",
    "row": 2208,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 758991
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "photo-like, realistic, clear, focussed",
    "row": 2209,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 774796
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "dark, focussed, colorful",
    "row": 2210,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 796522
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "dark, moody, blurred, emo",
    "row": 2211,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23Kline2.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 823254
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "warm, clear, light",
    "row": 2172,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 592792
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "hazy, warm, blurred",
    "row": 2173,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "23JeanDupas.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 596686
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "cool, light, clear",
    "row": 2174,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 605543
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "warm, clear, light",
    "row": 2175,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 612285
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "hazy, warm, blurred",
    "row": 2176,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "23Richter.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 616925
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "cool, light, spotty",
    "row": 2177,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 624291
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "abstract, colorful, angled",
    "row": 2178,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "23girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 637047
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "cartoon, pencil, animation",
    "row": 2139,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 582269
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "dark, cold",
    "row": 2140,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 596479
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "grunge, sharp, opaque",
    "row": 2141,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 619197
  },
  {
    "target_image": "23Chirico.jpg",
    "responses": "dark, bold, strong",
    "row": 2142,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 632220
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "rough, shaded, smooth",
    "row": 2143,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "23Kline1.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 650061
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "noise, hard",
    "row": 2144,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23Rothko2.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 662824
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "tame, frank, big",
    "row": 2145,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 675253
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dark, blurry, warm, lines, smooth, colourful, fire",
    "row": 2106,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 569192
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "cool, evening, defined, lines, dream, winter",
    "row": 2107,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 588784
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "smooth, colourful, cool, galaxy, abstract, evening, winter",
    "row": 2108,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 617247
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "winter, warm, abstract, lines, autumn, dream",
    "row": 2109,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "23Richter.jpg",
    "distractorTwo": "23Rothko2.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 635137
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "dream, blocky, abstract, lines, cool, blurry, winter,",
    "row": 2110,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 661976
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "cool, dream, spring, blurry, faded, sepia",
    "row": 2111,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 696169
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "autumn, warm, fire, blurry, dark",
    "row": 2112,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 710397
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "abstract, geometric, bright, pastel",
    "row": 2073,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23Richter2.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 547384
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "dark, cold, cartoonish",
    "row": 2074,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "23girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 562068
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "wintry, photographic, realistic, dated",
    "row": 2075,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 580180
  },
  {
    "target_image": "23Klimt1.jpg",
    "responses": "overexposed, pixilated",
    "row": 2076,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 597775
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "geometric, warm, indistinguishable",
    "row": 2077,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 614042
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "warm, illustrated, hard",
    "row": 2078,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 636876
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "soft, breezy, pointed, focused",
    "row": 2079,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 658493
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "painting, dark, dull",
    "row": 2040,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23Mondrian3.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 553898
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "colourful, bright",
    "row": 2041,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 572000
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "fire, bright, flame, intense",
    "row": 2042,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23kateryna-1951.jpg!Large.jpg",
    "distractorThree": "23dd101419.jpg!Large.jpg",
    "time_elapsed": 580966
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "moody, dark",
    "row": 2043,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 589253
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "abstract, pastel, bright",
    "row": 2044,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 606501
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "crayon, coloured",
    "row": 2045,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "23ManRay.jpg",
    "distractorTwo": "23Richter2.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 619831
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "textured, rainbow, dark",
    "row": 2046,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 632580
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "soft",
    "row": 2007,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 498650
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "vibrant",
    "row": 2008,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 512988
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "soft",
    "row": 2009,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 528952
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "twilight",
    "row": 2010,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 539064
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "moody",
    "row": 2011,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 553037
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "vibrant",
    "row": 2012,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 564356
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "warm",
    "row": 2013,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 585822
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "abstract, fun, blended, unrecognisable",
    "row": 1974,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 463130
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "frosty, dark, moody",
    "row": 1975,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "23ManRay.jpg",
    "distractorTwo": "23Kline2.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 474690
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "frosty, cold, textured",
    "row": 1976,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 485786
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dark, vintage, warm, fiery",
    "row": 1977,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 502745
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "textured, frosty, cold",
    "row": 1978,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 511402
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "cold, monochromatic, blended",
    "row": 1979,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "23grablegung.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23dd101419.jpg!Large.jpg",
    "time_elapsed": 524082
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "textured, dark,",
    "row": 1980,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 534290
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "faded",
    "row": 1941,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "23Remebrandt.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 369262
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "apple slices",
    "row": 1942,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 409686
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "earth co2",
    "row": 1943,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 422606
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "egplant fade",
    "row": 1944,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 456838
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "Chinese",
    "row": 1945,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "23Mondrian3.jpg",
    "distractorThree": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 474797
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "Under water",
    "row": 1946,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 485134
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "Fiesta",
    "row": 1947,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 490965
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "half blurry",
    "row": 1908,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23Cezanne.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 432916
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "lines",
    "row": 1909,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 439225
  },
  {
    "target_image": "23ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "warmer",
    "row": 1910,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 445655
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "liness",
    "row": 1911,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 450520
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "sunny",
    "row": 1912,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 461689
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "lines",
    "row": 1913,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23Klee1.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 467875
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "clear",
    "row": 1914,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 498280
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "evening",
    "row": 1875,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 333246
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "slip",
    "row": 1876,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 340622
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "move",
    "row": 1877,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "23ManRay.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 349294
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "going",
    "row": 1878,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 358978
  },
  {
    "target_image": "23Klimt1.jpg",
    "responses": "looking",
    "row": 1879,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 371398
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "confuse",
    "row": 1880,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 383805
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "gas",
    "row": 1881,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 388613
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "bizzare, warm, crowded",
    "row": 1842,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 379320
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "snow, cool, shadow",
    "row": 1843,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 392150
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "cool, fuzzy, bright",
    "row": 1844,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 407367
  },
  {
    "target_image": "23ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "warm, fuzzy, monotone",
    "row": 1845,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 424089
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "warm, cool, blurred",
    "row": 1846,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 434751
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "cool, bright, shadow",
    "row": 1847,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 445641
  },
  {
    "target_image": "23mary-magdalene.jpg!Large.jpg",
    "responses": "cool, warm, shadow, blurred, edge",
    "row": 1848,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 462311
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dark, angry,",
    "row": 1809,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 297450
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "bright,",
    "row": 1810,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23kateryna-1951.jpg!Large.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 308684
  },
  {
    "target_image": "23Klee2.jpg",
    "responses": "bright,hazy",
    "row": 1811,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23porch-ii-1947.jpg",
    "time_elapsed": 316365
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "abstract,bright,",
    "row": 1812,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 325498
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "blurry, dull,",
    "row": 1813,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "23Mucha.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 333542
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "abstract,bright,",
    "row": 1814,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "23Remebrandt.jpg",
    "distractorTwo": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 337878
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "blurry, hazy,",
    "row": 1815,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 347892
  },
  {
    "target_image": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "vibrant",
    "row": 1776,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 224704
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "contrast",
    "row": 1777,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 235998
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "pastel",
    "row": 1778,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 242001
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "grainy",
    "row": 1779,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 247278
  },
  {
    "target_image": "23madonna-casini.jpg",
    "responses": "potato",
    "row": 1780,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 253602
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "fractured",
    "row": 1781,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 263988
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "basic",
    "row": 1782,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23Richter2.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 270005
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "wistful, dream-like, retro, nostalgic, washed out, soft",
    "row": 1743,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "23kateryna-1951.jpg!Large.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 5864916
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "cubist, harsh, concrete jungle, monochrome",
    "row": 1744,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 5881618
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "vibrant, soft, careful",
    "row": 1745,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 5896487
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "harsh, textured, tough, rough",
    "row": 1746,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23Cezanne.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 5911729
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "explosive, energetic, vibrant",
    "row": 1747,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 5920359
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "tight, claustrophobic, harsh",
    "row": 1748,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 5936843
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dream-like, pessimistic, forboding, dark",
    "row": 1749,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 5956913
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "colourful, blurred, distorted",
    "row": 1710,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23Kline2.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 1123420
  },
  {
    "target_image": "23madonna-casini.jpg",
    "responses": "dull, blurred,",
    "row": 1711,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 1176404
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "distorted, blurred, abstract",
    "row": 1712,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 1201091
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "distorted, blurred, weird, soft, dull",
    "row": 1713,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 1255093
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "blurred, distorted, dark",
    "row": 1714,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 1270061
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "weird, unfocused,",
    "row": 1715,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 1305316
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "abstract, colourful,",
    "row": 1716,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1323276
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "busy, hectic, bold, angry, fast, overcrowded, shrinking, full",
    "row": 1677,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 1033463
  },
  {
    "target_image": "23Pollock2.jpg",
    "responses": "water, bold, strong, block, fish, underwater, swim",
    "row": 1678,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 1174156
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "bold, strong, focused, busy, movement",
    "row": 1679,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 1214629
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "soft, smooth, blurred, calm, cold, winter, snow,",
    "row": 1680,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 1259406
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "crumpled, old, deep, bold, strong, dark, winter, snow, cold,",
    "row": 1681,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23Richter2.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1346963
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "blurred,fuzzy, warm, light, bright, sun, scratched, exposed",
    "row": 1682,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1433937
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "dark, forest, grass, lost, bold, fuzzy, trees, swamp,",
    "row": 1683,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 1535707
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "flashes, washed out, chalk",
    "row": 1644,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1203028
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "washed our, warm, grassy tones",
    "row": 1645,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 1303536
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "metallic, bright,",
    "row": 1646,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 1321789
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "firey spots, veiny lines , pastels otherwise cold",
    "row": 1647,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 1369552
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "clearly defined shapes with outlines, rainbow, pastel",
    "row": 1648,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 1398383
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "cold but very colourful, cold chalky",
    "row": 1649,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 1443123
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "monotone, colourless",
    "row": 1650,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 1462917
  },
  {
    "target_image": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "blurry, flowing, light, colourful",
    "row": 1611,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 475452
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "bright, colourful, plain",
    "row": 1612,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 498444
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "pastel, bright, few colours",
    "row": 1613,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 522267
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "colourful, detailed, bright",
    "row": 1614,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 548183
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "faded, dull",
    "row": 1615,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23pissaro.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 563405
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "soft, pastel. misty",
    "row": 1616,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 577401
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "dark, colourful, soft",
    "row": 1617,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 603095
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "blurred, deep bright colours",
    "row": 1578,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 774002
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "blurred, pencil strokes, neon",
    "row": 1579,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 789566
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurred, warm colours, dusky",
    "row": 1580,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 801610
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "warm colours, limited colours, warm glow",
    "row": 1581,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 815185
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "dark, bold, bright but muted colour",
    "row": 1582,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 840290
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "dark, limited colour pallet",
    "row": 1583,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 859096
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "variety of colours, bright, blurred, mashed",
    "row": 1584,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 872871
  },
  {
    "target_image": "23madonna-casini.jpg",
    "responses": "sunset, morning",
    "row": 1545,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 3654428
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "creamy, clear",
    "row": 1546,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23les-musiciens-1952.jpg",
    "time_elapsed": 3672326
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "harsh, rough",
    "row": 1547,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 3682905
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "dark, evening",
    "row": 1548,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 3728980
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "icy, flakey",
    "row": 1549,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 3785113
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "warm, dark",
    "row": 1550,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 3793740
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "sandy, dessert",
    "row": 1551,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 3809477
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "inverted, unique",
    "row": 1512,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 1853618
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "lined, thick, snowy-looking,",
    "row": 1513,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 1914185
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "warm, bold",
    "row": 1514,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1927764
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "mosaic, rainbowed",
    "row": 1515,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 1962675
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "lost, hilly, warm coloured",
    "row": 1516,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 2030441
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "ferocious, dark, maddening",
    "row": 1517,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "23Kline1.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 2122373
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "heated, baked, dark contrast",
    "row": 1518,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 2149346
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "warm, un-patterned",
    "row": 1479,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 2703705
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "neutral, not special, simple",
    "row": 1480,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 3041263
  },
  {
    "target_image": "23mary-magdalene.jpg!Large.jpg",
    "responses": "dark, creased",
    "row": 1481,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "23girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 3127992
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "fiery, creased, warm",
    "row": 1482,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "23ManRay.jpg",
    "distractorTwo": "23kateryna-1951.jpg!Large.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 3187511
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, chill, creased,",
    "row": 1483,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 3288742
  },
  {
    "target_image": "23Mondrian3.jpg",
    "responses": "light, simple, ordinary",
    "row": 1484,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 3308412
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "very dark, ordinary",
    "row": 1485,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 3331400
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "vivid, spring pallet, warming",
    "row": 1446,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "23JeanDupas.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 1448442
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "cool, contrasting, wintery",
    "row": 1447,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 1467371
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "contrasting, pastel, rectangular",
    "row": 1448,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 1635669
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "dark, wintery, sketchy",
    "row": 1449,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "23Kline1.jpg",
    "distractorTwo": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 1685905
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "warm, pastel, clear",
    "row": 1450,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 1718596
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "abstract, colourful, contrasting",
    "row": 1451,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 1730813
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "wintery, cool, sketchy",
    "row": 1452,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 1747798
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "unrealistic, detailed, faint, precise,",
    "row": 1413,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 1699150
  },
  {
    "target_image": "23madonna-casini.jpg",
    "responses": "blurred, muted, bleak, smudged",
    "row": 1414,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 1785594
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "faded, faint, pastel, muted",
    "row": 1415,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 1851930
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "abstract, dark but vibrant, bright, brushstrokes, layers,",
    "row": 1416,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 1910594
  },
  {
    "target_image": "23mary-magdalene.jpg!Large.jpg",
    "responses": "abstract, reflections, multi tonal, shadowy, dark, creepy",
    "row": 1417,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 1936021
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "brush strokes, natural, light and dark,",
    "row": 1418,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23dd101419.jpg!Large.jpg",
    "time_elapsed": 1982180
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "blurred, distorted, bleak, concrete, skewed,",
    "row": 1419,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 2012558
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "smooth, jungle",
    "row": 1380,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 1984563
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "wood, chocolate",
    "row": 1381,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 2001655
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "crazy, unclear",
    "row": 1382,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 2013461
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "clear,",
    "row": 1383,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23Rothko2.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 2022261
  },
  {
    "target_image": "23Mondrian3.jpg",
    "responses": "dark, curvy",
    "row": 1384,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 2041428
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "desert, smooth",
    "row": 1385,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 2054064
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "rough, wrinkly, rainbow",
    "row": 1386,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 2082379
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "Grand, lovely",
    "row": 1347,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 1093632
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "Ra",
    "row": 1348,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23Klee2.jpg",
    "time_elapsed": 1103566
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "Radiant, nice",
    "row": 1349,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23Kline1.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 1115833
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "Ravishing, pleasing",
    "row": 1350,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 1127300
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Ideal, cool",
    "row": 1351,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 1141970
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "Nice, beautiful",
    "row": 1352,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 1159433
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "fascinating, fine",
    "row": 1353,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 1166822
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "striped, colourful, lightened, unclear",
    "row": 1314,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 1366707
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "wavey, rainbow, blended, vivid, bright",
    "row": 1315,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 1404127
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "crisp, clear, happy, centred",
    "row": 1316,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1439943
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "night, shadowed, clarity, wintery",
    "row": 1317,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 1493262
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "whitened, sketched, pastel, cartoonish, soft",
    "row": 1318,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 1567191
  },
  {
    "target_image": "23Chirico.jpg",
    "responses": "gloomy, autumnal, wavey, stormy",
    "row": 1319,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1621406
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "bold, streaked, soft, colourful, hawks",
    "row": 1320,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 1661139
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "bright, shapes, contrast, colours, warm",
    "row": 1281,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 1371189
  },
  {
    "target_image": "23Klimt1.jpg",
    "responses": "grainy, pointilism, hazy, dusty",
    "row": 1282,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 1403979
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "cartoon, bright, 3d, depth, no stick on the p",
    "row": 1283,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 1483782
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "wo, hazy, fading",
    "row": 1284,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 1518578
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "cubes, shiny",
    "row": 1285,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 1557974
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "warm, bright, sunset",
    "row": 1286,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23Ingleside.jpg",
    "time_elapsed": 1619371
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "dark, wavy, paypal, sea",
    "row": 1287,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 1692067
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "one dimensional scheme, simple, overcast",
    "row": 1248,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "23Rothko2.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 1290019
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "city, artificial lights reflecting, eerie,",
    "row": 1249,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1342968
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "night time, bleak, dark, bold and simple",
    "row": 1250,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "23Picasso.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 1436154
  },
  {
    "target_image": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "cold day, cloudy, snowy",
    "row": 1251,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "23Kline1.jpg",
    "distractorTwo": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 1468364
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "day time, cold,",
    "row": 1252,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 1492027
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "dusk, cold, fuzzy,",
    "row": 1253,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23porch-ii-1947.jpg",
    "time_elapsed": 1513331
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "cold, night",
    "row": 1254,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 1527439
  },
  {
    "target_image": "23Mondrian3.jpg",
    "responses": "Blurred,windswept,lonely.",
    "row": 1215,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 1093375
  },
  {
    "target_image": "23ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "Rich,festive,warm.",
    "row": 1216,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1125600
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "Jumbled,chaotic but warm.",
    "row": 1217,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 1165978
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "Cold,lonely and isolated.",
    "row": 1218,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 1199272
  },
  {
    "target_image": "23Klimt1.jpg",
    "responses": "Autumn,windy,drab.",
    "row": 1219,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 1294560
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "Tense,dark,scary.",
    "row": 1220,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 1326622
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "Wintery,cold,chaotic.",
    "row": 1221,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 1384102
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "neutral, bland, colourless, dull",
    "row": 1182,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 1236893
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "blocky, smooth",
    "row": 1183,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 1291894
  },
  {
    "target_image": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "neon, cyber, crumpled",
    "row": 1184,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 1350507
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "fiery, loud, bright, lively",
    "row": 1185,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 1381560
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "neutral, bland, colourless, dull",
    "row": 1186,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 1398024
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "watercolour, cartoon, pale",
    "row": 1187,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1435775
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "fiery, loud, eerie",
    "row": 1188,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 1456172
  },
  {
    "target_image": "23the-pink-candle-1910.jpg!Large.jpg",
    "responses": "sharp, pastel, contrast",
    "row": 1149,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 1090720
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "patchwork, contrasting, urban, sooty",
    "row": 1150,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23portrait-of-daughter-1912.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 1121184
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "cubist, japanese",
    "row": 1151,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 1244056
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "warm, mountainous",
    "row": 1152,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1282385
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "American indian, Autumn, kaleidoscope",
    "row": 1153,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 1357673
  },
  {
    "target_image": "23Chirico.jpg",
    "responses": "Autumn wind, rusty, dark",
    "row": 1154,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 1401073
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "high contrast, spring snow, fading light",
    "row": 1155,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 1472489
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "colourful, oil",
    "row": 1116,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23the-row.jpg!Large.jpg",
    "time_elapsed": 1161877
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "twilight",
    "row": 1117,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 1176922
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "muted, aged, oil",
    "row": 1118,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 1210356
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dark, viewed through sun glasses",
    "row": 1119,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "23ManRay.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1299731
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "colourful, noisy, a lot going on",
    "row": 1120,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 1345743
  },
  {
    "target_image": "23Chirico.jpg",
    "responses": "agedm damaged, oil",
    "row": 1121,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 1377242
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "cold, frosty, ice",
    "row": 1122,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "23Rothko2.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1393238
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "Cool, Imaginative, Wicked",
    "row": 1083,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1217567
  },
  {
    "target_image": "23Klee2.jpg",
    "responses": "Weird, Lost, Dreamy",
    "row": 1084,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 1242546
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "Unique, Unusual, Funky",
    "row": 1085,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1277741
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "Beautiful, Lovely, Nice",
    "row": 1086,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 1302712
  },
  {
    "target_image": "23portrait-of-daughter-1912.jpg",
    "responses": "Colourful, Unique",
    "row": 1087,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1333865
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "Warm, Cosy, Evening",
    "row": 1088,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23Klee1.jpg",
    "distractorThree": "23Ingleside.jpg",
    "time_elapsed": 1360648
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "Colourful, Eye-Catching, Funky",
    "row": 1089,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 1385842
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "Film, hazy",
    "row": 1050,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "23grablegung.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 910202
  },
  {
    "target_image": "23Mucha.jpg",
    "responses": "Geometric, abstract, warm",
    "row": 1051,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23dd101419.jpg!Large.jpg",
    "time_elapsed": 920898
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "Brushed",
    "row": 1052,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 943699
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "Crinkled",
    "row": 1053,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 961778
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "Cool",
    "row": 1054,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 999553
  },
  {
    "target_image": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "Cool, abstract",
    "row": 1055,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23Kline2.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 1025337
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "Realistic, clear",
    "row": 1056,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 1060695
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "colourful, late, pleasant, slightly dark",
    "row": 1017,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 1101171
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "clear, early, pastel, colourful",
    "row": 1018,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 1133503
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "early, wet, sunrise",
    "row": 1019,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1201767
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "colourful, brighter, clearer",
    "row": 1020,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 1256675
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "realistic, colourful, daytime, clearer",
    "row": 1021,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 1311118
  },
  {
    "target_image": "23Mondrian3.jpg",
    "responses": "early, bright, pastel",
    "row": 1022,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 1339696
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "colourful, blurred, obscured, faint",
    "row": 1023,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "23Rothko2.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 1383674
  },
  {
    "target_image": "23dd101419.jpg!Large.jpg",
    "responses": "cold, dark, damp",
    "row": 984,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "23Remebrandt.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23porch-ii-1947.jpg",
    "time_elapsed": 1159455
  },
  {
    "target_image": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "blurry, pasty, sombre",
    "row": 985,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 1179766
  },
  {
    "target_image": "23Rozanova2.jpg",
    "responses": "cold, windy",
    "row": 986,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 1227654
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "night, windy, pastel",
    "row": 987,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1261421
  },
  {
    "target_image": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "pastel, wavy, dark",
    "row": 988,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 1273758
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "coldm dark, ominous",
    "row": 989,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 1282554
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "earthy, cold",
    "row": 990,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 1305938
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "pastel, bright",
    "row": 951,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23MaxErnst.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 1227281
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "acrylic paint, oil paint",
    "row": 952,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "23kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1231198
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "pastel, acrylic paint, oil paint",
    "row": 953,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 1234960
  },
  {
    "target_image": "23Chirico.jpg",
    "responses": "pastel, acrylic paint, oil paint",
    "row": 954,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 1237567
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "pastel",
    "row": 955,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 1248173
  },
  {
    "target_image": "23mary-magdalene.jpg!Large.jpg",
    "responses": "acrylic paint, oil paint, dark",
    "row": 956,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 1256280
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "acrylic paint, oil paint",
    "row": 957,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 1263695
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "mixed, dense, blurry, defined, raspeberries",
    "row": 918,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 1054031
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "cold, icy, lifeless",
    "row": 919,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 1076512
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "warm, sand , drought, harsh",
    "row": 920,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "23ManRay.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 1107747
  },
  {
    "target_image": "23madonna-casini.jpg",
    "responses": "blurry, dense, warm, hot, armegeddon, pastel",
    "row": 921,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23Pollock2.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 1149374
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "tropical, fauna, overgrown, vegetatious",
    "row": 922,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1189723
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "hot, volcanic, steamy, vibrant",
    "row": 923,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1229892
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "cool, pastel, wintry, ice",
    "row": 924,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "23Burliuk.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 1255391
  },
  {
    "target_image": "23Richter.jpg",
    "responses": "bloody snow, blurred, clear tree",
    "row": 885,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 980546
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "very impressionistic, bright colours, person not clear,",
    "row": 886,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 1032038
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "pastel, blurred, out of focus, cool palette",
    "row": 887,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 1048732
  },
  {
    "target_image": "23Pollock2.jpg",
    "responses": "cold palette, person blends in, lot of sky colour",
    "row": 888,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1084353
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "pastel drawing effect, creases in snow, muted tones,",
    "row": 889,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 1119971
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "warm palette, brush strokes in snow, girly",
    "row": 890,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 1159045
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "only partly coloured, rainbow in snow, drab bag colour,",
    "row": 891,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 1188876
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "chilly, soft, undefined",
    "row": 852,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 962596
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "colorful, dark, muddy",
    "row": 853,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23Cezanne.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 982624
  },
  {
    "target_image": "23Mondrian3.jpg",
    "responses": "soft, warm, glowing",
    "row": 854,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23Klee1.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 1003409
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "harsh, drab, discolored",
    "row": 855,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 1057187
  },
  {
    "target_image": "23ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "sepia, warm, dark",
    "row": 856,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 1078893
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dim, somber, sepia",
    "row": 857,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23Rothko.jpg",
    "time_elapsed": 1110376
  },
  {
    "target_image": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "dark, bleak, discolored",
    "row": 858,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23still-life.jpg",
    "time_elapsed": 1160235
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "dark,",
    "row": 819,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 858810
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark,bleak",
    "row": 820,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 898586
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "digital, unclear",
    "row": 821,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 931002
  },
  {
    "target_image": "23Mondrian.jpg",
    "responses": "warm, clear",
    "row": 822,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 940890
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "lack of detail, smooth",
    "row": 823,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "23les-musiciens-1952.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 966938
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dark",
    "row": 824,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 1131648
  },
  {
    "target_image": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "distorted, glitchy",
    "row": 825,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23Ingleside.jpg",
    "time_elapsed": 1144472
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "abstract, trippy, variety of colours, unclear, blurry",
    "row": 786,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 571956
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "earthy tones, blurry, abstract, unclear",
    "row": 787,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 586935
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "soft, pastel, calm, peaceful",
    "row": 788,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23dd101419.jpg!Large.jpg",
    "time_elapsed": 600399
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "trippy, bright, vivid colours,",
    "row": 789,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 613011
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "smooth, warm tones, clear, calm",
    "row": 790,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "23Kline1.jpg",
    "distractorTwo": "23kateryna-1951.jpg!Large.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 631831
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "danger, empahsis on the centre, clear",
    "row": 791,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "23Klee2.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 662411
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "abstract, wavey, unclear, earth tones",
    "row": 792,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 676306
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "horizontal,blocked,bright",
    "row": 753,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 506460
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "winter,morning",
    "row": 754,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23dd101419.jpg!Large.jpg",
    "time_elapsed": 547037
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "abstact,bright,flashes",
    "row": 755,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 571226
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "abstract,bright,sunshine,movement",
    "row": 756,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 609891
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "contrast,movement,abstract,sunset,defined",
    "row": 757,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 654318
  },
  {
    "target_image": "23still-life.jpg",
    "responses": "rainbow,dark,rain",
    "row": 758,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 725367
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "pastels,dawn,snow,bright",
    "row": 759,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "23Mucha.jpg",
    "distractorTwo": "23Chirico.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 750464
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "nice, soft, friendly,",
    "row": 720,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 615640
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "abstract, dumpy, too vague,",
    "row": 721,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23Rodchenko1.jpg",
    "time_elapsed": 644256
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "bland, cold, sad,",
    "row": 722,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "23grablegung.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 662873
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "hopeful, promising, optimistic,",
    "row": 723,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 690137
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "crazy, weird, nightmarish,",
    "row": 724,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 713025
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "dark, boring, unfriendly,",
    "row": 725,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23Richter2.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 734122
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "worth looking at, eye catching, compelling,",
    "row": 726,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 769442
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "blurry, pastel, gloomy",
    "row": 687,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 448760
  },
  {
    "target_image": "23the-snow-maiden.jpg!Large.jpg",
    "responses": "dark, gloomy, chromatic",
    "row": 688,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "23Klee2.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 460212
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "messy, dark, blurry, watery",
    "row": 689,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "23Pollock1.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 466015
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "messy, dark, blurry, watery",
    "row": 690,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23Kline2.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 473736
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "dark, gloomy, chromatic",
    "row": 691,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 484132
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurry, light, sunny,",
    "row": 692,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 490892
  },
  {
    "target_image": "23still-life.jpg",
    "responses": "dark, gloomy, chromatic",
    "row": 693,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 498589
  },
  {
    "target_image": "23Cezanne.jpg",
    "responses": "Sketch, oil, soft, strokes",
    "row": 654,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23Klee1.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 571173
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "Dark, dim, winter, muted",
    "row": 655,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 581769
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "Hope, spectrum, glimmer, soft",
    "row": 656,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "23Rothko2.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 622563
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "Contrast, hard, jagged, blocks",
    "row": 657,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "23grablegung.jpg",
    "distractorThree": "23hoffmann.jpg",
    "time_elapsed": 641578
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "Soft, hazy, dreamy, glimmer, cold",
    "row": 658,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23Mondrian3.jpg",
    "time_elapsed": 669494
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "Blur, hazy, soft, warm",
    "row": 659,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23JeanDupas.jpg",
    "time_elapsed": 691781
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "Aquatic, harsh, blur, merge,",
    "row": 660,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 730770
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "autumnal, fuzzy,",
    "row": 621,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 538289
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "bright, colourful,",
    "row": 622,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23RobertCampin.jpg",
    "distractorThree": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 597747
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "warm,",
    "row": 623,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 612195
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, moody,",
    "row": 624,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23Marquet.jpg",
    "distractorThree": "23porch-ii-1947.jpg",
    "time_elapsed": 621676
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "bright, sunny,",
    "row": 625,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 629689
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "plain, warm,",
    "row": 626,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 681044
  },
  {
    "target_image": "23mary-magdalene.jpg!Large.jpg",
    "responses": "dark, moody,",
    "row": 627,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23Klee1.jpg",
    "time_elapsed": 697327
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "cartoon, handdrawn, chalk, colourful",
    "row": 588,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 579621
  },
  {
    "target_image": "23madonna-casini.jpg",
    "responses": "sepia, old fashioned, slight blur",
    "row": 589,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 596408
  },
  {
    "target_image": "23the-day-dream-1880.jpg!Large.jpg",
    "responses": "alien colours, blurred, some defined lines",
    "row": 590,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 614709
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "sepia, warm colours, blurred",
    "row": 591,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "23RobertCampin.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 631309
  },
  {
    "target_image": "23Klee2.jpg",
    "responses": "bright warm colours, blurred",
    "row": 592,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 641515
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "almost monochrome, newspaper image, blocky",
    "row": 593,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 665045
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "some colours included, computer generated drawing",
    "row": 594,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 690632
  },
  {
    "target_image": "23the-liver-is-the-cock-s-comb.jpg",
    "responses": "jarrying, bright, warm, hot, firey",
    "row": 555,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 603636
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "jagged, technocoloured",
    "row": 556,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23Rauschenberg.jpg",
    "time_elapsed": 617817
  },
  {
    "target_image": "23Klee2.jpg",
    "responses": "hazy, blurry, warm, hot, searing",
    "row": 557,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23porch-ii-1947.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 633080
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "hazy, blurry, warm, hot, calm, smooth, soft",
    "row": 558,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 649543
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "chaotic, destructive, warm, hot, jarring",
    "row": 559,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "23JohnsJasper.jpg",
    "distractorTwo": "23Pollock2.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 663568
  },
  {
    "target_image": "23the-pink-candle-1910.jpg!Large.jpg",
    "responses": "blurry, hazy, warm, hot, oppressive",
    "row": 560,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "23JeanDupas.jpg",
    "distractorTwo": "23kateryna-1951.jpg!Large.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 678662
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "dark, realistic, moody",
    "row": 561,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23Klimt1.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 694076
  },
  {
    "target_image": "23madonna-casini.jpg",
    "responses": "vivid,unclear,muddy",
    "row": 522,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23Richter2.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 524690
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "totured,twisted,unrecognisable,abstract,harsh",
    "row": 523,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 541713
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dark,muddy,gloomy,depressing",
    "row": 524,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23Mondrian.jpg",
    "time_elapsed": 553433
  },
  {
    "target_image": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "bright,oversaturated,false colour",
    "row": 525,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 576371
  },
  {
    "target_image": "23Matisse.jpg",
    "responses": "multicoloured,abstract,uplifting,happy",
    "row": 526,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "23girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 600299
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "dull,muted,muddy,gloomy",
    "row": 527,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 610058
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "intense,dramatic,disquieting",
    "row": 528,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "23self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "23Mondrian3.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 630050
  },
  {
    "target_image": "23Marquet.jpg",
    "responses": "like tv image distortion noise",
    "row": 489,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 535441
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "co",
    "row": 490,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 551820
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "colourful, wavey",
    "row": 491,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "23Rothko.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 570813
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "soft, warm",
    "row": 492,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23Cezanne.jpg",
    "distractorThree": "23mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 577420
  },
  {
    "target_image": "23Chirico.jpg",
    "responses": "edgy, sharp",
    "row": 493,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23Richter.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 590058
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "muted, blurry, bright, three toned colours",
    "row": 494,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 615756
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "like a negative photograph, well defined outline, blurry otherwise",
    "row": 495,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "23Rozanova2.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 651998
  },
  {
    "target_image": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "warm, warped, lack of detail, pinched",
    "row": 456,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 444363
  },
  {
    "target_image": "23ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "hot, deep, muted, blurry, warm",
    "row": 457,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "23Klee1.jpg",
    "distractorTwo": "23Remebrandt.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 458841
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "muted, blurry, cold, lack of detail",
    "row": 458,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 484616
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "warm, sunset, pastel, sharpness, sharp, patchy",
    "row": 459,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23Richter2.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 504134
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "dark, patchy, warped, warm, pinched, distorted",
    "row": 460,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23Ingleside.jpg",
    "time_elapsed": 523664
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "warm, muted, blurry, shadows",
    "row": 461,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "23kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 537997
  },
  {
    "target_image": "23MaxErnst.jpg",
    "responses": "bright, colourful, pastel, palette knife, monet, warm",
    "row": 462,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 567921
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "cool toned, golden hour, dull, hazy, soft",
    "row": 423,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23pissaro.jpg",
    "time_elapsed": 445364
  },
  {
    "target_image": "23Klee2.jpg",
    "responses": "warm, golden hour, bright, stippled",
    "row": 424,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23Kline2.jpg",
    "time_elapsed": 457723
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dull, dark, multi tonal, softened/hazy.",
    "row": 425,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23the-dream-1910.jpg!Large.jpg",
    "distractorThree": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 470805
  },
  {
    "target_image": "23JohnsJasper.jpg",
    "responses": "dull, cool, multi tonal, hazy,",
    "row": 426,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "23Marquet.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 484342
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "vivid, hand drawn, pastel, soft shading, sharp lines.",
    "row": 427,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "23Rothko2.jpg",
    "distractorTwo": "23Rodchenko1.jpg",
    "distractorThree": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 502046
  },
  {
    "target_image": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "warm autumnal tones, stippled details, sharp lines, small textures.",
    "row": 428,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "23Richter.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 523301
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "multitoned, strong details, vivid colours, dark.",
    "row": 429,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23JeanDupas.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 540469
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "dusky, blurred, fading",
    "row": 390,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 351441
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "bright, blurred, unclear",
    "row": 391,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 362696
  },
  {
    "target_image": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "wintry, night, stream of light",
    "row": 392,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 383230
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "drawing, swirling, blurred",
    "row": 393,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "23moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23EdgarDegas.jpg",
    "time_elapsed": 394361
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "abstract, rectangular, smudged",
    "row": 394,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23Picasso.jpg",
    "time_elapsed": 408421
  },
  {
    "target_image": "23Klee2.jpg",
    "responses": "bright, fused, streaming",
    "row": 395,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "23Matisse.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 422810
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "unclear, modern, abstract",
    "row": 396,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 433519
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "cold, wintery",
    "row": 357,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23Rothko2.jpg",
    "time_elapsed": 396239
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "lights",
    "row": 358,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "23girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "23Moholy.jpg",
    "distractorThree": "23Cezanne.jpg",
    "time_elapsed": 408728
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "messy,",
    "row": 359,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 416049
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "warm",
    "row": 360,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23the-row.jpg!Large.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 430946
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "blurry",
    "row": 361,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "23madonna-casini.jpg",
    "distractorTwo": "23Rozanova2.jpg",
    "distractorThree": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 438475
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "artic",
    "row": 362,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 445268
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "messy,",
    "row": 363,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23Richter2.jpg",
    "time_elapsed": 452340
  },
  {
    "target_image": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "dark",
    "row": 324,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23madonna-casini.jpg",
    "time_elapsed": 398490
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "shadow",
    "row": 325,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 414045
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "good use of colours",
    "row": 326,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "23the-row.jpg!Large.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 423856
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "dull, blurred",
    "row": 327,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "23Picasso.jpg",
    "distractorTwo": "23kateryna-1951.jpg!Large.jpg",
    "distractorThree": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 436906
  },
  {
    "target_image": "23Burliuk.jpg",
    "responses": "great use of colour",
    "row": 328,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "23gladiators-1940.jpg",
    "distractorThree": "23the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 447372
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "cool",
    "row": 329,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23Pollock1.jpg",
    "distractorThree": "23Remebrandt.jpg",
    "time_elapsed": 455336
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "2 effects used",
    "row": 330,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23Richter.jpg",
    "time_elapsed": 464026
  },
  {
    "target_image": "23ManRay.jpg",
    "responses": "simplistic, calming",
    "row": 291,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23madonna-casini.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 1401490
  },
  {
    "target_image": "23Moholy.jpg",
    "responses": "cold, chilly, swirling",
    "row": 292,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 1493029
  },
  {
    "target_image": "23Richter2.jpg",
    "responses": "digital, abstract",
    "row": 293,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "23Nay.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 1548670
  },
  {
    "target_image": "23les-musiciens-1952.jpg",
    "responses": "colourful, contrasting",
    "row": 294,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "23girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23Burliuk.jpg",
    "time_elapsed": 1597891
  },
  {
    "target_image": "23the-memory-of-the-golden-apse-2009.jpg",
    "responses": "calm, natural, realistic",
    "row": 295,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 1654571
  },
  {
    "target_image": "23JeanDupas.jpg",
    "responses": "unnerving, dark, chilling",
    "row": 296,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "23Richter.jpg",
    "distractorTwo": "23self-portrait-with-brushes-1942.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 1728181
  },
  {
    "target_image": "23kateryna-1951.jpg!Large.jpg",
    "responses": "eye-catching, focused",
    "row": 297,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 1787288
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "ugly, blurry, discolored, dark",
    "row": 258,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23Cezanne.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 874587
  },
  {
    "target_image": "23Mondrian3.jpg",
    "responses": "blurry, light, alone, sad",
    "row": 259,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "23the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "23moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 885187
  },
  {
    "target_image": "23mary-magdalene.jpg!Large.jpg",
    "responses": "alone, dark, night, scary, dangerous",
    "row": 260,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "23girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 931830
  },
  {
    "target_image": "23Klee1.jpg",
    "responses": "blurry, washed out, alone",
    "row": 261,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "23porch-ii-1947.jpg",
    "time_elapsed": 940185
  },
  {
    "target_image": "23city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "abstractism, modernism, chaotic",
    "row": 262,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 963767
  },
  {
    "target_image": "23Pollock1.jpg",
    "responses": "wormy, expressionistic, dark, night, alone",
    "row": 263,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "23Chirico.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 989441
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "autumn, warmth, calmness",
    "row": 264,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "23mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1006233
  },
  {
    "target_image": "23self-portrait-with-brushes-1942.jpg",
    "responses": "blurred, cool palette, muddled, lost, abstract",
    "row": 225,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "23the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "23kateryna-1951.jpg!Large.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 1212849
  },
  {
    "target_image": "23grablegung.jpg",
    "responses": "windy, warm palette, unclear objects",
    "row": 226,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "23gladiators-1940.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 1275327
  },
  {
    "target_image": "23RobertCampin.jpg",
    "responses": "animated colours, blurred, abstract",
    "row": 227,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "23Moholy.jpg",
    "time_elapsed": 1287244
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "sponge effect colour, cool palette, damp and cool",
    "row": 228,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "23dd101419.jpg!Large.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 1338105
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dark palette, scary, unknown, quiet",
    "row": 229,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 1423163
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "cool palette, wintry day with frost",
    "row": 230,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 1456936
  },
  {
    "target_image": "23Picasso.jpg",
    "responses": "animated colours, blurred, abstract",
    "row": 231,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23still-life.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 1476910
  },
  {
    "target_image": "23einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "futuristic, psychedelic, warming",
    "row": 192,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23Mondrian.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 941901
  },
  {
    "target_image": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "unnerving, disco, dynamic",
    "row": 193,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 1037780
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "bland, featureless, uninteresting",
    "row": 194,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "23mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "23ManRay.jpg",
    "distractorThree": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 1100479
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "bloody, scary, puse",
    "row": 195,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "23machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1118454
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "unimaginative, soulless, snowy, cold",
    "row": 196,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 1275539
  },
  {
    "target_image": "23pissaro.jpg",
    "responses": "hazy, scattered, cracked, three-dimensional",
    "row": 197,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "23Rodchenko1.jpg",
    "distractorTwo": "23Klee1.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1376034
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "unfinished, blankness, plain",
    "row": 198,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "23portrait-of-daughter-1912.jpg",
    "time_elapsed": 1424889
  },
  {
    "target_image": "23ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "bright, fiery, soft",
    "row": 159,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "23hoffmann.jpg",
    "distractorTwo": "23portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "23Mucha.jpg",
    "time_elapsed": 618290
  },
  {
    "target_image": "23Rauschenberg.jpg",
    "responses": "simple, colourful",
    "row": 160,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "23porch-ii-1947.jpg",
    "distractorTwo": "23Burliuk.jpg",
    "distractorThree": "23the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 662082
  },
  {
    "target_image": "23the-pink-candle-1910.jpg!Large.jpg",
    "responses": "dark, misty, cold",
    "row": 161,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "23city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23Klimt1.jpg",
    "time_elapsed": 688417
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "crazy, colorful, hidden",
    "row": 162,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "23Kline2.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23Matisse.jpg",
    "time_elapsed": 713820
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "floating, dark, soft",
    "row": 163,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "23girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "23EdgarDegas.jpg",
    "distractorThree": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 737220
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "hazy",
    "row": 164,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "23Kline1.jpg",
    "time_elapsed": 771943
  },
  {
    "target_image": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "cold, foggy, wintry",
    "row": 165,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 792482
  },
  {
    "target_image": "23gladiators-1940.jpg",
    "responses": "arty",
    "row": 126,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "23grablegung.jpg",
    "time_elapsed": 260313
  },
  {
    "target_image": "23Kline1.jpg",
    "responses": "square",
    "row": 127,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "23Rozanova2.jpg",
    "time_elapsed": 265241
  },
  {
    "target_image": "23Ingleside.jpg",
    "responses": "cold",
    "row": 128,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23Rothko.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 269041
  },
  {
    "target_image": "23moscow-i-1916.jpg!Large.jpg",
    "responses": "haphazard",
    "row": 129,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "23JeanDupas.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23ManRay.jpg",
    "time_elapsed": 274953
  },
  {
    "target_image": "23girl-s-head-in-a-shawl.jpg",
    "responses": "inbetween",
    "row": 130,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "23Mondrian.jpg",
    "distractorTwo": "23pissaro.jpg",
    "distractorThree": "23Nay.jpg",
    "time_elapsed": 282657
  },
  {
    "target_image": "23still-life.jpg",
    "responses": "warmist",
    "row": 131,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "23Pollock2.jpg",
    "distractorTwo": "23Kline2.jpg",
    "distractorThree": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 288673
  },
  {
    "target_image": "23Remebrandt.jpg",
    "responses": "cracked",
    "row": 132,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "23EdgarDegas.jpg",
    "distractorTwo": "23Mucha.jpg",
    "distractorThree": "23Pollock1.jpg",
    "time_elapsed": 293433
  },
  {
    "target_image": "23EdgarDegas.jpg",
    "responses": "soft, pastels, painted",
    "row": 93,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "23Cezanne.jpg",
    "distractorTwo": "23Picasso.jpg",
    "distractorThree": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 298993
  },
  {
    "target_image": "23the-dream-1910.jpg!Large.jpg",
    "responses": "harsh, blocky, bright",
    "row": 94,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "23Rothko2.jpg",
    "distractorTwo": "23hoffmann.jpg",
    "distractorThree": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 309486
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "impressionist, cool",
    "row": 95,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "23portrait-of-daughter-1912.jpg",
    "distractorTwo": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 317854
  },
  {
    "target_image": "23Nay.jpg",
    "responses": "abstract, swirly, bright",
    "row": 96,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "23ManRay.jpg",
    "distractorTwo": "23JohnsJasper.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 326442
  },
  {
    "target_image": "23machine-man-with-spiral-turn-1930.jpg",
    "responses": "bright, cool, hard to read",
    "row": 97,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "23the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "23destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "23ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 335208
  },
  {
    "target_image": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "warm, bright, painted, soft",
    "row": 98,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 344792
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "soft, blurred, warm",
    "row": 99,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "23pissaro.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 354084
  },
  {
    "target_image": "23Rothko.jpg",
    "responses": "cool, pastel",
    "row": 60,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "23Moholy.jpg",
    "distractorTwo": "23Ingleside.jpg",
    "distractorThree": "23JohnsJasper.jpg",
    "time_elapsed": 378249
  },
  {
    "target_image": "23Kline2.jpg",
    "responses": "creative, cool, soft",
    "row": 61,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "23reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "23les-musiciens-1952.jpg",
    "distractorThree": "23the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 384939
  },
  {
    "target_image": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "soft, cool, clear",
    "row": 62,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "23Richter2.jpg",
    "distractorTwo": "23ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "23the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 393071
  },
  {
    "target_image": "23oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "sharp, constrat, bright",
    "row": 63,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "23the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "23the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "23dd101419.jpg!Large.jpg",
    "time_elapsed": 403228
  },
  {
    "target_image": "23destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "soft, cool, clear",
    "row": 64,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "23still-life.jpg",
    "distractorTwo": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "23Pollock2.jpg",
    "time_elapsed": 409689
  },
  {
    "target_image": "23mary-magdalene.jpg!Large.jpg",
    "responses": "creative, cool, soft",
    "row": 65,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "23Rauschenberg.jpg",
    "distractorTwo": "23girl-s-head-in-a-shawl.jpg",
    "distractorThree": "23RobertCampin.jpg",
    "time_elapsed": 418033
  },
  {
    "target_image": "23Rothko2.jpg",
    "responses": "blurred, dull,",
    "row": 66,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "23MaxErnst.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23gladiators-1940.jpg",
    "time_elapsed": 428276
  },
  {
    "target_image": "23the-row.jpg!Large.jpg",
    "responses": "cool",
    "row": 27,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "23Klimt1.jpg",
    "distractorTwo": "23early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "23Chirico.jpg",
    "time_elapsed": 435288
  },
  {
    "target_image": "23porch-ii-1947.jpg",
    "responses": "tinted,",
    "row": 28,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "23portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "23Rauschenberg.jpg",
    "distractorThree": "23MaxErnst.jpg",
    "time_elapsed": 460682
  },
  {
    "target_image": "23samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "dull, dark, scary",
    "row": 29,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "23Mondrian3.jpg",
    "distractorTwo": "23Nay.jpg",
    "distractorThree": "23the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 470863
  },
  {
    "target_image": "23hoffmann.jpg",
    "responses": "dark, warm",
    "row": 30,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "23girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "23mary-magdalene.jpg!Large.jpg",
    "distractorThree": "23Marquet.jpg",
    "time_elapsed": 484491
  },
  {
    "target_image": "23Rodchenko1.jpg",
    "responses": "hazy, warm, simple",
    "row": 31,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "23the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "23Matisse.jpg",
    "distractorThree": "23the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 494456
  },
  {
    "target_image": "23disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "bright",
    "row": 32,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "23Ingleside.jpg",
    "distractorTwo": "23portrait-of-daughter-1912.jpg",
    "distractorThree": "23the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 507294
  },
  {
    "target_image": "23d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "dull, neutral",
    "row": 33,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "23portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "23dd101419.jpg!Large.jpg",
    "distractorThree": "23lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 523410
  }
]