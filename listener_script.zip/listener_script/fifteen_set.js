var fifteen_set= [
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "bright, little detail, warm, unpleasant",
    "row": 5060,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 371824
  },
  {
    "target_image": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "saturated, deep colours, dark",
    "row": 5061,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 486106
  },
  {
    "target_image": "15Rozanova2.jpg",
    "responses": "light, blurred, contrast",
    "row": 5062,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15RobertCampin.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 535535
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "blurred, boxy, angular, bright",
    "row": 5063,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15the-dream-1910.jpg!Large.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 596985
  },
  {
    "target_image": "15Klimt1.jpg",
    "responses": "very blurred, dessert, uniform",
    "row": 5064,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 666469
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "cool, pastel",
    "row": 5065,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 709332
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "crisp, contrast, blocky",
    "row": 5066,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 766178
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "rainbow, squares, bold, linear, blurry",
    "row": 5027,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "15Moholy.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 397566
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "dark, fiery, sharp",
    "row": 5028,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 450606
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "sunset, warm, dark",
    "row": 5029,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 593967
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "gentle, vibrant, vivid, smooth, warm, cool",
    "row": 5030,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 845045
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "vertical, thick, elongated, depth, contrasting",
    "row": 5031,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 1006310
  },
  {
    "target_image": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "dark, dreamy, night, sunset",
    "row": 5032,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 1036462
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "angular, light, neutral, stone, creamy, bright",
    "row": 5033,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1144860
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "vibrant, heavy brush strokes, ablaze, showy, vivid",
    "row": 4994,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 640437
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "pastel, watery, delicate",
    "row": 4995,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15Kline1.jpg",
    "time_elapsed": 836625
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "Vibrant, colorful, multicolored, smooth",
    "row": 4996,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 963865
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "blurry, cold, cool, winter",
    "row": 4997,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 1048146
  },
  {
    "target_image": "15Rothko2.jpg",
    "responses": "sooty, inky, bold, brash",
    "row": 4998,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 1426436
  },
  {
    "target_image": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "discolored, dappled, thick brush strokes",
    "row": 4999,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 1665335
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "gloomy, discolored, warm, night, inky, sombre",
    "row": 5000,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 1839735
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "sandy, muddy, plain",
    "row": 4961,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 127967
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "sunny, warm, blurry",
    "row": 4962,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 179783
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "grassy, dark, scary",
    "row": 4963,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 196191
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "watery, fast, colorful",
    "row": 4964,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 231624
  },
  {
    "target_image": "15hoffmann.jpg",
    "responses": "woody, dark, grassy",
    "row": 4965,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 254361
  },
  {
    "target_image": "15Picasso.jpg",
    "responses": "glassy, sharp, painful",
    "row": 4966,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15self-portrait-with-brushes-1942.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 283009
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "puffy, cool, winter",
    "row": 4967,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 340515
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "lucid, vibrant, aurora, neon",
    "row": 4928,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 242357
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "night, dark, pastel",
    "row": 4929,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 422286
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "sharp, bright, mixed hues, natural",
    "row": 4930,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15gladiators-1940.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 615600
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "vivid, dark, smoky, vibrant",
    "row": 4931,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 802434
  },
  {
    "target_image": "15the-dream-1910.jpg!Large.jpg",
    "responses": "sharp, dark, defined",
    "row": 4932,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 872470
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "blurred, autumn, natural",
    "row": 4933,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 966626
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "winter, sharp, boxy, light",
    "row": 4934,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 1186094
  },
  {
    "target_image": "15the-dream-1910.jpg!Large.jpg",
    "responses": "dark, bold, night,  sharp, thickened smoke, doom, gloom",
    "row": 4895,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15portrait-of-daughter-1912.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 776279
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "charcoal, definitive with slight blur, fast moving, oil crayon",
    "row": 4896,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 914987
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "longitudinal, repetitive, copy and paste in nature, loss of light, newspaper",
    "row": 4897,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15madonna-casini.jpg",
    "time_elapsed": 1037849
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "glaciered, mountainside, sunset reflection, streaky",
    "row": 4898,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 1102505
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "clear, slightly dull, slight warmth, longitudinal",
    "row": 4899,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 1265134
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "smear, slight blur, moderately undefined, daytime",
    "row": 4900,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "15Mucha.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 1375914
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "kaleidoscope, outlined, bold",
    "row": 4901,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 1467868
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "muted, muddy, pastel, blurry, indistinct, foggy",
    "row": 4862,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 298529
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "jewel tone, sunny, cloudy, afternoon, clear, calm",
    "row": 4863,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 502610
  },
  {
    "target_image": "15dd101419.jpg!Large.jpg",
    "responses": "dark, dusk, vivid, ethereal",
    "row": 4864,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 615776
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "cubism, neutral, geometric, abstract, surreal, pale",
    "row": 4865,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 667369
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "hazy, fuzzy, blurry, bright, smoky",
    "row": 4866,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 719987
  },
  {
    "target_image": "15Remebrandt.jpg",
    "responses": "hidden, camouflaged, dark, intense, outlines, primitive",
    "row": 4867,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 879881
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "dark, stormy, sunset, cottony, cloudy",
    "row": 4868,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 998886
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "vibrant, reflective, sunset",
    "row": 4829,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 310743
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "volcano, autumn, rain",
    "row": 4830,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 380502
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "displaced, plain",
    "row": 4831,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 466768
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "sketch, warm, powerful",
    "row": 4832,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 572917
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "smudge, dusk",
    "row": 4833,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 696699
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "paranormal, powerful, dream",
    "row": 4834,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 729054
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "old, lonely",
    "row": 4835,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 818345
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "Blocky, light, sketchy, electronic, warm",
    "row": 4796,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15Rauschenberg.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 639474
  },
  {
    "target_image": "15grablegung.jpg",
    "responses": "Transformer vibes, warm, light, dreamy, early morning or early evening, connected",
    "row": 4797,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 789375
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "Bat night, flocking, cool, night, cold",
    "row": 4798,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 891320
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "Bold, cool, colourful, breezy, night, blended",
    "row": 4799,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 981818
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "Smoky, fazed, sandy, sketchy, warm",
    "row": 4800,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 1046814
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "Futuristic, graffiti, night, lit up,",
    "row": 4801,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 1133913
  },
  {
    "target_image": "15Rozanova2.jpg",
    "responses": "Twisted, filled, ghostly, cold, swirls, snowy",
    "row": 4802,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "15portrait-of-daughter-1912.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 1207056
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "family,adventure,seaside,evening,",
    "row": 4763,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 232199
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "cold,tired,wintery,sunset",
    "row": 4764,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 372129
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "colourful,exotic,gnarly ,magical",
    "row": 4766,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "15portrait-of-daughter-1912.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 471668
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "abstract,colourful,lost,imaginative,",
    "row": 4767,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 526565
  },
  {
    "target_image": "15Richter.jpg",
    "responses": "dark,mysterious,cold, foggy",
    "row": 4768,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 575531
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "bright hues,stormy,concrete,",
    "row": 4769,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 795449
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "colorful, vibrant, dippy, mixed",
    "row": 4730,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "15Rozanova2.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 331699
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "darkened",
    "row": 4731,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 411684
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "jewel-toned, darkened, deep",
    "row": 4732,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "15les-musiciens-1952.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 447863
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "warm, wrinkled, moderately bright",
    "row": 4733,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 561997
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "desaturated, colorful, light, mostly warm",
    "row": 4734,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 656407
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "very warm, blended, dusty",
    "row": 4735,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "15Remebrandt.jpg",
    "time_elapsed": 787268
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "very colorful, very geometric",
    "row": 4736,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 849055
  },
  {
    "target_image": "15Remebrandt.jpg",
    "responses": "ornate,  busy, foreboding, natural tunnel, claustrophobia, smother, stifle,",
    "row": 4697,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 246576
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "skyscape, windswept, modern,",
    "row": 4698,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 313759
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "industrial, multi-colored, warning, ornate,",
    "row": 4699,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15self-portrait-with-brushes-1942.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 401544
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "modern, industrial, eye-popping,",
    "row": 4700,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 468815
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "doomed, dark, dusk, twilight, sunset, fear",
    "row": 4701,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 543895
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "splashy, bright, sunscape, sunny, lightshow, pyrotechnic, fire,",
    "row": 4702,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 632603
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "architecture, modern, neo, bi-level, soft focus, ornate,",
    "row": 4703,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 708354
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "warm, blurred, painting-like, distorted, smudged, atmospheric",
    "row": 4664,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15Kline1.jpg",
    "time_elapsed": 298074
  },
  {
    "target_image": "15Remebrandt.jpg",
    "responses": "chaotic, busy, crowded, crackly, sharp, high-contrast",
    "row": 4665,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 358924
  },
  {
    "target_image": "15Cezanne.jpg",
    "responses": "pastel-like, textured, sketchy, sunny",
    "row": 4666,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 466874
  },
  {
    "target_image": "15Mucha.jpg",
    "responses": "bold, hot, desert-like",
    "row": 4667,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15the-dream-1910.jpg!Large.jpg",
    "distractorThree": "15Marquet.jpg",
    "time_elapsed": 525304
  },
  {
    "target_image": "15Klimt1.jpg",
    "responses": "pixelated, klimt, obscure, broken, indistinct",
    "row": 4668,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15madonna-casini.jpg",
    "time_elapsed": 600474
  },
  {
    "target_image": "15Richter.jpg",
    "responses": "moody, wintery, dark, bruised, soft, restful, cloudy, stormy",
    "row": 4669,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-daughter-1912.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 679741
  },
  {
    "target_image": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "muted, highlighted, illuminated, dusky, cool, calm, still",
    "row": 4670,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15Matisse.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 811474
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "bright warm toned, clearly visible image with slightly blurred background",
    "row": 4631,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 297933
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "predominately warm tones, soft, slightly blurry",
    "row": 4632,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 396850
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "bold, bright, light",
    "row": 4633,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15portrait-of-daughter-1912.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 449847
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "light, clear, warm tones",
    "row": 4634,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 510397
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "mainly cool tones, pastel",
    "row": 4635,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "15Mucha.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 581761
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "clear, definable shapes",
    "row": 4636,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15Kline2.jpg",
    "distractorThree": "15Kline1.jpg",
    "time_elapsed": 722762
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "soft, hazy, clearly defined",
    "row": 4637,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 795359
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "grainy, blurred",
    "row": 4598,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 362567
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "smooth, boxy, textured",
    "row": 4599,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15RobertCampin.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 424078
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "indistinct, plain, soft",
    "row": 4600,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 495010
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "dark, textured, rustic, western",
    "row": 4601,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 531085
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "bright, scorching,",
    "row": 4602,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 572102
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "floral, dark",
    "row": 4603,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "15hoffmann.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 634317
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "smooth, light, scenic",
    "row": 4604,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "15Ingleside.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 668231
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurry, faded, blown out, soft, shaded,",
    "row": 4565,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "15hoffmann.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 151715
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "cubist, bright, abstract, geometrical, brushed,",
    "row": 4566,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 218858
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "blown out, soft, bright, overexposed,",
    "row": 4567,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 254746
  },
  {
    "target_image": "15Richter2.jpg",
    "responses": "low resolution, monochrome, digital,",
    "row": 4568,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 312034
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "ai, pastel, bright, contemporary",
    "row": 4569,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 444650
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "thick brush strokes, gloomy, blurred, blurry,",
    "row": 4570,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15Matisse.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 511690
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "dark, gloomy, dim, depressing, apocalyptical, dry, arid, desert like,",
    "row": 4571,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "15portrait-of-daughter-1912.jpg",
    "distractorTwo": "15Rauschenberg.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 560210
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "sharp, industrial, speedy",
    "row": 4532,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "15Marquet.jpg",
    "time_elapsed": 323610
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "dark, heavy, polluted",
    "row": 4533,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 373440
  },
  {
    "target_image": "15Remebrandt.jpg",
    "responses": "chaotic, nightmarish, scary",
    "row": 4534,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 422347
  },
  {
    "target_image": "15hoffmann.jpg",
    "responses": "dark, hellish, oppressive",
    "row": 4535,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 464026
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "dreamy, pretty",
    "row": 4536,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 535833
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "horrid, confusion, muddled",
    "row": 4537,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15Kline1.jpg",
    "time_elapsed": 615586
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "dusky, uncertainty",
    "row": 4538,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 695262
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "Blurry, soft, light, pastel",
    "row": 4499,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 423860
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "colourful, impactful, dark, dramatic",
    "row": 4500,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "15madonna-casini.jpg",
    "distractorTwo": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 501318
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "Dramatic, warm",
    "row": 4501,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 579120
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "Dark, subdued",
    "row": 4502,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-daughter-1912.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 612948
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "Dark, square, contrasted",
    "row": 4503,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 655986
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "Mottled, stippled",
    "row": 4504,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 686527
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "Angular, light, bright",
    "row": 4505,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 722863
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "blurry, light, soft",
    "row": 4466,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15Matisse.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 220948
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dark, oppressive, harsh, blurry",
    "row": 4467,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 245601
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "blurry, hard, dark, heavy",
    "row": 4468,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15Remebrandt.jpg",
    "time_elapsed": 291166
  },
  {
    "target_image": "15Cezanne.jpg",
    "responses": "light, bright, blurry, pastel,",
    "row": 4469,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 322542
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "bright, blurry, soft, colourful,",
    "row": 4470,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 357232
  },
  {
    "target_image": "15Rothko2.jpg",
    "responses": "light, colourful, pastel, blurry",
    "row": 4471,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 389012
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "light, calm, bright, blurry, calming, soft",
    "row": 4472,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15self-portrait-with-brushes-1942.jpg",
    "distractorThree": "15MaxErnst.jpg",
    "time_elapsed": 419394
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "dark colourful crazy night",
    "row": 4433,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 286959
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "warrm neutral colourful",
    "row": 4434,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 317987
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "dark cold night",
    "row": 4435,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 373244
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "warm, night,",
    "row": 4436,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 429261
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "hot, neutral, splash of colour",
    "row": 4437,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15self-portrait-with-brushes-1942.jpg",
    "distractorThree": "15madonna-casini.jpg",
    "time_elapsed": 451698
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "warm,dark, colourful",
    "row": 4438,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 479959
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "cold, breezy, neutral",
    "row": 4439,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 503407
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "mellow, warm, fantastical",
    "row": 4400,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 191065
  },
  {
    "target_image": "15Rodchenko1.jpg",
    "responses": "calming, relaxing, nostalgic, warm",
    "row": 4401,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 206935
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "modern, wintery, cool, futuristic",
    "row": 4402,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "15hoffmann.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 221951
  },
  {
    "target_image": "15Burliuk.jpg",
    "responses": "Otherwordly, fantastical, mystical,",
    "row": 4403,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 757936
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "Dim, mysterious, somber",
    "row": 4404,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 775942
  },
  {
    "target_image": "15ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "Firey, Angry, Furious",
    "row": 4405,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "15Ingleside.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 792899
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "Light, fun, whimsical",
    "row": 4406,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 805742
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "River-side",
    "row": 4367,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 303490
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "Artistic, abstract, rainbow, colorful",
    "row": 4368,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 340905
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "Alone, Safe, deep colors",
    "row": 4369,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 428369
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "Bright, Rainbow, nature",
    "row": 4370,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 457008
  },
  {
    "target_image": "15Mucha.jpg",
    "responses": "Old Fashioned, Abstract, Neutral",
    "row": 4371,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 514062
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "Deep, Dark, Spooky, Pop of color",
    "row": 4372,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "15Ingleside.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 539523
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "Desert, sky, pale",
    "row": 4373,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "15les-musiciens-1952.jpg",
    "distractorTwo": "15grablegung.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 589987
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "abstract, colourful, light",
    "row": 4334,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 636723
  },
  {
    "target_image": "15Mucha.jpg",
    "responses": "Rough, Bright",
    "row": 4335,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 667690
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "Colourful, Nice, Unique",
    "row": 4336,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 699327
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "Graffiti, Colourful",
    "row": 4337,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 715202
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "Dull, Pixelated, Different",
    "row": 4338,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 748883
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "Different, Animal",
    "row": 4339,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 771738
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "Rock, Dark, Abstract",
    "row": 4340,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 789342
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "sky, light, horizon, travelling, shoreline",
    "row": 4301,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 209274
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "blurry, pastel, skyline",
    "row": 4302,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15Rauschenberg.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 246618
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "bright, pastel, shimmer,light, reflection",
    "row": 4303,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 300434
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "vivid, darkening, blurred, hanging",
    "row": 4304,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 333826
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "pastel, shoreline, hills, blocks",
    "row": 4305,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 385034
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "pale, sweeping clouds, hillside, fluffy",
    "row": 4306,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 444154
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "blurred, bright, clashing, running colours",
    "row": 4307,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 486498
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "crinkled, cool, geometric, van gogh, dusk",
    "row": 4268,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 145749
  },
  {
    "target_image": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "smoggy, descending, drained, lifeless",
    "row": 4269,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 231101
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "warm, sunny, balmy, gilded",
    "row": 4270,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15gladiators-1940.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 294204
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "pastel, soft, pale, sandy",
    "row": 4271,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 347692
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "dank, sad, pearly, muted, drained. cloudy",
    "row": 4272,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 380540
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "kaleidoscope, vibrant, hues, streamers, intricate, fiery",
    "row": 4273,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 503148
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "impressionist, confusing, smudged, overcast",
    "row": 4274,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15RobertCampin.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 527845
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "warm, oil canvas, surreal",
    "row": 4235,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 375805
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "distorted, shaded",
    "row": 4236,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 392852
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "glitch, hue",
    "row": 4237,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 435567
  },
  {
    "target_image": "15Remebrandt.jpg",
    "responses": "surreal, colourful",
    "row": 4238,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15Matisse.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 447838
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "shaded, winter",
    "row": 4239,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 485158
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "shaded, blurred, runny colours",
    "row": 4240,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 504343
  },
  {
    "target_image": "15the-dream-1910.jpg!Large.jpg",
    "responses": "fireworks, toned, grayscale",
    "row": 4241,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 530551
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "fire, hot, chaos, flame, intense",
    "row": 4202,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 259732
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "blurred, hot, flame",
    "row": 4203,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 281507
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "intense, hot, warm",
    "row": 4204,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 305747
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "mysterious, dark, gloomy, blurred",
    "row": 4205,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 335517
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "pastel, gloomy, bland",
    "row": 4206,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 361757
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "light, pastel, blurred",
    "row": 4207,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 464523
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "chaos, colourful, sharp",
    "row": 4208,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15Matisse.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 512419
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "heat, water colour, broad brush, warm, sandy, eruption, wavy",
    "row": 4169,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "15Rauschenberg.jpg",
    "distractorTwo": "15the-dream-1910.jpg!Large.jpg",
    "distractorThree": "15Marquet.jpg",
    "time_elapsed": 200647
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "heave wave, warm, sandy, wavy, atmosphere",
    "row": 4170,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15grablegung.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 229494
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "aurora, wavy, storm, dark, tempest, apocalypse",
    "row": 4171,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 266055
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "jagged, modern, cave art, sharp, sandy, post card",
    "row": 4172,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 297295
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "christmas, jelly fish, wool, beanie, coral",
    "row": 4173,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "15hoffmann.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 322296
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "warm, heat wave, sandy, fire, coals, radiating",
    "row": 4174,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 342199
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "night sky, reflection, city lights, sunset, sunrise, storm clouds",
    "row": 4175,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 366983
  },
  {
    "target_image": "15Remebrandt.jpg",
    "responses": "dark, brooding, broken, ethereal, surreal, abstract, shadowy, sinister, striking, colourful, warm,",
    "row": 4136,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 231587
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "bright, airy, light, sunny, optimistic, abstract, surreal, landscape, distorted, sketch,",
    "row": 4137,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 295900
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "abstract, surreal, landscape, dark, brooding, ominous, shadowy, negative,",
    "row": 4138,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 360254
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "bright, clourful, contrasting, uplifting, broken,",
    "row": 4139,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "15kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 399241
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "bright, watercolour, rainbow, hue, summery, vibrant, eye-catching, spectrum, palette, fluorescent, illuminating, pastel, tonal, warm,",
    "row": 4140,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15Marquet.jpg",
    "time_elapsed": 472682
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "oceanic, two-tone, abstract, surrealism, landscape,",
    "row": 4141,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 508532
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "warm, pastel, abstract, surrealism, landscape, pastel, colourful, tonal, light, summery,",
    "row": 4142,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 565010
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "checkered, deep, nostalgic, peppered, grimey, skidded, jumbled",
    "row": 4103,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 235386
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "blended, sherbert, blown",
    "row": 4104,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "15Rozanova2.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 283949
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "digital, drafted, maze",
    "row": 4105,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "15Ingleside.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 318126
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "fruity, digitized, mosaic, focus",
    "row": 4106,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 367006
  },
  {
    "target_image": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "cold, stormy, washed out",
    "row": 4107,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 397187
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "downpour, gritty, gloomy",
    "row": 4108,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 446766
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "winterized, shadows, hazy",
    "row": 4109,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 489417
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "dark, rainbow, clear, vivid",
    "row": 4070,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 159940
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "dull, lack of color, sandy",
    "row": 4071,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 180329
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "bright, sharp, defined lines",
    "row": 4072,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 209518
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "swirly, geometric, light",
    "row": 4073,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 236399
  },
  {
    "target_image": "15the-dream-1910.jpg!Large.jpg",
    "responses": "dark, clear bottom half, clustered top half",
    "row": 4074,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 276172
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "wavey sky, rather dull/dark, dark sunset",
    "row": 4075,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 327233
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "unclear, bright, colorful lines, multicolored",
    "row": 4076,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 361815
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "futuristic, blocky, warm-toned, choppy",
    "row": 4037,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 185120
  },
  {
    "target_image": "15the-day-dream-1880.jpg!Large.jpg",
    "responses": "toxic, radioactive, unrealistic, neon",
    "row": 4038,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 243666
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "precise lines, clear,",
    "row": 4039,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 300022
  },
  {
    "target_image": "15ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "blurry, warm toned, hazy,",
    "row": 4040,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 324141
  },
  {
    "target_image": "15grablegung.jpg",
    "responses": "warm toned, blurry, bright, light",
    "row": 4041,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 354495
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "cool toned, pastel, bright, icy",
    "row": 4042,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 374936
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "cool toned, icy, light, clear",
    "row": 4043,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "15kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "15Moholy.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 412359
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "bright, primary palette, eccentric",
    "row": 4004,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 144825
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "muted, linear",
    "row": 4005,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 189742
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "vibrant, bold, brash",
    "row": 4006,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 218515
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "warm, minimalistic",
    "row": 4007,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 240092
  },
  {
    "target_image": "15Richter.jpg",
    "responses": "dark, blurry",
    "row": 4008,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 261262
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "cool, shadowed",
    "row": 4009,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 291759
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "bold, blocky",
    "row": 4010,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 320682
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "bright, explosive, graffiti, colorful, reflective",
    "row": 3971,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 168027
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "dull, sad, dark, depressing",
    "row": 3972,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 190534
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "night, subtle, muted,",
    "row": 3973,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 212269
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "sunset, nostalgic, soft, dreamy,",
    "row": 3974,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15gladiators-1940.jpg",
    "time_elapsed": 235115
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "funky, unreal, wavy",
    "row": 3975,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 257624
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "toxic, poison, fallout",
    "row": 3976,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 280233
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "blurry, scratchy, dark, textured",
    "row": 3977,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 306111
  },
  {
    "target_image": "15Rothko2.jpg",
    "responses": "wavy, disturbing, broken, vibrant",
    "row": 3938,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 124643
  },
  {
    "target_image": "15grablegung.jpg",
    "responses": "warm, hazy, dangerous",
    "row": 3939,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15MaxErnst.jpg",
    "time_elapsed": 146611
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "cold, fragile, crystalline, dark",
    "row": 3940,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15self-portrait-with-brushes-1942.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 171499
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "blurred, pale, soft, subdued",
    "row": 3941,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 189536
  },
  {
    "target_image": "15Cezanne.jpg",
    "responses": "dark, messy, mysterious",
    "row": 3942,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "15Rauschenberg.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 221229
  },
  {
    "target_image": "15dd101419.jpg!Large.jpg",
    "responses": "dark, vivid, magical",
    "row": 3943,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 256249
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "hot, hazy, unfocused",
    "row": 3944,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 287479
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "fall, blury",
    "row": 3905,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 164155
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "wavy, bright, bright",
    "row": 3906,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 216025
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "cool",
    "row": 3907,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 233607
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "warm, mixture of colors, geometry",
    "row": 3908,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 272692
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "cool, painting",
    "row": 3909,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "15kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 294805
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "light, ordinary",
    "row": 3910,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 317599
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "blurry, warm",
    "row": 3911,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 341472
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "Sunset, long, psychedelic, muted",
    "row": 3872,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15Moholy.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 148469
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "Dusk, soft, low-contrast, pastel, watercolor, blurred",
    "row": 3873,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 192366
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "Pointillistic, dotted, dark, low-contrast",
    "row": 3874,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 221585
  },
  {
    "target_image": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "Heavy, mountainous, cloudy",
    "row": 3875,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 253955
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "Dusty, desert, hot, lifeless",
    "row": 3876,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 283166
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "Busy, detailed, gilded",
    "row": 3877,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 306834
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "Vertical brushstrokes, discolored, stained",
    "row": 3878,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 331404
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "dark,shaded,blurry,edgy",
    "row": 3839,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 163540
  },
  {
    "target_image": "15ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "firey,sunset,blurry",
    "row": 3840,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 193688
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "fireworks,bright,clouds,pollution",
    "row": 3841,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 238067
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "soft,pastel,kind,sunrise",
    "row": 3842,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 259620
  },
  {
    "target_image": "15Picasso.jpg",
    "responses": "straight,edgy,overcast,mountains",
    "row": 3843,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 284757
  },
  {
    "target_image": "15Rodchenko1.jpg",
    "responses": "dessert,strong,",
    "row": 3844,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 309894
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "pastel,straight,sunsest",
    "row": 3845,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 344035
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "colorful, vibrant, sharp, energetic, moving, bold, emotional, intense, bright",
    "row": 3806,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 207010
  },
  {
    "target_image": "15Mucha.jpg",
    "responses": "flat, warm, sharp, sparse, subtle, mosaic-like",
    "row": 3807,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 241636
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "messy, warm, blurred, tactile, layered",
    "row": 3808,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 271448
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "tactile, dark, colorful, moving, layered, dense",
    "row": 3809,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 312533
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "broad, bright, colorful, flat, warm, radiant",
    "row": 3810,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 339601
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "cubic, moving, cool, angled",
    "row": 3811,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 371474
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "blur, colorful, bright, varied, layered, soft",
    "row": 3812,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15gladiators-1940.jpg",
    "time_elapsed": 390538
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "bright, colorful, rainbow, soft, fuzzy",
    "row": 3773,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "15Mucha.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 160534
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "saturated, bright, sharp",
    "row": 3774,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 194132
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "soft, pastel, rainbow, fuzzy, light",
    "row": 3775,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 211001
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "blurry, fuzzy, colorful, soft, pastel",
    "row": 3776,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 224563
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "sharp, hard, muted, dark",
    "row": 3777,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 240701
  },
  {
    "target_image": "15the-day-dream-1880.jpg!Large.jpg",
    "responses": "sharp, blurry, dark",
    "row": 3778,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 256988
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "saturated, dim",
    "row": 3779,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 277984
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "bold, thick",
    "row": 3740,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 185564
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "cool, squiggles",
    "row": 3741,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 206757
  },
  {
    "target_image": "15the-dream-1910.jpg!Large.jpg",
    "responses": "dark, tinge,",
    "row": 3742,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 224057
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "dark, autumnal",
    "row": 3743,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 251378
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "hazy, misty, northern lights",
    "row": 3744,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 272360
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "rainbow, hazy",
    "row": 3745,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 293518
  },
  {
    "target_image": "15hoffmann.jpg",
    "responses": "dark dingy, firey",
    "row": 3746,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 304466
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "choppy, muted",
    "row": 3707,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 150840
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "blocky, pastel, soft",
    "row": 3708,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 167861
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "vibrant, sharp",
    "row": 3709,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15Moholy.jpg",
    "distractorThree": "15self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 180411
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "low detail, geometric",
    "row": 3710,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 206232
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "abstract, dark",
    "row": 3711,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 226510
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "light, soft",
    "row": 3712,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 238525
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "soft, muted",
    "row": 3713,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 255818
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "warm, blocky",
    "row": 3674,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 60720
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "hot, fiery",
    "row": 3675,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 77649
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "weird, triangular",
    "row": 3676,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 89719
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "cool",
    "row": 3677,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 104367
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "realistic",
    "row": 3678,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 131014
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "artsy",
    "row": 3679,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 140293
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "abstract, vivid",
    "row": 3680,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 149061
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "dim,gray",
    "row": 3641,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 56820
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "bright, random",
    "row": 3642,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 67434
  },
  {
    "target_image": "15dd101419.jpg!Large.jpg",
    "responses": "night, dim,",
    "row": 3643,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 83592
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "desert",
    "row": 3644,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 306360
  },
  {
    "target_image": "15Burliuk.jpg",
    "responses": "starry,",
    "row": 3645,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 314571
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "random, museum",
    "row": 3646,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 325904
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "unsaturated, summer",
    "row": 3647,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 349116
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "chaotic, blurry, ethereal, motion",
    "row": 3608,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15RobertCampin.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 89307
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "dark, intense, northern lights, colourful, golden hour",
    "row": 3609,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 121993
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "colourful, vivid, bold",
    "row": 3610,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 135695
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "colourful, vivid, deep, intense",
    "row": 3611,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 153938
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "pastel, light, calm, gentle",
    "row": 3612,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 175400
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "dull, intense, monotonous, dim",
    "row": 3613,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 197191
  },
  {
    "target_image": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "intense, nighttime, vivid",
    "row": 3614,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 224455
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "blurry, pastel",
    "row": 3575,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 106759
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "blurry, smooth",
    "row": 3576,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 130242
  },
  {
    "target_image": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "blurry, abstract",
    "row": 3577,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 143808
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "clear, fuzzy,",
    "row": 3578,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 160172
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "clear, rough",
    "row": 3579,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15the-dream-1910.jpg!Large.jpg",
    "distractorThree": "15the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 193038
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "dark, blurry",
    "row": 3580,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 206373
  },
  {
    "target_image": "15Pollock1.jpg",
    "responses": "dark, abstract",
    "row": 3581,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 214808
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "wiggly, desaturated, dark, brushstrokes",
    "row": 3542,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 139563
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "colorful, bright, childish, zany",
    "row": 3543,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "15les-musiciens-1952.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 159454
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "sandy, blown out, highlighted, bright",
    "row": 3544,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 179272
  },
  {
    "target_image": "15Burliuk.jpg",
    "responses": "textured, saturated, impressionistic",
    "row": 3545,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 209922
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "midtone, chunky, peaceful, stormy",
    "row": 3546,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 244321
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, spooky, stormy, night",
    "row": 3547,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15madonna-casini.jpg",
    "time_elapsed": 265886
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "bright, sketchy, outlines",
    "row": 3548,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 293841
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "Hazy, distorted, altered",
    "row": 3509,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 132573
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Warm, brushed",
    "row": 3510,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 147847
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "Sketched, altered",
    "row": 3511,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 162791
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "Colorful, distorted",
    "row": 3512,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 175932
  },
  {
    "target_image": "15Rozanova2.jpg",
    "responses": "Crazy, Swirled",
    "row": 3513,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "15madonna-casini.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 226915
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "Warm, distorted",
    "row": 3514,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 241944
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "Mosaic, distorted",
    "row": 3515,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 252605
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "mazelike, labryinthic, blurred",
    "row": 3476,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 107804
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "faded, dreary, dusty",
    "row": 3477,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15madonna-casini.jpg",
    "time_elapsed": 125111
  },
  {
    "target_image": "15hoffmann.jpg",
    "responses": "dark, nightlike, faded, shadow",
    "row": 3478,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 143314
  },
  {
    "target_image": "15Picasso.jpg",
    "responses": "shattered, bright, rugged",
    "row": 3479,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15Remebrandt.jpg",
    "time_elapsed": 157518
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "colorful, dancing, neon, bright",
    "row": 3480,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 169077
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "blending, colorful, pastel, smudged",
    "row": 3481,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 183105
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "bright, rugged",
    "row": 3482,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "15Mucha.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 199101
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "pastel",
    "row": 3443,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 96051
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "blurred",
    "row": 3444,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15Rozanova2.jpg",
    "time_elapsed": 101556
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "vibrant",
    "row": 3445,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 112642
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "desert-type",
    "row": 3446,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 121445
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "light",
    "row": 3447,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "15kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 135063
  },
  {
    "target_image": "15Rodchenko1.jpg",
    "responses": "light",
    "row": 3448,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 138495
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "iridescent",
    "row": 3449,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15madonna-casini.jpg",
    "time_elapsed": 144711
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "abstract art style, slight blurry, sharped colors",
    "row": 3410,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 534996
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "darkened contrast, distorted shapes, harsh lines",
    "row": 3411,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 681453
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "abstract art style, distorted shapes, slight blurry, soft colors",
    "row": 3412,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 841264
  },
  {
    "target_image": "15the-dream-1910.jpg!Large.jpg",
    "responses": "patterns, dark contrast",
    "row": 3413,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 975384
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "colorful, patterns, abstract art, a little blur, bold lines, soft light",
    "row": 3414,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 1157053
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "dull colors, slight blur, abstract art style, bold lines",
    "row": 3415,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1334230
  },
  {
    "target_image": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "dark tones, bold lines",
    "row": 3416,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1459194
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "polaroid, cartoon",
    "row": 3377,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15Marquet.jpg",
    "time_elapsed": 338542
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "blended, blurry",
    "row": 3378,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 358767
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "aurora",
    "row": 3379,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 431610
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "bright, realistic, dark",
    "row": 3380,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 474323
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "pastel, sharp",
    "row": 3381,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 486055
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "chalk, sharp",
    "row": 3382,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 499615
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "colourful, sandy",
    "row": 3383,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 530511
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "Mottled, Grainy, Pastel, Speckled, Magic Eye,",
    "row": 3344,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15self-portrait-with-brushes-1942.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 571581
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "Dark, Mustard, Grainy, Old fashioned",
    "row": 3345,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "15Rauschenberg.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 670545
  },
  {
    "target_image": "15Richter2.jpg",
    "responses": "Monochrome, Newspaper cuttings, Steel",
    "row": 3346,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15the-dream-1910.jpg!Large.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 813388
  },
  {
    "target_image": "15Rozanova2.jpg",
    "responses": "Mountains from above, stone sky,",
    "row": 3347,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 922004
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "Maze sky, Sunset,",
    "row": 3348,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 1014233
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "Dark, Evil sky, Clear Street,",
    "row": 3349,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "15portrait-of-daughter-1912.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 1090977
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "Cherry, Peach, Scratchy",
    "row": 3350,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 1228505
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "blurry, menacing, cold, wintery",
    "row": 3311,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15RobertCampin.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 282114
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "hazy, summery, dreamlike, glowing, pastel",
    "row": 3312,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 726954
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "mosaic, light, sunny, warm, pleasant",
    "row": 3313,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15Kline2.jpg",
    "distractorThree": "15city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 964216
  },
  {
    "target_image": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "ominous, brooding, twilight, dark, cold, wet, windy",
    "row": 3314,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 997929
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "glowing, turner, shimmer",
    "row": 3315,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15Rauschenberg.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1199727
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dark, cold, rainy, gloomy, wet, wintery",
    "row": 3316,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 1255576
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "surreal, overcast, scary, otherworldly, mesmerising",
    "row": 3317,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 1483776
  },
  {
    "target_image": "15Cezanne.jpg",
    "responses": "exotic, tropical, stormy, abstract, warm",
    "row": 3278,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15grablegung.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 499334
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "sandy, burnt, blurry, cloudy, warm, thundery",
    "row": 3279,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 653584
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "cool, crisp, icy, subtle, haze",
    "row": 3280,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 744020
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "vivid, bright, crystal, clear, warm. delight",
    "row": 3281,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 818921
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "mosaic, sketch, warm, aged, textured",
    "row": 3282,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 927852
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "bright, sunny, vivid, bold, warmth",
    "row": 3283,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 980770
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "spring, pointism, hazy, mystical, dew, blur",
    "row": 3284,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 1163656
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "abstract",
    "row": 3245,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1757995
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "cool",
    "row": 3246,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 1765157
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "warm",
    "row": 3247,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 1770809
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "warm",
    "row": 3248,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 1775543
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "abstract",
    "row": 3249,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 1784775
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "busy",
    "row": 3250,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 1790307
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "warm",
    "row": 3251,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 1795113
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "colorful, multicolor, mosaic",
    "row": 3212,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 562945
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "soft, bright, colorful",
    "row": 3213,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15Moholy.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 615654
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "deep colored, smoth, soft",
    "row": 3214,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 638094
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "grey scaled, mild, ashey",
    "row": 3215,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 715981
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "dark, blurry,",
    "row": 3216,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 746155
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "dark colored,",
    "row": 3217,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 954526
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "outlined, creamy",
    "row": 3218,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 1021235
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Vibrant, warm, Energetic, Complementary composition",
    "row": 3179,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "15madonna-casini.jpg",
    "distractorTwo": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 593240
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "Cartoony, 2D outline, Warm, pastel colour palette",
    "row": 3180,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15Rauschenberg.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 707718
  },
  {
    "target_image": "15Burliuk.jpg",
    "responses": "Dark, streched edge strokes,",
    "row": 3181,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 834341
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "chaotic colours, contrast, sharp image,2D outline, feint",
    "row": 3182,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15Matisse.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 927576
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "Bland, warm, use of complementary colours, earthy colours,",
    "row": 3183,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 1008898
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "2D outline, sharp image, high contrast, stylized colours, complimentary",
    "row": 3184,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1059912
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "Bright, warm, earthy, high contrast, Morning sunrise",
    "row": 3185,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 1123303
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "heavens erupting in colour compressed vehicle,",
    "row": 3146,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 221343
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "multi colour, distinct, unhighlighted, mess,",
    "row": 3147,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 289687
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "undefined, dark, oppressive, downwards inclination",
    "row": 3148,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 372831
  },
  {
    "target_image": "15Mucha.jpg",
    "responses": "poor definition, mishmash, monocolour, background house,",
    "row": 3149,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 496997
  },
  {
    "target_image": "15Richter.jpg",
    "responses": "rainclouds, dark, indistinct, blurred,",
    "row": 3150,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 556916
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "squashed, dull, lengths, tubes,",
    "row": 3151,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 659163
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "squashed, dull, lengths, tubes,",
    "row": 3152,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 699226
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "coastal, riverside, driveby.",
    "row": 3113,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 513457
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "lemon, riverside, driveby",
    "row": 3114,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15self-portrait-with-brushes-1942.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 578336
  },
  {
    "target_image": "15Rozanova2.jpg",
    "responses": "pastel sky, riverside, driveby",
    "row": 3115,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "15kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "15Moholy.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 616184
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "modern, riverside, driveby.",
    "row": 3116,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 649464
  },
  {
    "target_image": "15Rothko2.jpg",
    "responses": "graffiti sky, riverside, driveby.",
    "row": 3117,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 683935
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "riverside, driveby, abstract",
    "row": 3118,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15the-dream-1910.jpg!Large.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 751448
  },
  {
    "target_image": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "melancholy, depressed, riverside driveby",
    "row": 3119,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 804122
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "new age, metallic, cool shades, mushroom like shapes in the air, true to life depicition of the car and road",
    "row": 3080,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 184732
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "still life of the car, metallic colours in the sky, a rainfall of rocks descending from the sky with occasional hint of colour",
    "row": 3081,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 247596
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "bright colourful depiction of the sky, swirling mass of colours above the car, slight reflection on the road of the colours shown above on the sky",
    "row": 3082,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 308431
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "the sky looks textured, like a furry blanket, with lots of bright colours, the car and the road are all painted in a normal form, the sun setting in the background is show is in different contrasting colours",
    "row": 3083,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "15les-musiciens-1952.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 371345
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "The background of the sun is shown as texture coming down from the sun, as folds of velvets, though these folds are more the colour of mustard and soft sand that you find on the beach. The car in the foreground is pictured realistically sitting on the road.",
    "row": 3084,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 446333
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "This picture has a much more striking depiction of the sky, it is shown in bright volcanic colours, with part of the sunset being shown as a volcano, erupting from the sea in a clash of colours. The rest of the sky lends in well with the colour.",
    "row": 3085,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 516314
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "Everything in this picture is mostly depicted in blocks, more nouveau art, with teh sky being shown in a series of interlocking blocks, different colours, but shades are consistent with concrete and silver, to weave together a sky of blocks.",
    "row": 3086,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 719636
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "detailed, shadow, colourful, dark",
    "row": 3047,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 194790
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurred, cold, bright, tonal",
    "row": 3048,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 210768
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "detailed, warm, shadow, clear, bright",
    "row": 3049,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15Moholy.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 237997
  },
  {
    "target_image": "15Burliuk.jpg",
    "responses": "warm, midnight, bright, shadow",
    "row": 3050,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 268759
  },
  {
    "target_image": "15Pollock1.jpg",
    "responses": "gloomy, shadow, detailed, warm",
    "row": 3051,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 304095
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "pastel, shadow, warm",
    "row": 3052,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15grablegung.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 380628
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "dark, midnight, shadow",
    "row": 3053,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 392002
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "kaleidoscopic, saturated",
    "row": 3014,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 166668
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "dirty, dull, rusty",
    "row": 3015,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 211014
  },
  {
    "target_image": "15Cezanne.jpg",
    "responses": "warm, earthy,",
    "row": 3016,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 276998
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "cubed, psychedelic, prismed,",
    "row": 3017,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 361131
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "summery, fiery, smoldering",
    "row": 3018,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 415970
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "flat, simple, abstract, bright",
    "row": 3019,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "15hoffmann.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 457191
  },
  {
    "target_image": "15Klimt1.jpg",
    "responses": "dissolving, warm, blurry",
    "row": 3020,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 505533
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "bright, colourful, vivid, contrasting, picturesque, cooler colours dominant",
    "row": 2981,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15portrait-of-daughter-1912.jpg",
    "distractorThree": "15Remebrandt.jpg",
    "time_elapsed": 231467
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "dark, gloomy, depressing, apocalyptic, sharp, clear, vivid",
    "row": 2982,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 311417
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurry, singular, sand-like, monotone, warm colour dominant",
    "row": 2983,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 373649
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "picturesque, vivid, multi-tone, multi-coloured, fragmented",
    "row": 2984,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 433194
  },
  {
    "target_image": "15grablegung.jpg",
    "responses": "mono-tone, mono-chrome, warm, sun-like, summerish, desert-like",
    "row": 2985,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15gladiators-1940.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 482156
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "bloody, warm, explicit, vivid",
    "row": 2986,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 534373
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, gloomy, blurry, fuzzy, cold, rain-like, waterish",
    "row": 2987,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 577274
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "very coloured, in focus, late afternoon",
    "row": 2948,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 215553
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "different colours, just out of focus",
    "row": 2949,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "15Ingleside.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 264506
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "very coloured, car hardly visablewhole picture similar",
    "row": 2950,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 335015
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "car in focus, multiple colours",
    "row": 2951,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 381035
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "twilight, not quite dark, verticle",
    "row": 2952,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 432188
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "vivid, rounded features, late afternoon",
    "row": 2953,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 490099
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "bright, light colours, blocky",
    "row": 2954,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 519488
  },
  {
    "target_image": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "dark, blurry, obscured",
    "row": 2915,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 205187
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "light, pastel, slightly blurred",
    "row": 2916,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 248073
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "Light colours, blurred, bright",
    "row": 2917,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 301421
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "bright burst of colours",
    "row": 2918,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 332646
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "warm, bright,",
    "row": 2919,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 388093
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "dark but colourful, chaotic",
    "row": 2920,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 432521
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "light colours,",
    "row": 2921,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 452540
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "darker, somewhat sharp, still vibrant, bold",
    "row": 2882,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 167431
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "dotty short strokes, still vibrant and somewhat dark but maybe more middle of the road light and dark",
    "row": 2883,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 228957
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "brighter, more wavy but still pointed lines,",
    "row": 2884,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 257246
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "morning, sharper with some pointedness",
    "row": 2885,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "15madonna-casini.jpg",
    "time_elapsed": 304913
  },
  {
    "target_image": "15Mucha.jpg",
    "responses": "picasso-esque, burnt, complex",
    "row": 2886,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 340509
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "muted vibrancy, somewhat wavy, mixed colors",
    "row": 2887,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 389387
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "sand dunes, very muted, dull",
    "row": 2888,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 409951
  },
  {
    "target_image": "15Richter.jpg",
    "responses": "smokey, dusk, realistic, cloudy",
    "row": 2849,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 162736
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "autumnal, bittersweet",
    "row": 2850,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15Kline1.jpg",
    "time_elapsed": 257735
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "early evening, rainbow hued, clear",
    "row": 2851,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 294807
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "vernal, lonely, warm toned",
    "row": 2852,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 373295
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "hazy, aurora,",
    "row": 2853,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 393103
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "fractured, angular, crisp",
    "row": 2854,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 413528
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "clear, impressionistic, bright",
    "row": 2855,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 438031
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "dull, smudged",
    "row": 2816,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 137437
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "bizarre, rainbow, blurred",
    "row": 2817,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 167715
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "jagged, blocky, smudged",
    "row": 2818,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 186232
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "Mountainous, clean, jagged",
    "row": 2819,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 238595
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "abstract, unique, autumnal, colourful",
    "row": 2820,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "15portrait-of-daughter-1912.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15madonna-casini.jpg",
    "time_elapsed": 274776
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "dark, pastel, rugged",
    "row": 2821,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 301239
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "bizarre, abstract, messy",
    "row": 2822,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 338874
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "bloody, loud, dark, equal",
    "row": 2783,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 92226
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "cubed, light, contrasting, pale, cold",
    "row": 2784,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 108825
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "dark, cold, blurred, charred, mysterious",
    "row": 2785,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 131180
  },
  {
    "target_image": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "contrasting, loud, odd, mixed, sharp",
    "row": 2786,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 148315
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "contrasting, bright, sharp, blurred, loud, clear, sunny",
    "row": 2787,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 163194
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "muted, blurred, bright, warm, interesting",
    "row": 2788,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 174766
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "pale, pastel, light, colourful, pretty, faded",
    "row": 2789,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 191700
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "saturated, vibrant, colourful, busy, bright, dreamlike, trippy, matted, patchwork",
    "row": 2750,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 455750
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "Bright, hazy, waterfall, streamlike, mountainous, canyons, desert, bright, cavernous",
    "row": 2751,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 1068156
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "Uneven brickwork, structural, geometric, tall, buildings, square, rectangular",
    "row": 2752,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 1153898
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "pyramidal, intense, cool, watery, calm, fantastical, optimistic",
    "row": 2753,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 1270377
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "Bright, cool, structured, passionate, vertical,",
    "row": 2754,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 1426788
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "Rocky, hard, cool, a warm winter day, detailed, hi res",
    "row": 2755,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15portrait-of-daughter-1912.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 2385041
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "warm, cloudy, pastel, round, feverish, biohazard, nuclear, eerie,",
    "row": 2756,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 2568726
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "pastel",
    "row": 2717,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 81827
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "desert",
    "row": 2718,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 102289
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "church",
    "row": 2719,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 117569
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "savannah",
    "row": 2720,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 124038
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "bleeding",
    "row": 2721,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 127903
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "sandy",
    "row": 2722,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 132264
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "scripture",
    "row": 2723,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 138271
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "muted, overcast, dark",
    "row": 2684,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15Matisse.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 408605
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "van gogh, sun reflecting off ice, art pop",
    "row": 2685,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "15hoffmann.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 530232
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "Devils sky, stone, metallic",
    "row": 2686,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 676022
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "vibrant, water colour, splash, warm",
    "row": 2687,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 839191
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "blurry, smudge, vibrant, carnival, feathered",
    "row": 2688,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "15Rozanova2.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 1001958
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "tree, autumn, sphere, vibrant, sharp",
    "row": 2689,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15Kline2.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 1183780
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Desert, bright, heat",
    "row": 2690,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 1210731
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "smooth, uniform, hazy, cozy",
    "row": 2651,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "15les-musiciens-1952.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 288098
  },
  {
    "target_image": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "sharp, distorted, graffiti, bold, dark",
    "row": 2652,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 373143
  },
  {
    "target_image": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "night, dark, menacing, surreal, cold, cool",
    "row": 2653,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15MaxErnst.jpg",
    "time_elapsed": 462477
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "pastel, blotchy, vista, wintery, religious, cool, calm",
    "row": 2654,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15Kline2.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 582405
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "colorful, hyper, bright, festive, bold, surreal",
    "row": 2655,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 627405
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "line art, cool, sharp, pastel, surreal, bright, abstract",
    "row": 2656,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 687892
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "blocky, smeared, colorful, linear, streaked, edgy, sharp, dark",
    "row": 2657,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 743526
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "Very blurred and impressionist, brightly lit and sunny, dazzling and almost watery, like a reflection in a lake",
    "row": 2618,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15RobertCampin.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 446826
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "The sky very granular like multi-coloured heather above a dark, dim foreground",
    "row": 2619,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 567061
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "Hot autumn colours, an impression of speed, and the sky full of a confused tangle of what look like half-seen skyscrapers",
    "row": 2620,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "15Rauschenberg.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 640474
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "Very bright, jewel-like colours, quite dark and yet saturated with light like a stained-glass window seen from a dark interior",
    "row": 2621,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 704698
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "Hot desert colours, fairly sharp in the foreground and with towering dark shapes stretching away in the sky",
    "row": 2622,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 771760
  },
  {
    "target_image": "15Richter2.jpg",
    "responses": "Almost monochrome, very pale and looks as if constructed from short sharp dabs of paint",
    "row": 2623,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 815649
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "Dark and very grainy, spackled with moorland colours",
    "row": 2624,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 870377
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "warm, glowing, straw, sandy",
    "row": 2585,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 418009
  },
  {
    "target_image": "15grablegung.jpg",
    "responses": "windy, warm, glow, sandy, sunny",
    "row": 2586,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 506778
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "dark, stormy, chaotic, moody, snowy",
    "row": 2587,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-daughter-1912.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 641848
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "bright, beautiful, colourful, spectacular, rainbow",
    "row": 2588,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 697240
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "bleak, snowy, cold, icy, freezing",
    "row": 2589,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 725823
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "snow, iceblocks, angelic, pure, jagged",
    "row": 2590,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 843854
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "ambient, calm, quite, comforting, relaxed",
    "row": 2591,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 896732
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "muted colors, pastel earth tones, blurred, soft",
    "row": 2552,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 370675
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "bright, neon colors, fuzzy, warm, sunny",
    "row": 2553,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 443152
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "abstract shapes, colorful, bright, distinct lines, vibrant",
    "row": 2554,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 518875
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "dark, muted, cool colors, fuzzy, ashy",
    "row": 2555,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 613088
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "bright, colorful, abstract, blurred, warm colors, bold colors",
    "row": 2556,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 719392
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "distinct lines, bright, sunny",
    "row": 2557,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 856598
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dark, muted, cool colors, blurred, stormy",
    "row": 2558,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 914469
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "sharp, clear,straight lines on the top half that are very distinct and sharp",
    "row": 2519,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 477693
  },
  {
    "target_image": "15hoffmann.jpg",
    "responses": "dark, Grim, hellish landscape, focus on Dual colors besides the car.",
    "row": 2520,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 515309
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "rust or molded bread pallet, a little bit on the darker side, and less Sharp",
    "row": 2521,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 609029
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "one single color appears to be shining behind the background of the sky., a heavenly peaceful horizon, soft, pleasantly beautiful, daytime",
    "row": 2522,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 683308
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "loud, sudden Bloch in the center with dual colors, vacant top left and right corners both matching colors, dark, nighttime,, details are smudged",
    "row": 2523,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 781205
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "beautiful and clear, wide curving Strokes, the sky is detailed and so clear that you can make out images such as smiley faces or frowny faces",
    "row": 2524,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 878201
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "pale, simple, midday, undetailed, only dual colored mainly, the one that looks the least like graffiti but it's also less colorful",
    "row": 2525,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "15portrait-of-daughter-1912.jpg",
    "distractorTwo": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "15Rozanova2.jpg",
    "time_elapsed": 961238
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "blocky, angular, muted",
    "row": 2486,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 299885
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "smudged, misty, bright,",
    "row": 2487,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 391009
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "pale, wishy washy, dull",
    "row": 2488,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15grablegung.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 460325
  },
  {
    "target_image": "15Richter2.jpg",
    "responses": "colourless, blocky, monochrome",
    "row": 2489,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "15Mucha.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 541838
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "splodgey, sunny, pale",
    "row": 2490,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 679260
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "blotchy, unclear,",
    "row": 2491,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 842658
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "abstract, messy, multicolour",
    "row": 2492,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 918015
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "scrunched, mountain like sky",
    "row": 2453,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 161116
  },
  {
    "target_image": "15Pollock1.jpg",
    "responses": "cool, scrunched",
    "row": 2454,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "15kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 208972
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "lower contrast",
    "row": 2455,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 280861
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "bright, colorful, vibrant",
    "row": 2456,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "15self-portrait-with-brushes-1942.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 316837
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "tanned, crisp",
    "row": 2457,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 351092
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "dark, dull",
    "row": 2458,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 399708
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "morphed, unusual, nauseated",
    "row": 2459,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 432636
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "geometric, cubist, delineated",
    "row": 2420,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 253865
  },
  {
    "target_image": "15Remebrandt.jpg",
    "responses": "wispy, bold, stark",
    "row": 2421,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 329575
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "abstract, dark, monochromatic, dull, drab",
    "row": 2422,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 372185
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "cubist, ribbon-like, pastel, sunset-inspired",
    "row": 2423,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 413481
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "bright, rich, jewel-toned, dramatic, bold, puffy",
    "row": 2424,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 446575
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "light, faded, fuzzy",
    "row": 2425,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 484854
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "Impressionist, monochromatic, abstract, interpreted",
    "row": 2426,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 538991
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "BRIGHT, COLOURFUL, RELAXED",
    "row": 2387,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15Rauschenberg.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 231013
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "WARM, DESERT, MUSK, FIRE",
    "row": 2388,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15Matisse.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 256102
  },
  {
    "target_image": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "STRANGE, COLD, THUNDER",
    "row": 2389,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "15Mucha.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 337716
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "THOUGHT, MIND, WORLD, HAPPPINESS",
    "row": 2390,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 356604
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "THOUGHT, DUSK",
    "row": 2391,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 416009
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "ART, THOUGHT, SQUARES",
    "row": 2392,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "15Rozanova2.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 480771
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "COLOURFUL, HAPPINESS, PEACE",
    "row": 2393,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 520977
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dull, gloomy, boring",
    "row": 2354,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 79047
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "crazy, disfigured, explosive",
    "row": 2355,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 104026
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "blocky, futuristic, washed out",
    "row": 2356,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 147807
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "blurry, unclear, mystical, night time",
    "row": 2357,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15Rauschenberg.jpg",
    "distractorThree": "15city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 186002
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "warm, sunset, dark, vibrant",
    "row": 2358,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 212264
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "abstract, picasso-eske, summer",
    "row": 2359,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 241318
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "high contrast, moody, sunset",
    "row": 2360,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 298673
  },
  {
    "target_image": "15Pollock1.jpg",
    "responses": "dark",
    "row": 2321,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 527672
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "lights, colorful",
    "row": 2322,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 538841
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "dust",
    "row": 2323,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 554860
  },
  {
    "target_image": "15the-dream-1910.jpg!Large.jpg",
    "responses": "forest",
    "row": 2324,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15Rozanova2.jpg",
    "time_elapsed": 583847
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "design",
    "row": 2325,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 594462
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "soft, feathery",
    "row": 2326,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 611876
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "dark",
    "row": 2327,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 633050
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "Autumn vibes",
    "row": 2288,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15Rozanova2.jpg",
    "time_elapsed": 237630
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Blazing Fire",
    "row": 2289,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 294770
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "Cool breezes",
    "row": 2290,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 315608
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "City Nights",
    "row": 2291,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 339845
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "mosaic tiles",
    "row": 2292,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 360043
  },
  {
    "target_image": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "Icey",
    "row": 2293,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 386953
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "amber horizon",
    "row": 2294,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 434623
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "brushstrokes, violent, harsh, angry",
    "row": 2255,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 170896
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "cheerful, wonder, childlike, vibrant, trippy",
    "row": 2256,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 206967
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "muted, blurry, tense",
    "row": 2257,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 259481
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "cubic, colorful,",
    "row": 2258,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "15Rozanova2.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 293479
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "bright, sickly, polluted",
    "row": 2259,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 347988
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "grainy, surreal, snowy,",
    "row": 2260,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 395796
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "overexposed, bright, fiery, passionate",
    "row": 2261,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 418179
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "Chaotic, cool, winter",
    "row": 2222,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 133335
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Warm, fire, bold, bright",
    "row": 2223,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 152970
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "Brush-strokes, bold, bright, nature",
    "row": 2224,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 191615
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "Ominous, fire, hot, sweat",
    "row": 2225,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 211834
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "Nostalgic, cool, dull, sandy",
    "row": 2226,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 235152
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "Colourful, jewels, aurora, crisp",
    "row": 2227,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15Remebrandt.jpg",
    "time_elapsed": 288197
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "Boxy, nostalgic, bright",
    "row": 2228,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 332474
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "abstract, chaotic, messy, colorful, mixture, blended",
    "row": 2189,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "15les-musiciens-1952.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 232711
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "dull, muted, warm, simple",
    "row": 2190,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 287951
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "ocean like, blend, mixture, combination, swirls",
    "row": 2191,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15portrait-of-daughter-1912.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 325405
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "peacock feathers, dull but flashy",
    "row": 2192,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 383737
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "bright, flashy, warm, very clear",
    "row": 2193,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 406031
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, flame like, dull",
    "row": 2194,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 423335
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "blobs, darker, warm",
    "row": 2195,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 467744
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "fuzzy, warm, hazy",
    "row": 2156,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 105769
  },
  {
    "target_image": "15the-dream-1910.jpg!Large.jpg",
    "responses": "crisp, dark, sharp",
    "row": 2157,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 137550
  },
  {
    "target_image": "15Pollock1.jpg",
    "responses": "pastel, cool, contrast",
    "row": 2158,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 166100
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "dark, warm, angled",
    "row": 2159,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "15Rauschenberg.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 181709
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "retro, cool, clear",
    "row": 2160,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "15madonna-casini.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 208881
  },
  {
    "target_image": "15hoffmann.jpg",
    "responses": "dark, ominous, blurred",
    "row": 2161,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 226309
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "warm, clear, light",
    "row": 2162,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 252458
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "archnoid, spectrum, paint, abstract, light",
    "row": 2123,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 280127
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "grunge, mosaic, loud, warm",
    "row": 2124,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "15Rozanova2.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 307289
  },
  {
    "target_image": "15dd101419.jpg!Large.jpg",
    "responses": "dark, gloomy, night, cold, silent",
    "row": 2125,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 332781
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "blinding, loud, chipper, grain",
    "row": 2126,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "15Kline1.jpg",
    "time_elapsed": 349628
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "smooth, soft, pastel",
    "row": 2127,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 361993
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "blocky, loud, rainbow, concrete, firm",
    "row": 2128,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "15Mucha.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 389275
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "spectrum, zodiac, hard, tame, loud",
    "row": 2129,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15Marquet.jpg",
    "time_elapsed": 414892
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "defined,  faded, old, sepia",
    "row": 2090,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 168011
  },
  {
    "target_image": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "defined, faded, sepia, vertical, lines",
    "row": 2091,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 205233
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "colourful, blocky, sunset, evening, dark, lines",
    "row": 2092,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 271951
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "dreamy, stained glass, northern lights, cool",
    "row": 2093,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15Remebrandt.jpg",
    "time_elapsed": 305651
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "dark, blurry, warm, blocky, glow, evening",
    "row": 2094,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 335587
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "warm, blocky, graphic, sunny, summer, bright",
    "row": 2095,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 368987
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "warm, blocky, defined, glow, sunset",
    "row": 2096,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 388436
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "dreary, bland, pixilated, warped, pastel, dark",
    "row": 2057,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 166819
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "abstract, geometric, primary",
    "row": 2058,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 197692
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "cool, snowy, pixilated, blurry",
    "row": 2059,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 248645
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "cool, icy",
    "row": 2060,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 276859
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "warm, blurry, sandy, pastel",
    "row": 2061,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 307549
  },
  {
    "target_image": "15hoffmann.jpg",
    "responses": "dark, dreary, hell",
    "row": 2062,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 327274
  },
  {
    "target_image": "15Rozanova2.jpg",
    "responses": "cool, whimsical",
    "row": 2063,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 367676
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "fire, bright, colourful, flame, intense",
    "row": 2024,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 200823
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "muted, pop of colour, rainbow, dull",
    "row": 2025,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 228942
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "futuristic, blocky, square",
    "row": 2026,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 255667
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "sunset, pastel, calming",
    "row": 2027,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 317441
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "maze, sketch, rainbow, lines, paint stroke",
    "row": 2028,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 335623
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "warped, dark, moody",
    "row": 2029,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15Rozanova2.jpg",
    "time_elapsed": 357532
  },
  {
    "target_image": "15Richter.jpg",
    "responses": "blurred, soft, dark",
    "row": 2030,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 387153
  },
  {
    "target_image": "15Pollock1.jpg",
    "responses": "erratic",
    "row": 1991,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 223878
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "moody",
    "row": 1992,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 234067
  },
  {
    "target_image": "15Rothko2.jpg",
    "responses": "vibrant",
    "row": 1993,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 244609
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "overwhelm",
    "row": 1994,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 261213
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "twilight",
    "row": 1995,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15Kline2.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 287460
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "vivid",
    "row": 1996,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 312669
  },
  {
    "target_image": "15ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "warm",
    "row": 1997,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 349512
  },
  {
    "target_image": "15Cezanne.jpg",
    "responses": "wavy, stripy,",
    "row": 1958,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 120825
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "stormy, rough,",
    "row": 1959,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 144225
  },
  {
    "target_image": "15Rodchenko1.jpg",
    "responses": "animalistic, warm,",
    "row": 1960,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 167561
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "dark, moody, staticky,",
    "row": 1961,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15Moholy.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 205194
  },
  {
    "target_image": "15ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "warm, animalistic, fiery",
    "row": 1962,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 222353
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "blocky, warm,",
    "row": 1963,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 251402
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "saticky, faded,",
    "row": 1964,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 270097
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "light, uplifting",
    "row": 1925,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 107742
  },
  {
    "target_image": "15Richter2.jpg",
    "responses": "mono boxing",
    "row": 1926,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 124078
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "alien haze",
    "row": 1927,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 135382
  },
  {
    "target_image": "15Remebrandt.jpg",
    "responses": "heavenly crayon",
    "row": 1928,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 157062
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "Baby pastel",
    "row": 1929,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "15Mucha.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 172566
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "primary bright",
    "row": 1930,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 186174
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "pretty pica",
    "row": 1931,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 230718
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "lines, blurry, road",
    "row": 1892,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 213853
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "warm, squiggly",
    "row": 1893,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 228719
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "zigzag, blurry, abstract",
    "row": 1894,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 245703
  },
  {
    "target_image": "15the-day-dream-1880.jpg!Large.jpg",
    "responses": "lots of designs, blurry",
    "row": 1895,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 265038
  },
  {
    "target_image": "15Picasso.jpg",
    "responses": "blurry, lines, zigzag",
    "row": 1896,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 290913
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "lots of lines, squares",
    "row": 1897,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 310847
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "moist, blurry, road",
    "row": 1898,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 335394
  },
  {
    "target_image": "15Rothko2.jpg",
    "responses": "night",
    "row": 1859,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 160146
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "swift",
    "row": 1860,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15Matisse.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 181610
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "slight",
    "row": 1861,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 193514
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "horizon",
    "row": 1862,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 217468
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "scape",
    "row": 1863,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "15gladiators-1940.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 224508
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "road",
    "row": 1864,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 239910
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "evening",
    "row": 1865,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 247298
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "vibrant, angular, multicolored",
    "row": 1826,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 121145
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "warm, jagged, sunset",
    "row": 1827,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15grablegung.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 145713
  },
  {
    "target_image": "15Richter2.jpg",
    "responses": "monotone, cubic, dusk",
    "row": 1828,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 175193
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "fuzzy, warm, beach",
    "row": 1829,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 202642
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "angular, warm, beach",
    "row": 1830,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "15Rozanova2.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 220448
  },
  {
    "target_image": "15dd101419.jpg!Large.jpg",
    "responses": "cool, dark, night, road",
    "row": 1831,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 231258
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "rainbow, vibrant, sky",
    "row": 1832,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 245214
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "warm, fiery,",
    "row": 1793,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 106069
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "pastel, dreamy",
    "row": 1794,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "15madonna-casini.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15Kline1.jpg",
    "time_elapsed": 112380
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "dark, earthy",
    "row": 1795,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 124703
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "dark, pixelated, gritty,",
    "row": 1796,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 159882
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "bright,",
    "row": 1797,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 166343
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "colorful,bright,",
    "row": 1798,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 175607
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "earthy, rustic",
    "row": 1799,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 182937
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "tie dye",
    "row": 1760,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 96742
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "fruity",
    "row": 1761,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 103166
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "scorched",
    "row": 1762,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "15madonna-casini.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 113487
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "oceanic",
    "row": 1763,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 123455
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "psychadelic",
    "row": 1764,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 129675
  },
  {
    "target_image": "15Burliuk.jpg",
    "responses": "rainbow",
    "row": 1765,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "15Mucha.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 134858
  },
  {
    "target_image": "15Remebrandt.jpg",
    "responses": "nachos",
    "row": 1766,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15Kline2.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 141881
  },
  {
    "target_image": "15Klimt1.jpg",
    "responses": "hazy, warm, soft",
    "row": 1727,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 5630441
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "harsh, cubist, motion, bold",
    "row": 1728,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 5653596
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "abstract, cold, energetic",
    "row": 1729,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 5672348
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "soft, warm, slow, wistful",
    "row": 1730,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 5692686
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "rough, gloomy, depressing, soft",
    "row": 1731,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 5705136
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "bright, optimistic, vibrant, busy, light",
    "row": 1732,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 5725700
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "aggressive, dark, depressing, harsh",
    "row": 1733,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 5736450
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "fiery, rough, aggressive, bold",
    "row": 1694,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 476701
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "soft, distorted",
    "row": 1695,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 546575
  },
  {
    "target_image": "15Burliuk.jpg",
    "responses": "colourful, beautiful, dazzling, magical, luminous",
    "row": 1696,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 592108
  },
  {
    "target_image": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "dark, atmospheric, enchanting",
    "row": 1697,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 655568
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "distorted, soft, bright, atmospheric, artistic",
    "row": 1698,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 687845
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "bright, weird, distorted, blurred, soft",
    "row": 1699,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "15Ingleside.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15Rozanova2.jpg",
    "time_elapsed": 715640
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "blurred, distorted, soft, light, peaceful",
    "row": 1700,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 763975
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "soft, gentle, quite, blurred, fuzzy, calm,",
    "row": 1661,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 277510
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "spiky, rainbow, magical, multicoloured",
    "row": 1662,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15Klimt1.jpg",
    "time_elapsed": 357671
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "deep, calm, sunset,",
    "row": 1663,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 416478
  },
  {
    "target_image": "15hoffmann.jpg",
    "responses": "dark, scary, night, angry, storm, danger,",
    "row": 1664,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 451597
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "clear, night sky, stars, calm, relaxing,",
    "row": 1665,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15gladiators-1940.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 482253
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "bright, sunny, relaxing, happy, warm",
    "row": 1666,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 517148
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "smooth, soft, block, calm, sunset, warm, happy",
    "row": 1667,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 576747
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "thick strokes, warm, bold outlines, pastel rainbow colours",
    "row": 1628,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 180502
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "warm colours, muddy but bright, fiery",
    "row": 1629,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "15les-musiciens-1952.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15Kline1.jpg",
    "time_elapsed": 278650
  },
  {
    "target_image": "15Mucha.jpg",
    "responses": "hazy, dusky, sunshine, thin hark outlines",
    "row": 1630,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 318233
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "all colours, bold, bright, defined shapes",
    "row": 1631,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 369933
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "warm muddy  tones, only slight fiery colour in the top half",
    "row": 1632,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 452979
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "bland colourless muddy tones, washed out sky",
    "row": 1633,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "15self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 497339
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "rainbow colours, throughout , hardy any sky definition, leopard print sky",
    "row": 1634,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "15kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 690043
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "sharp, a mostly unblurred upper half that is pale",
    "row": 1595,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 165174
  },
  {
    "target_image": "15Klimt1.jpg",
    "responses": "little color, static",
    "row": 1596,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 188664
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "watery road, colorful upper",
    "row": 1597,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15MaxErnst.jpg",
    "time_elapsed": 219846
  },
  {
    "target_image": "15ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "one colour dominating, almost words in the upper half",
    "row": 1598,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 248718
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "flower like in the upper, dark below",
    "row": 1599,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 271952
  },
  {
    "target_image": "15dd101419.jpg!Large.jpg",
    "responses": "dark, night like",
    "row": 1600,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15Rauschenberg.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 281514
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "sharp, detailed",
    "row": 1601,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15madonna-casini.jpg",
    "time_elapsed": 307542
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "blurred, warm, dusk, vibrant dominant colour in the sky",
    "row": 1562,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15gladiators-1940.jpg",
    "time_elapsed": 176033
  },
  {
    "target_image": "15the-day-dream-1880.jpg!Large.jpg",
    "responses": "dark, limited colour pallet, bright sky",
    "row": 1563,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 220320
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "pastel colours, bright,",
    "row": 1564,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 243485
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "bright, varying colours, blurry at the bottom",
    "row": 1565,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 292068
  },
  {
    "target_image": "15Klimt1.jpg",
    "responses": "grainy, dominant colour across the whole painting, unfocussed",
    "row": 1566,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "15Rozanova2.jpg",
    "time_elapsed": 338874
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "clear, bright, soft toned colours",
    "row": 1567,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 456456
  },
  {
    "target_image": "15Rothko2.jpg",
    "responses": "slightly blurry, limited colours",
    "row": 1568,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "15Ingleside.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15MaxErnst.jpg",
    "time_elapsed": 480213
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "squared, smuggy, blurry, colourful",
    "row": 1529,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 428709
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "warped, bright, round",
    "row": 1530,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 440683
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "plain, desert, bland",
    "row": 1531,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 469425
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "overdone, grainy, unclear",
    "row": 1532,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 532176
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "rusty, dry",
    "row": 1533,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 550743
  },
  {
    "target_image": "15Picasso.jpg",
    "responses": "marble, pointy",
    "row": 1534,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 576962
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "vibrant, blurry, ugly",
    "row": 1535,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 592049
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "sunset, warm, pastel",
    "row": 1496,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15Rothko2.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 155388
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "dark, aurora, rainbow",
    "row": 1497,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 855156
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "bubble gum, mosaic, bright",
    "row": 1498,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 906386
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "haze, desert",
    "row": 1499,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 980187
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "treasure, bright, sparkling",
    "row": 1500,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 1127806
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "smudged, pastel, cracked sky,",
    "row": 1501,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 1370988
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "peacock-styled, somber",
    "row": 1502,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 1518686
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "Cool, crystal like, like fire and water",
    "row": 1463,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 734406
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "Sandy, dull",
    "row": 1464,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 791648
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "boxy, cool and warm, gridlike",
    "row": 1465,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 950703
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "softly patterned, moderately striking",
    "row": 1466,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15gladiators-1940.jpg",
    "time_elapsed": 1413138
  },
  {
    "target_image": "15ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "softened, not sharp, like road on mars",
    "row": 1467,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 1652676
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "fiery, blazing, symbol like patterns",
    "row": 1468,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 1762490
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "dark, strong, smoky, fiery, sinister",
    "row": 1469,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 1807065
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "abstract, stained glass, soft, mellow",
    "row": 1430,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "15les-musiciens-1952.jpg",
    "distractorTwo": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 294251
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "warm, pastel, clouded",
    "row": 1431,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "15Ingleside.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 329093
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "sharp, angular, warm, blocky",
    "row": 1432,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15gladiators-1940.jpg",
    "time_elapsed": 395489
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "abstract, colourful, contrasting",
    "row": 1433,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 424392
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "abstract, rectangular, cool",
    "row": 1434,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 443989
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "cold, vivid",
    "row": 1435,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 464148
  },
  {
    "target_image": "15Richter.jpg",
    "responses": "blurry, dark, murky",
    "row": 1436,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15Marquet.jpg",
    "time_elapsed": 487873
  },
  {
    "target_image": "15Picasso.jpg",
    "responses": "neutral tones, desert, sunset, bold lines, clear image, rocks",
    "row": 1397,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15Moholy.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 773279
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "earthy tones, paintbrushed effect, realistic, natural",
    "row": 1398,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 927522
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "abstract, unrealistic, block colour,",
    "row": 1399,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15the-dream-1910.jpg!Large.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1012643
  },
  {
    "target_image": "15Richter2.jpg",
    "responses": "disjointed, neutral pale colour tone, bleak, cut up, mosaic,",
    "row": 1400,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 1058972
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "smudged, blurred, muted, smeared, blended,",
    "row": 1401,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 1083917
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "gentle, pastel, light, floaty, airy,",
    "row": 1402,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1194348
  },
  {
    "target_image": "15Burliuk.jpg",
    "responses": "abstract, choppy, unrealistic, multi-tonal, bold,",
    "row": 1403,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 1247647
  },
  {
    "target_image": "15ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "not dull but not bright",
    "row": 1364,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 949850
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "sandy clear",
    "row": 1365,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 965377
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "mix of colours, straight, vertical,",
    "row": 1366,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 1789400
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "sun",
    "row": 1367,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 1795469
  },
  {
    "target_image": "15Rodchenko1.jpg",
    "responses": "sun, rough",
    "row": 1368,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15Mucha.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 1807229
  },
  {
    "target_image": "15Cezanne.jpg",
    "responses": "jungle",
    "row": 1369,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15Rozanova2.jpg",
    "time_elapsed": 1812328
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "desert, mixed, ice",
    "row": 1370,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 1846195
  },
  {
    "target_image": "15Richter2.jpg",
    "responses": "cool, attractive.",
    "row": 1331,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15Rozanova2.jpg",
    "time_elapsed": 664257
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "endearing, appealing.",
    "row": 1332,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 705582
  },
  {
    "target_image": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "Marvelous, alluring, dazzling",
    "row": 1333,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 771084
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "fascinating, fine",
    "row": 1334,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 795253
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "Dazzling, elegant, exquisite.",
    "row": 1335,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 845235
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "excellent, ideal, nice.",
    "row": 1336,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 877783
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "Classy, radiant, ravishing",
    "row": 1337,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 905909
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "Angular, vivid, Kaleidoscopic, colourful, abstract, pastel",
    "row": 1298,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 401901
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "Bright, rainbow, clear, eye-catching, vivid",
    "row": 1299,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "15hoffmann.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 465271
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "blockish, graffiti, chaotic, unrealistic, evening",
    "row": 1300,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 584510
  },
  {
    "target_image": "15Rodchenko1.jpg",
    "responses": "Distorted, cloudlike, warm, bright, hazy, light",
    "row": 1301,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "15Rauschenberg.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 635892
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "childlike, unfinished, minimalist, carnival, bright, basic",
    "row": 1302,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 730064
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "icey, cold, snowy, pale, colourless, tranquil",
    "row": 1303,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 777788
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "Tiger-like, twilight, hazy, contrasting, gloom, washed",
    "row": 1304,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 853322
  },
  {
    "target_image": "15Mucha.jpg",
    "responses": "sun, sharp, defined, picasso, papery, sandpaper, texture",
    "row": 1265,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "15kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 282986
  },
  {
    "target_image": "15Rozanova2.jpg",
    "responses": "cool, bright, calm, clear sky, maze",
    "row": 1266,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 363054
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "houses, squares, rectangles, bright, pen, farms from above",
    "row": 1267,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15self-portrait-with-brushes-1942.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 560603
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dark, ufo, ice",
    "row": 1268,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 648729
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "dream, bright, dusty, filter, blurry, haze, ripple",
    "row": 1269,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 738126
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "scrunched, sharp, defined, lines, bright, ridges",
    "row": 1270,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "15hoffmann.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 818360
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "dotty, pointy, haze, warm",
    "row": 1271,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15gladiators-1940.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 855354
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "stormy sky, angry, unsettled",
    "row": 1232,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15grablegung.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 255513
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "wishy washy, dusk, mellow, strange calm",
    "row": 1233,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 378211
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "twilight, angry atmosphere, strange vibes",
    "row": 1234,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 456082
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "eclectic, multi dimensional, on acid.",
    "row": 1235,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15RobertCampin.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 583004
  },
  {
    "target_image": "15Mucha.jpg",
    "responses": "rustic, boxy, angular, twilight, somethings to come",
    "row": 1236,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 665335
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "Twilight, intricate sky of twirls, mellow city in distance",
    "row": 1237,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 736240
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "shining upon, concrete sky, city in distance",
    "row": 1238,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 795221
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Striking,powerful and warming colours.",
    "row": 1199,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 333830
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "Bold, powerful, moody colours.",
    "row": 1200,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 416730
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "Desolate, dry and arid.",
    "row": 1201,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15Moholy.jpg",
    "time_elapsed": 507273
  },
  {
    "target_image": "15Remebrandt.jpg",
    "responses": "Crazy, chaotic, wild.",
    "row": 1202,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 554650
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "Cold,moody and unforgiving.",
    "row": 1203,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "15hoffmann.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 636248
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "Warm, exotic, fiery.",
    "row": 1204,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 684310
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "Calm,relaxing and serene.",
    "row": 1205,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 715591
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "wavy, pastel, windy, material texture",
    "row": 1166,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 420168
  },
  {
    "target_image": "15Klimt1.jpg",
    "responses": "grainy, rough, blurry",
    "row": 1167,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 472695
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "dark, eerie, glow",
    "row": 1168,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 572708
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "frantic, earthly, sinister",
    "row": 1169,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 668110
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "calm, dark, wavy, earthy",
    "row": 1170,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 709598
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "grainy, rough, blurry",
    "row": 1171,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 719617
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "blocky, neutral, colourless, bland",
    "row": 1172,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 798095
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "High contrast, autumnal, warm",
    "row": 1133,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 231648
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "vivid, atmospheric, invigorating, colourful",
    "row": 1134,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 295584
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "dusky, fantasy, otherworldly, spring",
    "row": 1135,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 568929
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "dark, moody, angry, ominous",
    "row": 1136,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15Marquet.jpg",
    "time_elapsed": 604792
  },
  {
    "target_image": "15dd101419.jpg!Large.jpg",
    "responses": "night, dark, high contrast",
    "row": 1137,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15gladiators-1940.jpg",
    "time_elapsed": 657969
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "pastel, colourful, harlequin",
    "row": 1138,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 694528
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "fresh. mazy, blurred, cubist",
    "row": 1139,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "15madonna-casini.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 737817
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "blaze, hot, scorching",
    "row": 1100,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 272589
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "heat, colourful",
    "row": 1101,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 317060
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "wine, wood",
    "row": 1102,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 434787
  },
  {
    "target_image": "15Richter2.jpg",
    "responses": "colourless",
    "row": 1103,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 453507
  },
  {
    "target_image": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "twilight, arora",
    "row": 1104,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 583977
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "colourful, highly crumpled",
    "row": 1105,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 714459
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "stacked stones",
    "row": 1106,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "15portrait-of-daughter-1912.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 807465
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "Colourful, Unusual, Fun, Funky",
    "row": 1067,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 286711
  },
  {
    "target_image": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "Wizzy, Eye-Catching, Unusual",
    "row": 1068,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 331375
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "Fabulous, Cool, Lovely, Unique",
    "row": 1069,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 357064
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "Boring, Dull, Uninteresting",
    "row": 1070,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-daughter-1912.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 382713
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "Pastel, Light, Imaginative",
    "row": 1071,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 418924
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "Evening, Lovely, Calm",
    "row": 1072,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 444296
  },
  {
    "target_image": "15Picasso.jpg",
    "responses": "Funky, Light",
    "row": 1073,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15JeanDupas.jpg",
    "time_elapsed": 475857
  },
  {
    "target_image": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "dark, glowing",
    "row": 1034,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 305515
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "Geometric, colorful",
    "row": 1035,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 326721
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "Monochromatic, abstract, neutral",
    "row": 1036,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 368595
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "Colorful, reflective, blurred",
    "row": 1037,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 428426
  },
  {
    "target_image": "15hoffmann.jpg",
    "responses": "Dark, unclear, dusky",
    "row": 1038,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "15portrait-of-daughter-1912.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 460022
  },
  {
    "target_image": "15the-dream-1910.jpg!Large.jpg",
    "responses": "Intricate",
    "row": 1039,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "15Kline2.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15Marquet.jpg",
    "time_elapsed": 496028
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "Pastel, calm, dichromatic",
    "row": 1040,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 604821
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "colourful, dull, bushy",
    "row": 1001,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 238105
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "obscured, faint, blends into one, pastel",
    "row": 1002,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 310517
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "pastel, colourful, tasteful, funky, complimentary",
    "row": 1003,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "15gladiators-1940.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 381950
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurred, angry, foggy, moody",
    "row": 1004,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 430084
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "light, pastel, celestial, early",
    "row": 1005,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 487583
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "blurred, bright, colourful, psychedelic",
    "row": 1006,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "15Klee1.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 537019
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "blurred, darkish, obscured, angry",
    "row": 1007,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 602833
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "rocky, hilly, pastel",
    "row": 968,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 292285
  },
  {
    "target_image": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "smudged, wavy, dull",
    "row": 969,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 323042
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "pastel, primary, bright",
    "row": 970,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 345427
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "metropolitan, smoky, pastel",
    "row": 971,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "15Ingleside.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 396741
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "blocky, picasso, cool",
    "row": 972,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 438350
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "warm, sandy, blurry",
    "row": 973,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 479066
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "nature, dreary",
    "row": 974,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15Rothko.jpg",
    "distractorThree": "15self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 546449
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "pastel, dark, colorful",
    "row": 935,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15Marquet.jpg",
    "time_elapsed": 957012
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "oil pastel, bright",
    "row": 936,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 973863
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "oil pastel, dark",
    "row": 937,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 993948
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "pastel, acrylic paint, oil paint",
    "row": 938,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "15Kline1.jpg",
    "time_elapsed": 1106739
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "pastel, acrylic paint, oil paint",
    "row": 939,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 1116084
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "acrylic paint, oil paint",
    "row": 940,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 1131317
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "pastel, acrylic paint, oil paint",
    "row": 941,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 1137085
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "pastel, blurred, fiery, mashed",
    "row": 902,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 323806
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "cool, cold, pale, hazy",
    "row": 903,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "15Ingleside.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 366671
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "icy, cold, impressionist, collage",
    "row": 904,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 409548
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "sulphuric, gasesous, blurred, moutainous",
    "row": 905,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15JeanDupas.jpg",
    "distractorThree": "15self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 477598
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "pastel, chalky, mild, light",
    "row": 906,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 521154
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "psychedelic, vibrant, gassy, poisonous",
    "row": 907,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 588302
  },
  {
    "target_image": "15portrait-of-daughter-1912.jpg",
    "responses": "striking , hot, cold, varied",
    "row": 908,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 647604
  },
  {
    "target_image": "15grablegung.jpg",
    "responses": "autumnal, mountain blur, bold, busy sky,",
    "row": 869,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 341516
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "cold tones, dappled sky, mountain blur, sunny spot,",
    "row": 870,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "15les-musiciens-1952.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 385068
  },
  {
    "target_image": "15the-dream-1910.jpg!Large.jpg",
    "responses": "jungle feel, brush strokes, dark tones,",
    "row": 871,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 431834
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "doodled sky, sunrise feel, colours quite true,",
    "row": 872,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 472277
  },
  {
    "target_image": "15Richter2.jpg",
    "responses": "almost mono-chromatic, cubist feel, boxy,",
    "row": 873,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 504094
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "bush fire colours, wolf head in sky, bright,",
    "row": 874,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 547335
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "sombre colours, dark towers in sky, autumnal,",
    "row": 875,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 590133
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "milky, drab, subtle",
    "row": 836,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 252021
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "metallic,dark,warm",
    "row": 837,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 286285
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "bright,sunny,flame",
    "row": 838,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 359496
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "dark, cold, bleak",
    "row": 839,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 410800
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "fiery, glowing,warm",
    "row": 840,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 529807
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "deep,opalescent,bleak",
    "row": 841,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "15Klimt1.jpg",
    "distractorThree": "15gladiators-1940.jpg",
    "time_elapsed": 583546
  },
  {
    "target_image": "15Mondrian.jpg",
    "responses": "cold,monotone,faded",
    "row": 842,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "15Rauschenberg.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 644631
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "digital, bleak",
    "row": 803,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 268320
  },
  {
    "target_image": "15Klimt1.jpg",
    "responses": "warm, blurry, unclear",
    "row": 804,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 317408
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark",
    "row": 805,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 338153
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "static,",
    "row": 806,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 357656
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "fuzzy, bleak",
    "row": 807,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 377928
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "distorted, warm",
    "row": 808,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 408311
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "warm,",
    "row": 809,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 441575
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "bright colours, variety of colours, psychedelic, pixelated almost, hectic, busy",
    "row": 770,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "15madonna-casini.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 215797
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "peaceful, calm, soft colours, dark, sketchy",
    "row": 771,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 243229
  },
  {
    "target_image": "15hoffmann.jpg",
    "responses": "dark, almost scary, tense, edgy",
    "row": 772,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 274934
  },
  {
    "target_image": "15the-day-dream-1880.jpg!Large.jpg",
    "responses": "blurry, lumninscent,",
    "row": 773,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "15Cezanne.jpg",
    "time_elapsed": 319787
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "psychedelic, pastel, colour variety, dull, scenic, serene, peaceful",
    "row": 774,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 328600
  },
  {
    "target_image": "15grablegung.jpg",
    "responses": "smeared, light soft colours, bright",
    "row": 775,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15RobertCampin.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 362144
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "warm colours with emphasis on orange, focus on the water,",
    "row": 776,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 404534
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "winter,pastels,movement,dark",
    "row": 737,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 134631
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "fire,smoothed,waves,morning",
    "row": 738,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 158648
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "pixelated,bright,colourful",
    "row": 739,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 175094
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "dark,contrast,moody,storm",
    "row": 740,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 193991
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "haze,rain,broken",
    "row": 741,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 215780
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "dusk,bright,sharp",
    "row": 742,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 244170
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark,night,moody",
    "row": 743,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 269406
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "insane, ugly, distorted,",
    "row": 704,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 184111
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "dreamy, strange, menacing,",
    "row": 705,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "15kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 220175
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "ridiculous, amateurish, freaky,",
    "row": 706,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 246919
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "silly, boring, uninspiring,",
    "row": 707,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15Rauschenberg.jpg",
    "distractorThree": "15Picasso.jpg",
    "time_elapsed": 268303
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "odd, scary, ill-fitting,",
    "row": 708,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "15Mucha.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 308977
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "fiery, monstrous, evil, satanic,",
    "row": 709,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 346745
  },
  {
    "target_image": "15Cezanne.jpg",
    "responses": "pathetic, gloomy, waste of paint,",
    "row": 710,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15Kline1.jpg",
    "time_elapsed": 381931
  },
  {
    "target_image": "15the-day-dream-1880.jpg!Large.jpg",
    "responses": "dark, gloomy, chromatic",
    "row": 671,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 139953
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "messy, light, sandy",
    "row": 672,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "15Kline1.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 166581
  },
  {
    "target_image": "15girl-s-head-in-a-shawl.jpg",
    "responses": "messy, dark, blurry, watery",
    "row": 673,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 193635
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "dark, gloomy, blurry, messy",
    "row": 674,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 214594
  },
  {
    "target_image": "15grablegung.jpg",
    "responses": "blurry, light, sunny,",
    "row": 675,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15Moholy.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 238459
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "blurry, gloomy, dark, dingy",
    "row": 676,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 253875
  },
  {
    "target_image": "15dd101419.jpg!Large.jpg",
    "responses": "dark, blurry, gloomy, sad",
    "row": 677,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "15moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "15gladiators-1940.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 281764
  },
  {
    "target_image": "15Mondrian3.jpg",
    "responses": "Murky, hazy, dim, soft, crinkle",
    "row": 638,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 146820
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "Dark, dim, shade, muted",
    "row": 639,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 189546
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "Jagged, pastels, sharp, tropical",
    "row": 640,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 217808
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "Spray, dark, dim, muted, hazy, shade,",
    "row": 641,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 242310
  },
  {
    "target_image": "15Rodchenko1.jpg",
    "responses": "Desert, soft, lined, sunset,",
    "row": 642,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 287519
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Bright, flame, contrast, explosive",
    "row": 643,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "15girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 324340
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "Dark, dim, ominous, doom, dread, hard",
    "row": 644,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15the-dream-1910.jpg!Large.jpg",
    "distractorThree": "15gladiators-1940.jpg",
    "time_elapsed": 352140
  },
  {
    "target_image": "15the-memory-of-the-golden-apse-2009.jpg",
    "responses": "blurred, neutral, fuzzy,",
    "row": 605,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15grablegung.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 158572
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "picasso like, colourful,",
    "row": 606,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "15Richter2.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 181871
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "fuzzy, different hues,",
    "row": 607,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15the-row.jpg!Large.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 226278
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "rainbow,",
    "row": 608,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 272408
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dark, moody,",
    "row": 609,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 307050
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "bright, in your face,",
    "row": 610,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 324380
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "autumnal, fire,",
    "row": 611,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 339731
  },
  {
    "target_image": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "dark but warm colours, soft edges, abstract sky",
    "row": 572,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "15Pollock2.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 227003
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, unclear, vague",
    "row": 573,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 248189
  },
  {
    "target_image": "15the-day-dream-1880.jpg!Large.jpg",
    "responses": "luminous colours, abstract sky, defined foreground",
    "row": 574,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 270718
  },
  {
    "target_image": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "bright, primary colours, aurora type sky",
    "row": 575,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 291997
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "sandy colours, bright, colourful, soft sky",
    "row": 576,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "15hoffmann.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 318946
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "sharp and defined lines, pale colours, life-like",
    "row": 577,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 342115
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "highly abstract sky, squared pastel coloured sky",
    "row": 578,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 370217
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "boxy, robotic, surrealist, techno, bright, vibrant, sharp",
    "row": 539,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15gladiators-1940.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 167354
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "hot, warm, blurry, wavy, streaky, searing",
    "row": 540,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 205699
  },
  {
    "target_image": "15Rothko2.jpg",
    "responses": "contrasting, rainbow-like, technocoloured, bright, defined, in-your-face",
    "row": 541,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15grablegung.jpg",
    "time_elapsed": 256488
  },
  {
    "target_image": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "dark, vibey, pastel, streaky, night, moody",
    "row": 542,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15Mondrian.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 280233
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "crazy, dramatic, hot, overwhelming, destructive, technocoloured, bright, complex",
    "row": 543,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 314700
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "pastel, blurry, calm, soft, hazy, soothing, dark, moody",
    "row": 544,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 345687
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "hot, blurry, warm, explosive",
    "row": 545,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "15machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 375256
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "contrasting,dramatic,pastel,serious,dynamic,vivid,motion blur",
    "row": 506,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15grablegung.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 138797
  },
  {
    "target_image": "15Ingleside.jpg",
    "responses": "abstract,distorted,manic,uncomfortable,torturous,twisted",
    "row": 507,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "15Klee2.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 180907
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark,brooding,dramatic,hellscape,stormy,intense,oversaturated",
    "row": 508,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15portrait-of-daughter-1912.jpg",
    "distractorThree": "15les-musiciens-1952.jpg",
    "time_elapsed": 209489
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "pastel,mellow,bland,anodyne,calm",
    "row": 509,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "15MaxErnst.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 239177
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "cubist,urgent,abstract,alarming",
    "row": 510,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 266381
  },
  {
    "target_image": "15Cezanne.jpg",
    "responses": "nauseating,unclear,headache-inducing,sickly,vivd, bright",
    "row": 511,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15Marquet.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 297359
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "contrasting,abstract,washed out,well lit",
    "row": 512,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 335506
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "colourful,",
    "row": 473,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 142812
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "mountainous, desert landscape,",
    "row": 474,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 173717
  },
  {
    "target_image": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "bright, warm,",
    "row": 475,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15gladiators-1940.jpg",
    "distractorThree": "15MaxErnst.jpg",
    "time_elapsed": 195423
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "mountainous terrain from above on gps",
    "row": 476,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "15portrait-of-daughter-1912.jpg",
    "distractorTwo": "15Mondrian3.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 243442
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "geometric, futuristic, bold",
    "row": 477,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 278812
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "blurry, muted but colourful",
    "row": 478,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 299387
  },
  {
    "target_image": "15the-pink-candle-1910.jpg!Large.jpg",
    "responses": "pastel, blurry, colour of flowers",
    "row": 479,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15Rothko2.jpg",
    "time_elapsed": 319499
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "picasso, pastel, summer, sunset,",
    "row": 440,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 123278
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "muted, sunset, patchy, scaly,",
    "row": 441,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 149502
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "dark, warped, shadow, shade",
    "row": 442,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 163114
  },
  {
    "target_image": "15Klimt1.jpg",
    "responses": "picasso, light, summer, bright, distorted,",
    "row": 443,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 191534
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "abstract, summer, sunny, colourful, boxy,",
    "row": 444,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15madonna-casini.jpg",
    "distractorThree": "15city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 210917
  },
  {
    "target_image": "15ManRay.jpg",
    "responses": "pastel, sunset, collage",
    "row": 445,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 233057
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "warped, bold, mask, sharp",
    "row": 446,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "15Mucha.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 260709
  },
  {
    "target_image": "15city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "warm toned, soft and blurred, faded, softened",
    "row": 407,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 126751
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "softened, hazy, faded, pastel, blurred,",
    "row": 408,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 144182
  },
  {
    "target_image": "15Matisse.jpg",
    "responses": "vivid, textured, cool toned with warm elements,",
    "row": 409,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15Remebrandt.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 168417
  },
  {
    "target_image": "15destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "cool dull toned, textured, hazy, dark",
    "row": 410,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "15Burliuk.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 190124
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "vivid, bright, bold",
    "row": 411,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15porch-ii-1947.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 205152
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "hazy, warm, golden hour bright, textured, sharp",
    "row": 412,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 230213
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "vivid, textured, cool toned, stippled, small texture, small details",
    "row": 413,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 250465
  },
  {
    "target_image": "15EdgarDegas.jpg",
    "responses": "Autumnal, light, sunset",
    "row": 374,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 121091
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "ominous, pastel, vertical",
    "row": 375,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15RobertCampin.jpg",
    "distractorThree": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 138592
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "light, whimsical, blurry",
    "row": 376,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15Rozanova2.jpg",
    "distractorThree": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 156384
  },
  {
    "target_image": "15Pollock1.jpg",
    "responses": "Van Gogh-esque, Opposing colours, Sharp",
    "row": 377,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15Remebrandt.jpg",
    "time_elapsed": 182771
  },
  {
    "target_image": "15JeanDupas.jpg",
    "responses": "Soft, darkening, moody",
    "row": 378,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "15Chirico.jpg",
    "distractorTwo": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 193254
  },
  {
    "target_image": "15Rodchenko1.jpg",
    "responses": "Bright, Sunburst, hazy",
    "row": 379,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 209950
  },
  {
    "target_image": "15grablegung.jpg",
    "responses": "Bright, prisms, unclear",
    "row": 380,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "15Richter.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 226589
  },
  {
    "target_image": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "dull, cold",
    "row": 341,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 162841
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "misty, hazy",
    "row": 342,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 184307
  },
  {
    "target_image": "15Marquet.jpg",
    "responses": "bright, varied",
    "row": 343,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 206710
  },
  {
    "target_image": "15Richter.jpg",
    "responses": "storm, dark",
    "row": 344,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "15the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 217535
  },
  {
    "target_image": "15Rozanova2.jpg",
    "responses": "cold, wintery",
    "row": 345,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "15Ingleside.jpg",
    "distractorTwo": "15grablegung.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 224527
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "block, square",
    "row": 346,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15Rodchenko1.jpg",
    "time_elapsed": 237432
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "abstract,",
    "row": 347,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 249298
  },
  {
    "target_image": "15MaxErnst.jpg",
    "responses": "bright, warm",
    "row": 308,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15Klee1.jpg",
    "distractorThree": "15Marquet.jpg",
    "time_elapsed": 127270
  },
  {
    "target_image": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "cool, dark, blended",
    "row": 309,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15Richter.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 163075
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "not many colours used, dark",
    "row": 310,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "15Nay.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 187446
  },
  {
    "target_image": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "lots of colouir, blended",
    "row": 311,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 236486
  },
  {
    "target_image": "15Remebrandt.jpg",
    "responses": "dark the car isnt the focus",
    "row": 312,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "15mary-magdalene.jpg!Large.jpg",
    "distractorThree": "15kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 253040
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "dull",
    "row": 313,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 262123
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "2 effects used",
    "row": 314,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15Rauschenberg.jpg",
    "distractorThree": "15Klee2.jpg",
    "time_elapsed": 275215
  },
  {
    "target_image": "15Rothko2.jpg",
    "responses": "ethereal, cosmic, lively",
    "row": 275,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15Richter2.jpg",
    "distractorThree": "15Matisse.jpg",
    "time_elapsed": 309843
  },
  {
    "target_image": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "calming, soft, bright",
    "row": 276,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "15portrait-of-daughter-1912.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15ManRay.jpg",
    "time_elapsed": 388628
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "bold, contrasting, cool",
    "row": 277,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15Richter.jpg",
    "time_elapsed": 474425
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "natural, warm, calming",
    "row": 278,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 658594
  },
  {
    "target_image": "15Klee1.jpg",
    "responses": "frosted, dreamlike, simplistic",
    "row": 279,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "15Pollock1.jpg",
    "distractorTwo": "15Cezanne.jpg",
    "distractorThree": "15pissaro.jpg",
    "time_elapsed": 795153
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "striking, bright, vibrant",
    "row": 280,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "15the-row.jpg!Large.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 959153
  },
  {
    "target_image": "15Mucha.jpg",
    "responses": "dull, dusty, simplistic",
    "row": 281,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 1032495
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "surrealism, cold, colourful, dark",
    "row": 242,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15dd101419.jpg!Large.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 422854
  },
  {
    "target_image": "15Pollock1.jpg",
    "responses": "wormy, surreal, dark, cold",
    "row": 243,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "15Matisse.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15still-life.jpg",
    "time_elapsed": 538223
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "cubism, colourful, fresh, energetic",
    "row": 244,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "15porch-ii-1947.jpg",
    "time_elapsed": 549661
  },
  {
    "target_image": "15Moholy.jpg",
    "responses": "bright, wormy, cold, twilight",
    "row": 245,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15Chirico.jpg",
    "time_elapsed": 584456
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "lonely, sad, simple, dread, blurred",
    "row": 246,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15Burliuk.jpg",
    "time_elapsed": 632008
  },
  {
    "target_image": "15Nay.jpg",
    "responses": "modernism, colourful, cheerful",
    "row": 247,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "15mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "15machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "15Kline2.jpg",
    "time_elapsed": 661251
  },
  {
    "target_image": "15self-portrait-with-brushes-1942.jpg",
    "responses": "chaotic, energetic, bright",
    "row": 248,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 678148
  },
  {
    "target_image": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark and moody palette of colours, as though there is a storm brewing and the ground is wet",
    "row": 209,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 310241
  },
  {
    "target_image": "15Cezanne.jpg",
    "responses": "Sunny, spring day and the sun is shining early in the morning, reflecting on the ground",
    "row": 210,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "15ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "15JohnsJasper.jpg",
    "time_elapsed": 411035
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "wintry scene, blizzard, looks like it has been snowing with more snow on its way, frosty and crisp",
    "row": 211,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "15Rozanova2.jpg",
    "distractorTwo": "15gladiators-1940.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 538691
  },
  {
    "target_image": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "blurred, cool palette, smudged, storm brewing overhead",
    "row": 212,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "15the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 606608
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "warm palette, sunshine, bright, busy",
    "row": 213,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "15EdgarDegas.jpg",
    "distractorTwo": "15the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 661979
  },
  {
    "target_image": "15porch-ii-1947.jpg",
    "responses": "still, calm, spicy and oriental",
    "row": 214,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "15Rothko2.jpg",
    "distractorTwo": "15Kline1.jpg",
    "distractorThree": "15self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 722812
  },
  {
    "target_image": "15Pollock2.jpg",
    "responses": "very cool colours, overcast and shadowy with hints of light breaking through",
    "row": 215,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "15RobertCampin.jpg",
    "distractorTwo": "15Nay.jpg",
    "distractorThree": "15girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 782803
  },
  {
    "target_image": "15JohnsJasper.jpg",
    "responses": "ice, cold, mystical, freezing",
    "row": 176,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "15still-life.jpg",
    "distractorTwo": "15Ingleside.jpg",
    "distractorThree": "15Rothko.jpg",
    "time_elapsed": 231791
  },
  {
    "target_image": "15Pollock1.jpg",
    "responses": "dark, muddy, dank, dingy",
    "row": 177,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 320850
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "psychedelic, rave, bright, excitable, exuberant",
    "row": 178,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "15Moholy.jpg",
    "distractorTwo": "15girl-s-head-in-a-shawl.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 384835
  },
  {
    "target_image": "15the-row.jpg!Large.jpg",
    "responses": "autumnal, sunset, warming, dimming",
    "row": 179,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "15the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "15dd101419.jpg!Large.jpg",
    "time_elapsed": 444862
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "expressive, mazy. explosive, dynamic",
    "row": 180,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 504974
  },
  {
    "target_image": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "autumnal, soft, dull, uninspiring",
    "row": 181,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15pissaro.jpg",
    "distractorThree": "15EdgarDegas.jpg",
    "time_elapsed": 607370
  },
  {
    "target_image": "15Richter2.jpg",
    "responses": "binary, concrete, sharp, dispiriting",
    "row": 182,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "15Klimt1.jpg",
    "distractorTwo": "15Klee2.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 668161
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "abstract, bright, fiery, chaos",
    "row": 143,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "15the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15Nay.jpg",
    "time_elapsed": 138407
  },
  {
    "target_image": "15grablegung.jpg",
    "responses": "warm, summery",
    "row": 144,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "15Pollock2.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 167863
  },
  {
    "target_image": "15les-musiciens-1952.jpg",
    "responses": "blazing,",
    "row": 145,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "15Picasso.jpg",
    "distractorTwo": "15portrait-of-daughter-1912.jpg",
    "distractorThree": "15Mondrian3.jpg",
    "time_elapsed": 201647
  },
  {
    "target_image": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "nightfall, cold",
    "row": 146,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "15Pollock1.jpg",
    "time_elapsed": 227959
  },
  {
    "target_image": "15Rauschenberg.jpg",
    "responses": "geometric,",
    "row": 147,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "15the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "15hoffmann.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 266042
  },
  {
    "target_image": "15Rodchenko1.jpg",
    "responses": "swarming, sandy",
    "row": 148,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "15JohnsJasper.jpg",
    "distractorThree": "15Rozanova2.jpg",
    "time_elapsed": 295472
  },
  {
    "target_image": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "cold, wintry, icey",
    "row": 149,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "15kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15Mucha.jpg",
    "time_elapsed": 332038
  },
  {
    "target_image": "15Kline2.jpg",
    "responses": "natural",
    "row": 110,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 98265
  },
  {
    "target_image": "15Klimt1.jpg",
    "responses": "desert",
    "row": 111,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "15porch-ii-1947.jpg",
    "distractorTwo": "15reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 107721
  },
  {
    "target_image": "15moscow-i-1916.jpg!Large.jpg",
    "responses": "patchwork",
    "row": 112,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15Rauschenberg.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 115921
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "night",
    "row": 113,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "15ManRay.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 121217
  },
  {
    "target_image": "15madonna-casini.jpg",
    "responses": "sandy",
    "row": 114,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "15destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 127729
  },
  {
    "target_image": "15Cezanne.jpg",
    "responses": "naturalistic",
    "row": 115,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15EdgarDegas.jpg",
    "distractorThree": "15Richter2.jpg",
    "time_elapsed": 137505
  },
  {
    "target_image": "15Klee2.jpg",
    "responses": "explosion",
    "row": 116,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 146745
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "crunchy, sharp, abstract, dark",
    "row": 77,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "15Marquet.jpg",
    "distractorTwo": "15disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "15hoffmann.jpg",
    "time_elapsed": 92650
  },
  {
    "target_image": "15mary-magdalene.jpg!Large.jpg",
    "responses": "swirly, dark, moody",
    "row": 78,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "15les-musiciens-1952.jpg",
    "distractorTwo": "15d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "15destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 102726
  },
  {
    "target_image": "15the-dream-1910.jpg!Large.jpg",
    "responses": "scratchy, hard, dark",
    "row": 79,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "15grablegung.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 115582
  },
  {
    "target_image": "15the-snow-maiden.jpg!Large.jpg",
    "responses": "blurred, cloudy, soft, pastel, cool",
    "row": 80,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "15portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "15moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 130243
  },
  {
    "target_image": "15machine-man-with-spiral-turn-1930.jpg",
    "responses": "blocky, square, cool, light",
    "row": 81,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "15einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "15Mondrian.jpg",
    "time_elapsed": 139327
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "abstract, impressionist, warm, bright",
    "row": 82,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "15dd101419.jpg!Large.jpg",
    "distractorTwo": "15Picasso.jpg",
    "distractorThree": "15ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 152801
  },
  {
    "target_image": "15RobertCampin.jpg",
    "responses": "warm, dirty",
    "row": 83,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "15pissaro.jpg",
    "distractorTwo": "15MaxErnst.jpg",
    "distractorThree": "15Pollock2.jpg",
    "time_elapsed": 168690
  },
  {
    "target_image": "15kateryna-1951.jpg!Large.jpg",
    "responses": "soft, clear",
    "row": 44,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "15ManRay.jpg",
    "distractorTwo": "15Rodchenko1.jpg",
    "distractorThree": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 137235
  },
  {
    "target_image": "15Kline1.jpg",
    "responses": "blurry, contrast, bold",
    "row": 45,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "15Rothko.jpg",
    "distractorTwo": "15city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "15mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 156897
  },
  {
    "target_image": "15Pollock1.jpg",
    "responses": "monotonic, dull,",
    "row": 46,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "15JeanDupas.jpg",
    "distractorTwo": "15the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "15mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 176471
  },
  {
    "target_image": "15still-life.jpg",
    "responses": "blurred, dull, distant",
    "row": 47,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "15Mondrian.jpg",
    "distractorTwo": "15Kline2.jpg",
    "distractorThree": "15the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 193113
  },
  {
    "target_image": "15the-liver-is-the-cock-s-comb.jpg",
    "responses": "sharp, clear, bright",
    "row": 48,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "15JohnsJasper.jpg",
    "distractorTwo": "15les-musiciens-1952.jpg",
    "distractorThree": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 211686
  },
  {
    "target_image": "15pissaro.jpg",
    "responses": "pastel, blurred",
    "row": 49,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "15Remebrandt.jpg",
    "distractorTwo": "15early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "15Ingleside.jpg",
    "time_elapsed": 221671
  },
  {
    "target_image": "15Chirico.jpg",
    "responses": "creative, cool, soft",
    "row": 50,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "15self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "15Burliuk.jpg",
    "distractorThree": "15Rauschenberg.jpg",
    "time_elapsed": 260179
  },
  {
    "target_image": "15the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "earthy, warm,",
    "row": 11,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "15Mondrian3.jpg",
    "distractorTwo": "15still-life.jpg",
    "distractorThree": "15the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 175706
  },
  {
    "target_image": "15gladiators-1940.jpg",
    "responses": "pastel, cool, dreamy",
    "row": 12,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "15oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "15kateryna-1951.jpg!Large.jpg",
    "distractorThree": "15Klee1.jpg",
    "time_elapsed": 202472
  },
  {
    "target_image": "15Rothko.jpg",
    "responses": "muted, warm",
    "row": 13,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "15the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "15samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "15the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 224809
  },
  {
    "target_image": "15Picasso.jpg",
    "responses": "warm, neutral",
    "row": 14,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "15Rodchenko1.jpg",
    "distractorTwo": "15Matisse.jpg",
    "distractorThree": "15MaxErnst.jpg",
    "time_elapsed": 251211
  },
  {
    "target_image": "15ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "deep, firey, warm",
    "row": 15,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "15Cezanne.jpg",
    "distractorTwo": "15Pollock1.jpg",
    "distractorThree": "15portrait-of-daughter-1912.jpg",
    "time_elapsed": 270207
  },
  {
    "target_image": "15lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "delicate, cool,",
    "row": 16,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "15portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "15Chirico.jpg",
    "distractorThree": "15RobertCampin.jpg",
    "time_elapsed": 292638
  },
  {
    "target_image": "15Klimt1.jpg",
    "responses": "sandy, mono, warm",
    "row": 17,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "15the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "15the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "15the-row.jpg!Large.jpg",
    "time_elapsed": 316641
  }
]