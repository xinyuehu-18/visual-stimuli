var thirteen_set = [
  {
    "target_image": "13pissaro.jpg",
    "responses": "pixelated, dotty",
    "row": 5068,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 803379
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "warm, bright, smudged",
    "row": 5069,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 835332
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "dark, gloomy",
    "row": 5070,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13Burliuk.jpg",
    "time_elapsed": 852578
  },
  {
    "target_image": "13Chirico.jpg",
    "responses": "texture, contrast, dark",
    "row": 5071,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 884371
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "blocky, block colour, flat",
    "row": 5072,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 922495
  },
  {
    "target_image": "13the-row.jpg!Large.jpg",
    "responses": "hotspots, strong colour",
    "row": 5073,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 977076
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "blurred, bland",
    "row": 5074,
    "subject_id": "5e8281c53c757f9b257d2a0a",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 1073017
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "acquatic, marine, oceanic",
    "row": 5035,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 1223506
  },
  {
    "target_image": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "warm, fiery, bold, amber, glowing, fierce, sharp, coarse, gritty,",
    "row": 5036,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 1334757
  },
  {
    "target_image": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "dark, vibrant, dramatic, cool, dreamy, active",
    "row": 5037,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1781150
  },
  {
    "target_image": "13the-pink-candle-1910.jpg!Large.jpg",
    "responses": "calm, realistic, clear, contrasting",
    "row": 5038,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 1848687
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "angular, geometric, colorful, defined, jagged",
    "row": 5039,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1974883
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "focal, rosy, blushing, smooth, bright",
    "row": 5040,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 2245166
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "rocky, light, sandy, gritty, gentle, pale",
    "row": 5041,
    "subject_id": "5e3d8d90de328d044e7c6ffb",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 2329024
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "blurry, daytime, cool, grainy",
    "row": 5002,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 1931701
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "festive, colorful, speckled, brash, daytime",
    "row": 5003,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 2000538
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "flaming, fiery, dappled",
    "row": 5004,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 2057226
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "dark, nighttime, sombre, sooty, warm, sepia",
    "row": 5005,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 2107741
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "colorful, daytime, dusty, blotchy",
    "row": 5006,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 2209338
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "fiery, flaming, tinted, discolored, inky",
    "row": 5007,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 2247889
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "flaming, fiery, blotchy, discolored",
    "row": 5008,
    "subject_id": "56e6a66af6ed900006a5867c",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 2278037
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "scary, pastel, soft",
    "row": 4969,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13madonna-casini.jpg",
    "time_elapsed": 412805
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "sharp, blurry, shiny",
    "row": 4970,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 435617
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "grassy, glassy, sharp",
    "row": 4971,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 450331
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "muddy, lonely, swampy",
    "row": 4972,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13Klimt1.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 479029
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "old, staticky, paper",
    "row": 4973,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 510423
  },
  {
    "target_image": "13Kline1.jpg",
    "responses": "blurry, vast, windy",
    "row": 4974,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 532284
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "sunny, crispy, toasty",
    "row": 4975,
    "subject_id": "5c0990b854deae0001ac693c",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 551116
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "neon, blurry, aurora, vibrant",
    "row": 4936,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 1282194
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "dark, natural, clear, spring",
    "row": 4937,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 1317516
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dark, blurred, washed out",
    "row": 4938,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13dd101419.jpg!Large.jpg",
    "time_elapsed": 1637268
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "autumn, wavy, light, natural, blurred",
    "row": 4939,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 1724761
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "speckled, vibrant, neon, blurry, dark",
    "row": 4940,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13the-row.jpg!Large.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 1785516
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, crisp, defined, focused",
    "row": 4941,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 1876297
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "autumn, natural, blurred, bright",
    "row": 4942,
    "subject_id": "5e85088b3f06400f3f75e21f",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 1914931
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "smeared, firey warmth, blazing sun",
    "row": 4903,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "13Picasso.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 1524308
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "mother nature, earthly, muddy",
    "row": 4904,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 1558527
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "blood shed, sorrow, night, gloomy",
    "row": 4905,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13Kline1.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 1601716
  },
  {
    "target_image": "13portrait-of-daughter-1912.jpg",
    "responses": "kaleidoscope, rainbow, inclusion",
    "row": 4906,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 1633460
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "strawberry shmear, detailed, moderately defined.",
    "row": 4907,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 1726230
  },
  {
    "target_image": "13Klee2.jpg",
    "responses": "washed out, blurred, non-definitive, blazing sun",
    "row": 4908,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "13MaxErnst.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1782920
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "blocky, abstract shapes, spots",
    "row": 4909,
    "subject_id": "5ff0038ecd5d98eb8083a651",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 1830215
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "Stippled, textured, watercolor, swirled, realistic",
    "row": 4870,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 1100541
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "dark, muted, realistic, drab",
    "row": 4871,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 1149158
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "sunny, shining, rays of light, bright, daylight, warm",
    "row": 4872,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 1178589
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "wavy, shadows, pastel, realistic, dayilght",
    "row": 4873,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 1242038
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "Inverted, light, highlighted, chalky",
    "row": 4874,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 1407033
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "dark, afternoon, shadowy, dusk, realistic, textured",
    "row": 4875,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 1444483
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "faded, hazy, pastel, blurry, dusty, little constrast",
    "row": 4876,
    "subject_id": "5fb090f5bc045b492643352d",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13Burliuk.jpg",
    "time_elapsed": 1511797
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "religion, sad, cold",
    "row": 4837,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 956225
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "warm, energy, change",
    "row": 4838,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 1009111
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "vintage, 80s",
    "row": 4839,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "13girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 1124636
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "wet, cold",
    "row": 4840,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "13Matisse.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13madonna-casini.jpg",
    "time_elapsed": 1271133
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "summer, light, dry",
    "row": 4841,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 1343293
  },
  {
    "target_image": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "expressive, direction",
    "row": 4842,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 1434416
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "disorientated",
    "row": 4843,
    "subject_id": "6032903277ccb729ab92972d",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 1486301
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "Centre focused, highlighted, distorted",
    "row": 4804,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 1278656
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "Children's book, cool, chalky, two toned",
    "row": 4805,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13still-life.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 1346826
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "Water marked, clean, dark, night",
    "row": 4806,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 1386462
  },
  {
    "target_image": "13the-row.jpg!Large.jpg",
    "responses": "Florescent, sharp, realistic,",
    "row": 4807,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 1456874
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "Blotchy, dark, few tones,",
    "row": 4808,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 1491060
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "Simple, monotone, shiny, neglected",
    "row": 4809,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 1573912
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "Lonely, haunted, ghostly, chalky, wavy",
    "row": 4810,
    "subject_id": "5e11ff6f814bba8816cca900",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 1606124
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "foggy,blending surroundings,eerie,",
    "row": 4771,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 924588
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "abstract,swirly,fused,blended,caving,",
    "row": 4772,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 1010965
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "pastel,spring,light,",
    "row": 4773,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 1039857
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "early evening, blended, swirly, mellow",
    "row": 4774,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 1100219
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "Easter eggs, spring,circular,obscure but dark",
    "row": 4775,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "13Marquet.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 1286332
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "abstract,hazy,floral,",
    "row": 4776,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 1373767
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "washed out,blurred,skin tone",
    "row": 4777,
    "subject_id": "5f84d98b2b16bc1ab7369b6a",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 1424088
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "pastel, mostly cool, geometric, winding",
    "row": 4738,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 912202
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "pastel, very soft focus",
    "row": 4739,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 954121
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "vibrant, high contrast, striated",
    "row": 4740,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "13Picasso.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 1082345
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "desaturated, shadowy, blurred, subdued, mostly earthy",
    "row": 4741,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 1197284
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "very colorful, vibrant, smudged, softened, painted-over",
    "row": 4742,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1270462
  },
  {
    "target_image": "13the-row.jpg!Large.jpg",
    "responses": "jewel-toned, vibrant pops",
    "row": 4743,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 1340073
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "very warm, very earthy, natural, faded, retreating, subdued",
    "row": 4744,
    "subject_id": "5be750e4af5ae80001f0ce07",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 1381305
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "bouquet, pastel, fuzzy, blurred, landscape, nature, floral,",
    "row": 4705,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 807386
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "sharp focus, ornate, modern, floral, stepping stones, arid, dry,",
    "row": 4706,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 910276
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "parkscape, classic, grassy, landscape, bench base, verdant, green,",
    "row": 4707,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "13the-row.jpg!Large.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 988618
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "floral, earth tone, crisp, soft-focus background, flower garden,",
    "row": 4708,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 1088042
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "greenery, Southern, palm garden, palm leaves, palm fronds,",
    "row": 4709,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "13MaxErnst.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 1175933
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "soft focus, blurry, floral arrangement, colorful, golden,",
    "row": 4710,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13Ingleside.jpg",
    "time_elapsed": 1254916
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "artificial, hodgepodge, color medley, bench, fantasy, colorscape, earth tone background, strange focus,",
    "row": 4711,
    "subject_id": "5e237189f0b71e629c6efe62",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 1388229
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "blurry, high-contrast, murky",
    "row": 4672,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 952034
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "warm, blurred, smudged, soft",
    "row": 4673,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 1021024
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "hot, arid, sharp, bold, clear, defined",
    "row": 4674,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 1075695
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "lineless, smeared, warm, motion, low-contrast",
    "row": 4675,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13ManRay.jpg",
    "time_elapsed": 1182095
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "cool, light, crisp, stark",
    "row": 4676,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "13grablegung.jpg",
    "distractorTwo": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "13Klee1.jpg",
    "time_elapsed": 1223175
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "bright, colourful, bold, dynamic, mixed",
    "row": 4677,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 1293445
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "sponge-effect, warm, cool, fresh, mediterranean, still",
    "row": 4678,
    "subject_id": "5f80b82e7548d3125787783a",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 1358226
  },
  {
    "target_image": "13Marquet.jpg",
    "responses": "colourful, detailed",
    "row": 4639,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 832849
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "sharp, defined",
    "row": 4640,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13Klee1.jpg",
    "time_elapsed": 889261
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "pastel, soft, dreamy, subdued",
    "row": 4641,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 965446
  },
  {
    "target_image": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "earthy, dark",
    "row": 4642,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13Kline1.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 1009062
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "defined shaped, slightly cool, contrast",
    "row": 4643,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 1096622
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "light, cool, pastel soft",
    "row": 4644,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 1133999
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurred, hazy, warm",
    "row": 4645,
    "subject_id": "5f19675f002f9a01e273dc57",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 1167817
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "hot, bright",
    "row": 4606,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13Klimt1.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 715071
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "varied, constrasting",
    "row": 4607,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 745295
  },
  {
    "target_image": "13Chirico.jpg",
    "responses": "dark, textured",
    "row": 4608,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 755932
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "inverted, unblended",
    "row": 4609,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 792714
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "bright, indistinct",
    "row": 4610,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 813023
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "dark, blurred",
    "row": 4611,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 1148147
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "cold, colourful, vibrant",
    "row": 4612,
    "subject_id": "5f3dc6a9e5391b1d7eea62f8",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1209867
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "Deep learning, impressionist, abstract, bright,",
    "row": 4573,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13Ingleside.jpg",
    "time_elapsed": 646538
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "Post impressionist, pastel, soft, warm, blurry",
    "row": 4574,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 697393
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "Dark, moist, high contrast, lush,",
    "row": 4575,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 751929
  },
  {
    "target_image": "13Chirico.jpg",
    "responses": "Vintage, dark, tapestry, swirled,",
    "row": 4576,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13Klee1.jpg",
    "time_elapsed": 804242
  },
  {
    "target_image": "13the-liver-is-the-cock-s-comb.jpg",
    "responses": "Abstract, blown out, swirled, blurred, twisted,",
    "row": 4577,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 866233
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "Dark, dim, scary, chameleon",
    "row": 4578,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 918849
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Blown out, warm, bursting, faded, swirled",
    "row": 4579,
    "subject_id": "5fc48a83c38b8d430bf3e14c",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 962289
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "bright, messy",
    "row": 4540,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "13grablegung.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 764300
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "unknown, fuzzy",
    "row": 4541,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 799206
  },
  {
    "target_image": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "sad, dark",
    "row": 4542,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 816105
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "hallucinogenic, chaos",
    "row": 4543,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 882892
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "hope, light",
    "row": 4544,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "13Picasso.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 947681
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "heavy, dark",
    "row": 4545,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 1001375
  },
  {
    "target_image": "13Klee2.jpg",
    "responses": "heavenly, smoggy",
    "row": 4546,
    "subject_id": "5c871ab7de75d4001602869d",
    "distractorOne": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 1030921
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "light, pastel",
    "row": 4507,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 771196
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "Colourful, abstract, bright",
    "row": 4508,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 801994
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "blurred, stippled, colourful",
    "row": 4509,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 844696
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "Dark, moody",
    "row": 4510,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "13Mondrian3.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 863935
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "Dark, pastel, blurred",
    "row": 4511,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 890643
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "Bright, vibrant, colourful",
    "row": 4512,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 917945
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "Warm, deep",
    "row": 4513,
    "subject_id": "5de57a5b1017854f8a4efca3",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 963371
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "colourful, blotchy, blurry,",
    "row": 4474,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13Klimt1.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 452121
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "blurry, soft, blended,",
    "row": 4475,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 498049
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "calm, blurry, light, peaceful",
    "row": 4476,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 541564
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "bright, harsh, abstract, blurred,",
    "row": 4477,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 573742
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "blended, blurry, colourful, harsh,",
    "row": 4478,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 598312
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "abstract, bright, blended, light,",
    "row": 4479,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 635921
  },
  {
    "target_image": "13EdgarDegas.jpg",
    "responses": "semi-dark, blurry, blended, soft, mixed,",
    "row": 4480,
    "subject_id": "5bef31aa059b3200010715dc",
    "distractorOne": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 684029
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "colourful, manic, detailed cold",
    "row": 4441,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 570675
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "warm, neutral,",
    "row": 4442,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 597971
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "darl, cold, lonely",
    "row": 4443,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13the-row.jpg!Large.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 616279
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "blurry, colourful, warm, exciting",
    "row": 4444,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 645637
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "hot, neutral, splash of colour",
    "row": 4445,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 664958
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "warm neutral colourful",
    "row": 4446,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 684296
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "neutral, day",
    "row": 4447,
    "subject_id": "5edf9c64ecf5a026f9fd3464",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 700943
  },
  {
    "target_image": "13portrait-of-daughter-1912.jpg",
    "responses": "hazy, unrealistic, all over the place, out there",
    "row": 4408,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 845178
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "calm, monotone, relaxed",
    "row": 4409,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 859860
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "Warm, friendly, soft-hearted",
    "row": 4410,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 884621
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "Realistic, blurry, natural, authentic",
    "row": 4411,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 898970
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "Natural, woodsy, outdoorsy",
    "row": 4412,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 912956
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "Abstract, hazy, blurry",
    "row": 4413,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 930125
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "Monotone, modern, blurry",
    "row": 4414,
    "subject_id": "5be87e33a14b540001aa2ea5",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13the-row.jpg!Large.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 941295
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "Neutral, Bland, One-Dimensional",
    "row": 4375,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 644526
  },
  {
    "target_image": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "Blurry, Conventional, Conservative",
    "row": 4376,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 679689
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "Dark, Mystique, Mystery, deep colors",
    "row": 4377,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "13Marquet.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 695646
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "Evil, Scary",
    "row": 4378,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "13Rothko2.jpg",
    "distractorTwo": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 729064
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "Pale, Light, Ethereal",
    "row": 4379,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13Ingleside.jpg",
    "time_elapsed": 890162
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "Artistic, abstract, Mysterious",
    "row": 4380,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 907188
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "Bright, Bold, Fuzzy",
    "row": 4381,
    "subject_id": "5c79bc94d454af00160e2eee",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 966466
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Bright, Fire",
    "row": 4342,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 819974
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "Rainbow, Colourful, Bright",
    "row": 4343,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13still-life.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 832580
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "Nice, Focused Well",
    "row": 4344,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "13Matisse.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 862246
  },
  {
    "target_image": "13the-liver-is-the-cock-s-comb.jpg",
    "responses": "Bright, Graffiti, Bold",
    "row": 4345,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 879529
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "Unique, Nice, Good Focus on Flowers",
    "row": 4346,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 903465
  },
  {
    "target_image": "13Marquet.jpg",
    "responses": "Abnormal, Rainbow",
    "row": 4347,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 921802
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "Different, Animal, Cool",
    "row": 4348,
    "subject_id": "5e88754ed1170a4fc39435e4",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 940236
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "darkening, unfocused, dull",
    "row": 4309,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13Pollock1.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 544873
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "variety, bright, multitude",
    "row": 4310,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 578273
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "blurred, light, pale",
    "row": 4311,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "13Rothko2.jpg",
    "distractorTwo": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 631834
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "bright, sunny, blurred,",
    "row": 4312,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 671666
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "variety, stripes. bright",
    "row": 4313,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 710090
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "blurred, deep, dark",
    "row": 4314,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "13girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13dd101419.jpg!Large.jpg",
    "time_elapsed": 743897
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "pale, sunlight, lumpy, sandy",
    "row": 4315,
    "subject_id": "57b8e70f35624400013d690c",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 780345
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "pastel, soft, pale, tender",
    "row": 4276,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 548124
  },
  {
    "target_image": "13the-liver-is-the-cock-s-comb.jpg",
    "responses": "kaleidoscope, vibrant, hues,  intricate, fiery",
    "row": 4277,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "13Mondrian3.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13porch-ii-1947.jpg",
    "time_elapsed": 560436
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "lukewarm, blurred, undefined, mid, depressing.",
    "row": 4278,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 592772
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "warmish, impressionistic, hay fields",
    "row": 4279,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 633788
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "warm, glowing, feminine, bold, saturated.",
    "row": 4280,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13ManRay.jpg",
    "time_elapsed": 662388
  },
  {
    "target_image": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "angular, warmish, scratched.",
    "row": 4281,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 678724
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "warm, glowing, bold, super-saturated, smeared",
    "row": 4282,
    "subject_id": "5fee5c55878eaa15ebc56b26",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 732492
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "old, low hue",
    "row": 4243,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 552344
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "warm, pastel",
    "row": 4244,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 559353
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "distorted",
    "row": 4245,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 574246
  },
  {
    "target_image": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "blurred, dynamic",
    "row": 4246,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 592082
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "old photograph, fuzzy",
    "row": 4247,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 604743
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "old painting, pastel coloured",
    "row": 4248,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 617532
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "surreal, colourful",
    "row": 4249,
    "subject_id": "5c5108e39c016f0001f53d82",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 630298
  },
  {
    "target_image": "13dd101419.jpg!Large.jpg",
    "responses": "dark, gloomy, mysterious",
    "row": 4210,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 541263
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "blurred, gloomy, smooth",
    "row": 4211,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 560112
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "abstract, gloomy, pastel",
    "row": 4212,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 598987
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "light, pastel, sharp, blocks",
    "row": 4213,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 619188
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "pastel, blurred, mysterious, glow",
    "row": 4214,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13Pollock1.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 673999
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "bright, happy, pastel, blurred",
    "row": 4215,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 686885
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "sharp",
    "row": 4216,
    "subject_id": "5c35655f87b777000170d85a",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 718543
  },
  {
    "target_image": "13portrait-of-daughter-1912.jpg",
    "responses": "bright, fluoro, colourful, iridescent, stained glass",
    "row": 4177,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13Kline2.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 466616
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "pastel, sandy, broad brush, desert, drought, bush fire",
    "row": 4178,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 496136
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "blurred, pastel, broad brush, soft, calm",
    "row": 4179,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 520520
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "blurred, sandy, warm, heat, blurred",
    "row": 4180,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 547353
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "blurred, out of focus, high contrast, dull, cold, dusty",
    "row": 4181,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 579376
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "heat, heat waves, warm ,sunny, blurred, wavy, bushfire",
    "row": 4182,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 604065
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "bright, high contrast, colourful, stark, indistinct, confusing, chaos",
    "row": 4183,
    "subject_id": "5c3c1728bc64440001349812",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 639593
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "asbtract, surrealism, collage, dark, contrasting, foreboding, lively,",
    "row": 4144,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13Kline1.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 605667
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "asbtract, surrealism, impressionism, portrait, floral, pastel, warm, tonal,hue,",
    "row": 4145,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "13Rothko2.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 645954
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "bright, watercolour, rainbow, hue, summery, vibrant, eye-catching, spectrum, palette, fluorescent, illuminating, pastel, tonal, warm,",
    "row": 4146,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 669169
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "dark, brooding, broken, ethereal, surreal, abstract, shadowy, sinister, striking, colourful, warm,",
    "row": 4147,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 674672
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "bright, clourful, contrasting, uplifting, broken,",
    "row": 4148,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 683431
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "asbtract, surrealism, collage, bright, contrasting, lively, jubilant, colourful,",
    "row": 4149,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 690288
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "dark, brooding, broken, ethereal, surreal, abstract, shadowy, sinister, striking, colourful, warm,",
    "row": 4150,
    "subject_id": "5f0ee1c5befb85011c91daf4",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 701718
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "whirly",
    "row": 4111,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 501637
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "cohesive, crayons",
    "row": 4112,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 533174
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "greyscale, distorted, xray",
    "row": 4113,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 569688
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "dark, scary, inward",
    "row": 4114,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 603565
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "washed, creamy, tired",
    "row": 4115,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13Klee1.jpg",
    "time_elapsed": 621637
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "burnt, harsh, scolded",
    "row": 4116,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 636713
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "sputtered, crimped, tight",
    "row": 4117,
    "subject_id": "5f349eb6628adc3c59ae4f68",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 672213
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "classic, water color, quite clear",
    "row": 4078,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 402035
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "not too colorful, darkish, quite clear, wavey",
    "row": 4079,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13ManRay.jpg",
    "time_elapsed": 459120
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "colorful, bright",
    "row": 4080,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 490578
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "dark haze,",
    "row": 4082,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 517745
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "bland, darker, more detailed",
    "row": 4083,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13Klee1.jpg",
    "time_elapsed": 549465
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "fake, quite bright, fragmented, line pattern",
    "row": 4084,
    "subject_id": "5e8deb648c085a0643af9567",
    "distractorOne": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "13still-life.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 598937
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "realistic, clear, unfiltered, dark",
    "row": 4045,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 446054
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "warm toned, light, bright,",
    "row": 4046,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 463771
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "cool toned, vivid, difficult to decipher",
    "row": 4047,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13Ingleside.jpg",
    "time_elapsed": 495908
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "cool toned, blurry, hazy, colourful",
    "row": 4048,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13Pollock1.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 513024
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "warm toned, hazy, blurry,",
    "row": 4049,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 536581
  },
  {
    "target_image": "13ManRay.jpg",
    "responses": "pastel, abstract, heavily filtered, light, bright",
    "row": 4050,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 552921
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "medium filter, mix of colours, colourful border",
    "row": 4051,
    "subject_id": "5cabaa10ed17090015e1eb75",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 603445
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "cool, hasty",
    "row": 4012,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 352362
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "realistic, muted",
    "row": 4013,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 367981
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "dark, reverse shadows, linear",
    "row": 4014,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 412771
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "cool, blurry, realistic",
    "row": 4015,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 426114
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "warm, dull, textured",
    "row": 4016,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 448440
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "muted, realistic",
    "row": 4017,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 474904
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "old ladyish",
    "row": 4018,
    "subject_id": "601981d7485c3e0a342183a5",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 499001
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "warped, sunny, weird",
    "row": 3979,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 334191
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "dark, sunset, fuzzy",
    "row": 3980,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 351135
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "weird, smudged, wobbly",
    "row": 3981,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 472938
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "warped, abstract,",
    "row": 3982,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 494879
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "fuzzy, blurry, muted, night, dusk",
    "row": 3983,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 506894
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "brushed, warped, geometric",
    "row": 3984,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 547500
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "neon, bright, sharp",
    "row": 3985,
    "subject_id": "5c8575d4bb45d10016c9265e",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 564428
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "warped, unstable, clear, bright",
    "row": 3946,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 333279
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "vacuum, bright, distorted",
    "row": 3947,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 370147
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "dulled, unfinished, moderate, broken",
    "row": 3948,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "13Mondrian3.jpg",
    "distractorTwo": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "13Klee1.jpg",
    "time_elapsed": 399205
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "messy, vibrant, colorful, blurry",
    "row": 3949,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "13grablegung.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 427474
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "subdued, dark, pixelated",
    "row": 3950,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "13MaxErnst.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 459305
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "burning, bright, hot",
    "row": 3951,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13the-row.jpg!Large.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 481077
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "cooled, simple, rippled",
    "row": 3952,
    "subject_id": "5ddf08afcb9dd6e746231429",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 497250
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "rocky",
    "row": 3913,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 355757
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "clourful, bright",
    "row": 3914,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 370150
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "dark",
    "row": 3915,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 389508
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "pastal, warm",
    "row": 3916,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 409407
  },
  {
    "target_image": "13the-pink-candle-1910.jpg!Large.jpg",
    "responses": "simple, clear",
    "row": 3917,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 432091
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "nature, pastal, clear",
    "row": 3918,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 461136
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "dark, dull",
    "row": 3919,
    "subject_id": "5e9f4b15daa0ba0ac0d460ea",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 488007
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "Vivid, over-the-top, gaudy",
    "row": 3880,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 357579
  },
  {
    "target_image": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "Scratchy, vertical",
    "row": 3881,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13dd101419.jpg!Large.jpg",
    "time_elapsed": 393473
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "Dotted, stipple, pointillism",
    "row": 3882,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 410297
  },
  {
    "target_image": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "Nostalgic, sunset, rosey",
    "row": 3883,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "13Mondrian3.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 426455
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "Spring, daytime, descriptive",
    "row": 3884,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 467477
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "Implied, intense, fast-movement",
    "row": 3885,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 493666
  },
  {
    "target_image": "13the-row.jpg!Large.jpg",
    "responses": "Wobbly, blurred, distorted",
    "row": 3886,
    "subject_id": "5732cf135bb65700097296b1",
    "distractorOne": "13Rothko2.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 508378
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "whispy,windy",
    "row": 3847,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 369024
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "sunset,campfire",
    "row": 3848,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 399600
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "soft,delicate",
    "row": 3849,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 419343
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "dark,shaded,blurry,edgy",
    "row": 3850,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 440271
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "superblurr,foggy",
    "row": 3851,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 452346
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "ocean,puffy",
    "row": 3852,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "13grablegung.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13madonna-casini.jpg",
    "time_elapsed": 467260
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "blurry,real life,",
    "row": 3853,
    "subject_id": "5e1b4375cd15fa36d5f2c3bd",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 494832
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "blur, neutral, delicate, detailed, tight",
    "row": 3814,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "13porch-ii-1947.jpg",
    "time_elapsed": 420242
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "broad, warm, organic, soft",
    "row": 3815,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 443025
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "dark, warm, dense",
    "row": 3816,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13Kline1.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 453068
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "warm, cubic, sharp, abstract",
    "row": 3817,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 466591
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "soft, cool, layered, dull",
    "row": 3818,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 478770
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "cool, layered, busy, dense",
    "row": 3819,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 491993
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "soft, blurred, cool-toned",
    "row": 3820,
    "subject_id": "5f5d967f60d7fa5fdca4cc4f",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 507418
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "pastel, soft, bright, fuzzy",
    "row": 3781,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 298766
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "pastel, soft, muted, fuzzy",
    "row": 3782,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 317474
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "bright, saturated, blurry",
    "row": 3783,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 341475
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "soft, bright, dark",
    "row": 3784,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13Pollock1.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 354317
  },
  {
    "target_image": "13Marquet.jpg",
    "responses": "sharp, rainbow, bright, light",
    "row": 3785,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 368190
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "monotone, sharp, bright",
    "row": 3786,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 382951
  },
  {
    "target_image": "13EdgarDegas.jpg",
    "responses": "fuzzy, saturated, bright",
    "row": 3787,
    "subject_id": "5ddb1206e2dcbda78d24ee70",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 397393
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "light, clear",
    "row": 3748,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 335398
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "autumnal, warm",
    "row": 3749,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 350708
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "golden, hazy",
    "row": 3750,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 357271
  },
  {
    "target_image": "13EdgarDegas.jpg",
    "responses": "autumnal, warm",
    "row": 3751,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 377515
  },
  {
    "target_image": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "bold, colorful",
    "row": 3752,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 402712
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "hazy, pastel",
    "row": 3753,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "13Rothko2.jpg",
    "distractorTwo": "13still-life.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 408358
  },
  {
    "target_image": "13Klee2.jpg",
    "responses": "blurry, warm",
    "row": 3754,
    "subject_id": "5d3658b84f14c3001641516a",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 418875
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "distorted, harsh",
    "row": 3715,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 280231
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "blurry, tinted",
    "row": 3716,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13Kline2.jpg",
    "distractorThree": "13Ingleside.jpg",
    "time_elapsed": 321098
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "colorful, soft",
    "row": 3717,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 333915
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "dark, stained, sharp",
    "row": 3718,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "13Matisse.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 348293
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "colorless, blurry",
    "row": 3719,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 361792
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "painting, abstract",
    "row": 3720,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "13kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 382052
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "soft, muted",
    "row": 3721,
    "subject_id": "5d4a3ff17df55600014ddbd1",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 391345
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "filter, warm",
    "row": 3682,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 156973
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "abstract",
    "row": 3683,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 162414
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "abstract, church-like",
    "row": 3684,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 172965
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "blurred",
    "row": 3685,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "13Picasso.jpg",
    "distractorTwo": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 177245
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "cool, vivid",
    "row": 3686,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "13Mondrian3.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 182965
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "warm",
    "row": 3687,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 188172
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "desert",
    "row": 3688,
    "subject_id": "5d4a41890e604c00011ade8b",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 194188
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "mysterious, bright",
    "row": 3649,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 360462
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "cold, dim",
    "row": 3650,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13porch-ii-1947.jpg",
    "time_elapsed": 366287
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "random, green",
    "row": 3651,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 375331
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "dim",
    "row": 3652,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 381669
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "gray,",
    "row": 3653,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 386435
  },
  {
    "target_image": "13Chirico.jpg",
    "responses": "fire",
    "row": 3655,
    "subject_id": "5b19e01b68a5ed000173631e",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 442548
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "warm, dark, vivid, clear",
    "row": 3616,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 251045
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "blurred, colourful, cheerful",
    "row": 3617,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "13Picasso.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 267466
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "warm, intense, dim, serious",
    "row": 3618,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 285386
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "dull, realistic, cool, clear",
    "row": 3619,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 297216
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "warm, intense, fiery, angry",
    "row": 3620,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13Klimt1.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 316476
  },
  {
    "target_image": "13Chirico.jpg",
    "responses": "clear, realistic",
    "row": 3621,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 339648
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "blurred, mismatch, colourful, confusing",
    "row": 3622,
    "subject_id": "5fc6c12373967e3a9a4c54fe",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 364453
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, blurry",
    "row": 3583,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 286125
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "dark, abstract",
    "row": 3584,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 302202
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "abstract, pastel",
    "row": 3585,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 312551
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "nondescript, abstract, pastel",
    "row": 3586,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 330361
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "pastel, abstract",
    "row": 3587,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 340307
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "abstract, pastel",
    "row": 3588,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13porch-ii-1947.jpg",
    "time_elapsed": 377370
  },
  {
    "target_image": "13the-row.jpg!Large.jpg",
    "responses": "abstract, watercolor",
    "row": 3589,
    "subject_id": "6008f3fa7177ca059d268e0b",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 389490
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "blurry, warm, sunny",
    "row": 3550,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 311400
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "dreamy, grainy, cool",
    "row": 3551,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 326633
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "midtone, natural",
    "row": 3552,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 342856
  },
  {
    "target_image": "13ManRay.jpg",
    "responses": "colorful, outlines, bright",
    "row": 3553,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 367253
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "autumny, warm, simple",
    "row": 3554,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13still-life.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 383705
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "blocky, bright, colorful, stylized",
    "row": 3555,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 395607
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "stylized, desaturated, blocky, unclear",
    "row": 3556,
    "subject_id": "5ec70a378fd0f014915afeac",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13the-row.jpg!Large.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 420335
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "Brushed, pastel",
    "row": 3517,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "13girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 288157
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "Blurry",
    "row": 3518,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 296584
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "Hazy, distorted",
    "row": 3519,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13madonna-casini.jpg",
    "time_elapsed": 308731
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "Swirled",
    "row": 3520,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 313903
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "Pastel",
    "row": 3521,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 319466
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "Mosaic, distorted",
    "row": 3522,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "13Klee1.jpg",
    "time_elapsed": 330364
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "Warm, sketched",
    "row": 3523,
    "subject_id": "5fbdcc31ba05ae2260106c9c",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 341127
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "faded, colorful, grassy",
    "row": 3484,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 228057
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "autumn, outlined, faded",
    "row": 3485,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13ManRay.jpg",
    "time_elapsed": 244536
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "realistic, photographic",
    "row": 3486,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "13Matisse.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 253525
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "abstract, bright, glitched",
    "row": 3487,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 277329
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "dusty, hazy, stretched",
    "row": 3488,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 287206
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "distorted, moving",
    "row": 3489,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 294601
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "filtered, dusky, blurred",
    "row": 3490,
    "subject_id": "5a412f0b99311d0001df431e",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 309598
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "warm",
    "row": 3451,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13Ingleside.jpg",
    "time_elapsed": 153606
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "warm",
    "row": 3452,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 158402
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "monotone",
    "row": 3453,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 160922
  },
  {
    "target_image": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "clear",
    "row": 3454,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 170923
  },
  {
    "target_image": "13the-liver-is-the-cock-s-comb.jpg",
    "responses": "blurred",
    "row": 3455,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 174471
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "mixed",
    "row": 3456,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "13Matisse.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 178550
  },
  {
    "target_image": "13Kline1.jpg",
    "responses": "lines",
    "row": 3457,
    "subject_id": "5ec875255c6a2700081554ac",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 182477
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "animated, brown tones, abstract, clear lines",
    "row": 3418,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 1565972
  },
  {
    "target_image": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "thin lines watercolor, patterns abstract",
    "row": 3419,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "13girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 1663582
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "distorted, meshed colors, blurred",
    "row": 3420,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 1769036
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "distorted, animated, abstract, unrealistic, dull colors",
    "row": 3421,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 1847477
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "very abstract, bright colors",
    "row": 3422,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 1921924
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "animated, brown tones, hint of turquoise abstract, clear lines, earthy",
    "row": 3423,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 2053177
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "blurred, meshed, earth tones, slightly distorted",
    "row": 3424,
    "subject_id": "6004d64f0346c25c8a7eb3f0",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 2125687
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "dark",
    "row": 3385,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 539691
  },
  {
    "target_image": "13EdgarDegas.jpg",
    "responses": "bright, metallic",
    "row": 3386,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 568272
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "blinding",
    "row": 3387,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 576316
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "real, blurred",
    "row": 3388,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 593386
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "metallic",
    "row": 3389,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 609444
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "monotone, high contrast",
    "row": 3390,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 630156
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "bluy",
    "row": 3391,
    "subject_id": "58c565298a3f870001c0e70d",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13Klimt1.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 647981
  },
  {
    "target_image": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "Smooth, Lavender,",
    "row": 3352,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 1381380
  },
  {
    "target_image": "13the-row.jpg!Large.jpg",
    "responses": "Dry, summer,",
    "row": 3353,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "13Matisse.jpg",
    "distractorTwo": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 1574193
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "Grassy all over, Shiny, spots",
    "row": 3354,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 1630152
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "Old fashioned, Grainy, Dry grass",
    "row": 3355,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13Kline2.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 1688169
  },
  {
    "target_image": "13portrait-of-daughter-1912.jpg",
    "responses": "Kaleidoscope, multi-coloured, Bright,",
    "row": 3356,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 1746722
  },
  {
    "target_image": "13Marquet.jpg",
    "responses": "Colourful, ugly, messy",
    "row": 3357,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 1809490
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "Blood bench, Dry grass,",
    "row": 3358,
    "subject_id": "5c055ede1a20110001e9e938",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 1857547
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "confusing, swirling, sad, cold, sketchy",
    "row": 3319,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 1579793
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "shimmer, richter, sad, sparkling, glowing",
    "row": 3320,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 1665005
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "hazy, rainbow, peaceful, sad, colourful",
    "row": 3321,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 1741363
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "blurry, warm, hazy, sad, peaceful",
    "row": 3322,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 1796450
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "cold, sad, wintery, reflective. swirling",
    "row": 3323,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 1862509
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "golden, shimmer, summery, sunny, hazy",
    "row": 3324,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 1892580
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "peaceful, sad, colourful, richter, powerful",
    "row": 3325,
    "subject_id": "5bf7290ed5ec8200015d07e7",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 1962309
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "warm, summer, beam, surrounded",
    "row": 3286,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 1284862
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "dusk, dim, smokey, night, swirl",
    "row": 3287,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 1339526
  },
  {
    "target_image": "13Kline1.jpg",
    "responses": "rainbow, colourful, bright, dim, dusk",
    "row": 3288,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 1394712
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "frosty, dew, crisp, lit, hazey, pointism",
    "row": 3289,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 1458672
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "glow, melting, smokey, ash",
    "row": 3290,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1512935
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "warm, musty, bold, glowing,",
    "row": 3291,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 1591218
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "romantic, subtle, warm, evening, dim,",
    "row": 3292,
    "subject_id": "5f6d1389e5d74817b6231b3b",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13still-life.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 1638988
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "abstract",
    "row": 3253,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 1814190
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "cool",
    "row": 3254,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 1819096
  },
  {
    "target_image": "13ManRay.jpg",
    "responses": "warm",
    "row": 3255,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 1823455
  },
  {
    "target_image": "13Marquet.jpg",
    "responses": "abstract",
    "row": 3256,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 1828132
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "warm",
    "row": 3257,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 1834244
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "warm",
    "row": 3258,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 1838526
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "abstract",
    "row": 3259,
    "subject_id": "5f0a7dec44c42c19a6c9f6d9",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 1847246
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "abstract, edges, shaded",
    "row": 3220,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 1213668
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "sandy, smooth",
    "row": 3221,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 1346164
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "bloody, fuzy, hazy",
    "row": 3222,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 1362516
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "sky, colorful, rainbow",
    "row": 3223,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 1416069
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "fresh, landscape,",
    "row": 3224,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 1449611
  },
  {
    "target_image": "13the-liver-is-the-cock-s-comb.jpg",
    "responses": "abstract, colorful, not-distinct",
    "row": 3225,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13dd101419.jpg!Large.jpg",
    "time_elapsed": 1470346
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "roses, colorful,",
    "row": 3226,
    "subject_id": "6015ce45d4e20d72584594c3",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 1489909
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "warm,Filter, Bright, energetic",
    "row": 3187,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 1163323
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "Stylized,Blocky, Hard to makeout, Unreadable, Dull, bland",
    "row": 3188,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 1220107
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "basic, earthy, warm, dull, bland",
    "row": 3189,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "13Picasso.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 1252494
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "stylized, Bright, 2d outline, Vibrant, balanced warm and cool",
    "row": 3190,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 1317983
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "Most natural, high contrast, earthy, neutral",
    "row": 3191,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 1365269
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "Dull, nuetral, earthy, Most natural, earthy",
    "row": 3192,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 1409457
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "Chaotic,Hard to read, multiple colours, busy, Vibrant",
    "row": 3193,
    "subject_id": "5f89debc12abd1044a5e5c4a",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1465936
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "one colour, blurred, indistinct,",
    "row": 3154,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 757297
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "shapes, rocks, flowers, distinct",
    "row": 3155,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 831312
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dull, shapeless, bold outlines,",
    "row": 3156,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 887103
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "defined, sharp, colourful , stony",
    "row": 3157,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 1011607
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "indistinct, blurred, mishmash, colourful,",
    "row": 3158,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "13Rothko2.jpg",
    "distractorTwo": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 1074949
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "hay, grained, blurred,",
    "row": 3159,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 1126228
  },
  {
    "target_image": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "figure, monotone, dull,",
    "row": 3160,
    "subject_id": "5cd2ee8d66bd5c001747f52e",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 1229516
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "hard chalk, achromatic, fire",
    "row": 3121,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 887895
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "creative",
    "row": 3122,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "13grablegung.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 905407
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "oblique, melancholy",
    "row": 3123,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 925986
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "colourless portrait",
    "row": 3124,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13the-row.jpg!Large.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 950298
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "dark, squiggle",
    "row": 3125,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 965898
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "modern",
    "row": 3126,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13Burliuk.jpg",
    "time_elapsed": 983088
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "digital",
    "row": 3127,
    "subject_id": "5d9e3b307b8a7d00169f35c0",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 991103
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "blurred, pastel, all the images are blurred into one with the distinctive features of the bench only standing out as the tones of the bench is slightly darker than the other elements in the picture",
    "row": 3088,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 762493
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "lots of plant life in this picture, the flowers look as if they are taken from a photo, sharp spiky lines on the grass surrounding the bench",
    "row": 3089,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13Kline2.jpg",
    "distractorThree": "13kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 810236
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "blurred, modernist, big blurs of mostly the same colour, all shown throughout the picture. They do contrast each other somewhat",
    "row": 3090,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 855225
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "Blurred, mixture of colours, very artistic as there are a number of colours that have been bleed in each other to give the picture a different feel",
    "row": 3092,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 899845
  },
  {
    "target_image": "13the-pink-candle-1910.jpg!Large.jpg",
    "responses": "blurred, the picture is stark, there is not much in it apart from the flowers on the bench",
    "row": 3093,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 928712
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "Simplistic, same shades of colour used throughout, the main focus is on the bunch of flowers in the foregram.",
    "row": 3094,
    "subject_id": "5dd5c6599595a158ef0e4e48",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 959320
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurred, warm, windy,",
    "row": 3055,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "13Marquet.jpg",
    "distractorTwo": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 423956
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "graphic, cold, animated",
    "row": 3056,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 436933
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "warm, dark, semi blurry",
    "row": 3057,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 458725
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "warm, bright, animation, semi blur",
    "row": 3058,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 480453
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "graphic, cold, animated, light",
    "row": 3059,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "13MaxErnst.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 496846
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "dark, semi blurred, midnight, cold",
    "row": 3060,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 513385
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "tonal, warm, semi blurred",
    "row": 3061,
    "subject_id": "5ea4cebb8944a8495280db42",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13ManRay.jpg",
    "time_elapsed": 528880
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "smudged, translucent",
    "row": 3022,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 563421
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "monochrome, desaturated,",
    "row": 3023,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13madonna-casini.jpg",
    "time_elapsed": 591015
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "clear, shady, dark",
    "row": 3024,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 613826
  },
  {
    "target_image": "13dd101419.jpg!Large.jpg",
    "responses": "alien, cool, twilight",
    "row": 3025,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13Pollock1.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 673006
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "smooth, calm ,diluted , dull",
    "row": 3026,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "13Picasso.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 727363
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "kaleidoscopic, busy, hectic,",
    "row": 3027,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 769775
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "warm, diluted, dull, hazy,",
    "row": 3028,
    "subject_id": "5c79e0e53454d70014499289",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 804361
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "fragmented, sand-like, multi-coloured, bulky, sharp, contrasting",
    "row": 2989,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "13Rothko2.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 644021
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "blurry, summer-like, fuzzy, mono-chrome, mono-tone",
    "row": 2990,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 688660
  },
  {
    "target_image": "13the-liver-is-the-cock-s-comb.jpg",
    "responses": "explicit, vivid, warm, summer-like",
    "row": 2991,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 711361
  },
  {
    "target_image": "13portrait-of-daughter-1912.jpg",
    "responses": "blurry, dark, autumn-like, diverse, multi-chrome, multi-tone",
    "row": 2992,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 744948
  },
  {
    "target_image": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "mono-tone, mono-chrome, bloody, bright, explicit, vivid, contourful",
    "row": 2993,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 786058
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "multi-chrome, multi-tone, dark, winter-like, blurry, colourful",
    "row": 2994,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 830202
  },
  {
    "target_image": "13Chirico.jpg",
    "responses": "dark, autumn-like, mono-chrome, mono-tone, singular",
    "row": 2995,
    "subject_id": "5e3c759575109a055e99b38a",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 868525
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "plain,  soft, fields",
    "row": 2956,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 579224
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "medium, distinguishable, bench obvious",
    "row": 2957,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 648734
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "dark, plain, colourless",
    "row": 2958,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 678110
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "autumn, distinguishable,",
    "row": 2959,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13porch-ii-1947.jpg",
    "time_elapsed": 717786
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "light, blurred, one colour",
    "row": 2960,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 772643
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dark, obvious, most in focus",
    "row": 2961,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13Ingleside.jpg",
    "time_elapsed": 811737
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "light,",
    "row": 2962,
    "subject_id": "5780d9a1900cc80001d2d1c2",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 852930
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "earthy tones, colour bleeds to the right",
    "row": 2923,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 491842
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "sepia style,",
    "row": 2924,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 522353
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "abstract, mono",
    "row": 2925,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 540858
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "earthy, neutral tones",
    "row": 2926,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 559456
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "more realistic, earth tones",
    "row": 2927,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 589026
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "abstract, bright, two colours",
    "row": 2928,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 625657
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, parrot colours",
    "row": 2929,
    "subject_id": "5eb85f3396c3477b910ed61a",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 647412
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "wavy, flowing, muted, dark",
    "row": 2890,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 427021
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "burnt, picasso-esque, breakdown of standard lines",
    "row": 2891,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 450907
  },
  {
    "target_image": "13the-row.jpg!Large.jpg",
    "responses": "sharper, muted vibrancy, realistic but distorted with enhanced colors",
    "row": 2892,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 490407
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "blurred, morning, movement",
    "row": 2893,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 513107
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "breakdown of lines, bright to be bright, abstract, smaller brushstrokes",
    "row": 2894,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 541345
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "muted but not neutered colors, wavy and distorted but in a smaller way, swirly",
    "row": 2895,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13Burliuk.jpg",
    "time_elapsed": 587437
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, evening, lower end of the colors, but still sharp",
    "row": 2896,
    "subject_id": "5f1a41d3f6dc7613c6e6b406",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 612441
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "hazy, pastel, blurred",
    "row": 2857,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13madonna-casini.jpg",
    "time_elapsed": 453679
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "pixelated, dark, dusk toned",
    "row": 2858,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 481848
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "titian, reflective, sunset",
    "row": 2859,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 534127
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "distorted, wavy, saturated",
    "row": 2860,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 575223
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "oceanic, brush stroked, sundappled",
    "row": 2861,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 601896
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "sandied, angular, advuncular",
    "row": 2862,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 632215
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "autumnal morning, finely detailed",
    "row": 2863,
    "subject_id": "603fad5084b4750912f77008",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 661239
  },
  {
    "target_image": "13the-liver-is-the-cock-s-comb.jpg",
    "responses": "unidentifiable, rainbow",
    "row": 2824,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13porch-ii-1947.jpg",
    "time_elapsed": 385024
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "pixely, clear, spring-like",
    "row": 2825,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "13grablegung.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 412396
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "light, soft",
    "row": 2826,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 424946
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "dark, night, focused",
    "row": 2827,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 439750
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "splattered, normal",
    "row": 2828,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 494799
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "abstract, smeared, soft",
    "row": 2829,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 503207
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "bright, jaded, pastel",
    "row": 2830,
    "subject_id": "5e9aff02f4a78b1a1fe7fc3c",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 517872
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "blurred, colourful, pastel",
    "row": 2791,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 203563
  },
  {
    "target_image": "13Moholy.jpg",
    "responses": "blurry, curved, pastel, light, muted",
    "row": 2792,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 213272
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "contrasting, blurred, drawn, vibrant",
    "row": 2793,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 228607
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "muted, blurred, flat, similar",
    "row": 2794,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 245920
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "forrest, blurred, curved",
    "row": 2795,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 260118
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "muted, simple, blurred, faded, earthy",
    "row": 2796,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 272136
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "contrasting, vibrant, loud, complicated, mixture",
    "row": 2797,
    "subject_id": "602fa0097cdd70cc39cc118f",
    "distractorOne": "13Mondrian3.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 282394
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "Hazy, warm, pastel, nostalgic, sunny",
    "row": 2758,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 2769982
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "Dark, shadowy, moody",
    "row": 2759,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 3062500
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "Bright, summery, impressionist, hazy, dandelion",
    "row": 2760,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 3124515
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "Cool, depressed, morose, forest, dark woods",
    "row": 2761,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 3289078
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "Moldy, subdued, pastel, cloudy, still, quiet",
    "row": 2762,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 3659237
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "Passionate, nostalgic, optimistic, focused, realism, tunnel vision",
    "row": 2763,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 5510246
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "cold spring morning, cool, crisp, natural, realistic",
    "row": 2764,
    "subject_id": "586ce5e0ac950900013de2c3",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 5565537
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "cement",
    "row": 2725,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 150299
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "sandy",
    "row": 2726,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 153628
  },
  {
    "target_image": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "toasty",
    "row": 2727,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 159112
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "wavy",
    "row": 2728,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13still-life.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 172017
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "burnt",
    "row": 2729,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 174993
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "desert",
    "row": 2730,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 181287
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "plain",
    "row": 2731,
    "subject_id": "5d6325d535218100017210a2",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 184038
  },
  {
    "target_image": "13ManRay.jpg",
    "responses": "pastel, soft, cartoony, blurry",
    "row": 2692,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 1318429
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "loud, eyesore, dissonant, harsh, messy",
    "row": 2693,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 1388808
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "bleeding, smudge, rocky, barren",
    "row": 2694,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 1629847
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "vintage, classic, polaroid, natural",
    "row": 2695,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 1745661
  },
  {
    "target_image": "13the-pink-candle-1910.jpg!Large.jpg",
    "responses": "sharp, natural, soft",
    "row": 2696,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 2005412
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "instagram filter, romantic, soft",
    "row": 2697,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 2256498
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "marble, blocky, water",
    "row": 2698,
    "subject_id": "5f839c3b6baf3953cf18d606",
    "distractorOne": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 2346611
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "electric, bright, line art, hyper, energetic",
    "row": 2659,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 796501
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "impressionist, simple, cool, watery, flowing, bold, solid",
    "row": 2660,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 884098
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "fuzzy, blurred, warm, high contrast, shaded, dark, muted",
    "row": 2661,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 973034
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "colorful, blurred, smooth, blended, random,",
    "row": 2662,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 1100235
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "modern, thick lined, uniform, bright, warped, confusing",
    "row": 2663,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "13Klee1.jpg",
    "time_elapsed": 1213290
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "pastel, clear, distorted, blended, natural, mixed",
    "row": 2664,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 1322962
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "shaded, dark, natural,  muted, realistic, autumnal, grungy, dank",
    "row": 2665,
    "subject_id": "5a84f454ae9a0b0001a9e4e5",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 1422736
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "Abstracted until the shapes are almost unrecognisable, reduced to streaks splashed over the top with blurry, misty patches of hot colour",
    "row": 2626,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1024996
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "Very close to the original photograph, muted and slightly impressionistic but with all features clearly recognisable",
    "row": 2627,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 1094372
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "Very bright and sunny, mildly abstracted, I can see msot of the features of the original image but if I didn't know what they were meant to be I might not recognise them",
    "row": 2628,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 1192051
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "Realistic, with the elements of the photo' easy to identify, but overlaid by wide ripples of hot and cold colour running towards and away from the viewer",
    "row": 2629,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 1276695
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "Realistic, all elements easy to identify, but in washed-out watercolour tones and slightly smudged",
    "row": 2630,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 1346210
  },
  {
    "target_image": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "In the original colours but darker and more grainy, with the distance quite clear but the foreground very blurry, aside from the flowers which are almost photographically sharp",
    "row": 2631,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 1491815
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "Hot autumn colours with a splotch of bright colour at right foreground, and the whole foreground image smearing into distorted horizontal streaks",
    "row": 2632,
    "subject_id": "5e1e5c3c80e02e1c36679187",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 1584926
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "lonely, grieving, isolated, lonely",
    "row": 2593,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 999371
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "relaxed, cracked, hurt, hidden, blended",
    "row": 2594,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 1091825
  },
  {
    "target_image": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "hazy, warm, basking, sunny, summery",
    "row": 2595,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13Kline1.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 1144778
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "disintegrating, heavy, overflowing,  broken, stoney",
    "row": 2596,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13Pollock1.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 1232461
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "warm, bleeding, lonely",
    "row": 2597,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1412219
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "drowning, overwhelmed, bathing, storm",
    "row": 2598,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 1478380
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "hidden, blended, camouflaged, hide and seek",
    "row": 2599,
    "subject_id": "5ef24f45ba594791fb6cb88d",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13Burliuk.jpg",
    "time_elapsed": 1557951
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "warm and cool colors, semi-dark, blurred, distinct lines",
    "row": 2560,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 1029546
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "multi-colored, colorful, dark, warm and cool, bold colors",
    "row": 2561,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 1104899
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "colorful, muted, blurred, fuzzy, watercolor, earth tones",
    "row": 2562,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 1153687
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "pop of color, muted, blurred, abstract, mostly earth tones",
    "row": 2563,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "13girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13Burliuk.jpg",
    "time_elapsed": 1272631
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "colorful, bright colors, blurred, watercolor, tranquil",
    "row": 2564,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 1341794
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "colorful, blurred, pops of color, warm and cool colors",
    "row": 2565,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "13Mondrian3.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 1410764
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "cool colors, fuzzy",
    "row": 2566,
    "subject_id": "5fadd628cd4e9e1c42dab969",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1522845
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "brushstrokes are neither blurry nor exceptionally sharp in detail, simple colors, sad, but also a bit warm",
    "row": 2527,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 1061990
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "out of the two where you can see the detail in a featured flower piece, this is the less intense one,simple, generic, a popular centerpiece, blurry table",
    "row": 2528,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1168819
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "overcast, lonely, simple, clear",
    "row": 2529,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 1201930
  },
  {
    "target_image": "13dd101419.jpg!Large.jpg",
    "responses": "dark, contrast of the table verse a blurry background, stained glass window",
    "row": 2530,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 1241621
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "Garden, warm, blotchy, ugly but in a beautiful way",
    "row": 2531,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 1280411
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "darkest table, conflicting double color comparison in-center, smudged border, dark Center",
    "row": 2532,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 1337998
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "busy, crazy, electronic, Minnie Sharp lines in various directions",
    "row": 2533,
    "subject_id": "5f5f26703e0a0500093457fc",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 1368914
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "lifelike, colourful, daytime",
    "row": 2494,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 978449
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "dull, muted",
    "row": 2495,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 1007150
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "true to life,",
    "row": 2496,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 1050883
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "blured, dull",
    "row": 2497,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 1105692
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "muted, true to life, dark",
    "row": 2498,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 1154665
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "pale, realistic, muted",
    "row": 2499,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 1187382
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "bendy, muted",
    "row": 2500,
    "subject_id": "6018880c76e9e614739fde32",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 1227834
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "bright, warm",
    "row": 2461,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 475220
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "colorful, blended",
    "row": 2462,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 511652
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "sad, clear background",
    "row": 2463,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13madonna-casini.jpg",
    "time_elapsed": 561980
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "Thanksgiving filter",
    "row": 2464,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 667036
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "autumn",
    "row": 2465,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 718460
  },
  {
    "target_image": "13the-pink-candle-1910.jpg!Large.jpg",
    "responses": "smooth, eerie",
    "row": 2466,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 779149
  },
  {
    "target_image": "13Kline1.jpg",
    "responses": "ventilated, striking, horizontal edges",
    "row": 2467,
    "subject_id": "5c98310742270c0014d0287a",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 821437
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "abstract, blending, modern, surreal",
    "row": 2428,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 592751
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "holographic, faded, mod",
    "row": 2429,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 625846
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "realistic, Cezanne-like",
    "row": 2430,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13Klimt1.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 653662
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "surreal, bold, postmodern, streamer-like, abstract",
    "row": 2431,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 699654
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "holographic, photographic, morning-light, vibrant",
    "row": 2432,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 740771
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "cubist, modern, swirly, fuzzy, bright, bold",
    "row": 2433,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 795816
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "warped, wavy, bold, realistic",
    "row": 2434,
    "subject_id": "5edfb0770fb0722aa3839b6d",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 830000
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "COLOURFUL",
    "row": 2395,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 556260
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "DULL, CLEAR",
    "row": 2396,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 575458
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "COLOURFUL, SHAPES,",
    "row": 2397,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 593364
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "OLD, CLEAR",
    "row": 2398,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 632402
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "BLURRED",
    "row": 2399,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 697313
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "ABSTRACT",
    "row": 2400,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 709423
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "CREATIVE, EARTH, CLEAR",
    "row": 2401,
    "subject_id": "5f54d772f5bba984fdf8676e",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 734461
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "realistic, blurry, distorted, bland, plain",
    "row": 2362,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 324143
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "distorted, glowy, warm, still",
    "row": 2363,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 356694
  },
  {
    "target_image": "13Moholy.jpg",
    "responses": "crazy, disorganised, flat",
    "row": 2364,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 388709
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "warm, aggressive, sharp",
    "row": 2365,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 434845
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "earthy, streamy",
    "row": 2366,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13Pollock1.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 471838
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "washed out, odd, weird",
    "row": 2367,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 509025
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "low detail, simplistic, blocky",
    "row": 2368,
    "subject_id": "5630b79b733ea00011164946",
    "distractorOne": "13grablegung.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 530232
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "dust",
    "row": 2329,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 653960
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "gloomy",
    "row": 2330,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 670977
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "artistic",
    "row": 2331,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 694146
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "colorful",
    "row": 2332,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 733546
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "blurry",
    "row": 2333,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 742953
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "colorful",
    "row": 2334,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 758747
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "dusty, blurry",
    "row": 2335,
    "subject_id": "5b25d4db0ec82d0001d1fdde",
    "distractorOne": "13Marquet.jpg",
    "distractorTwo": "13Kline1.jpg",
    "distractorThree": "13porch-ii-1947.jpg",
    "time_elapsed": 768397
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "desert bloom",
    "row": 2296,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "13Matisse.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 527380
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "feeling blue",
    "row": 2297,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 564241
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "forest moss",
    "row": 2298,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 595572
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "muted hues",
    "row": 2299,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 620780
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "zigzag",
    "row": 2300,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 658134
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "dark,dreary",
    "row": 2301,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 670690
  },
  {
    "target_image": "13Marquet.jpg",
    "responses": "abstract",
    "row": 2302,
    "subject_id": "5c7b25a44660bf0013c73198",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 693022
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "bizarre, rocky, colorful, patterned",
    "row": 2263,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 458258
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "grainy, spray,",
    "row": 2264,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 491798
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "warm, fiery, bright,",
    "row": 2265,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 523428
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "bizarre, wild, ordered, edged",
    "row": 2266,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 572138
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "gradiated, colorful, drab, simplified",
    "row": 2267,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 624585
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "warm, bright, blurred, obscured",
    "row": 2268,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "13Kline2.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 644780
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "cheerful, wonder, vibrant, trippy flowing",
    "row": 2269,
    "subject_id": "5bf3761862e1bc0001f15cb2",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 670505
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "Blurry, dull, realistic, calm",
    "row": 2230,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 377506
  },
  {
    "target_image": "13the-liver-is-the-cock-s-comb.jpg",
    "responses": "Chaotic, colourful, claustrophobic, aggressive",
    "row": 2231,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13Pollock1.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 393937
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "Nature, impressionist, complicated",
    "row": 2232,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 437899
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "Blurry, dreamy, stretching",
    "row": 2233,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13madonna-casini.jpg",
    "time_elapsed": 496085
  },
  {
    "target_image": "13the-pink-candle-1910.jpg!Large.jpg",
    "responses": "Blood, warm, melting, spring",
    "row": 2234,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 534293
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "Chaotic, sharp, aggressive, unpleasant",
    "row": 2235,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 570066
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "Neat, impressionist, lines",
    "row": 2236,
    "subject_id": "5da8d0f95af0e400163fdfe6",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 618985
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "blurry, unfocussed, dark",
    "row": 2197,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 512113
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "pastels, light",
    "row": 2198,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 526124
  },
  {
    "target_image": "13Kline1.jpg",
    "responses": "dark, muted, color",
    "row": 2199,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 550885
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "pastels, colorful",
    "row": 2200,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 584273
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "darker, clearer, realistic",
    "row": 2201,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 616087
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "warm, fiery, hell, glowing",
    "row": 2202,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 635134
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "bright, sunny, unfocussed, blurry",
    "row": 2203,
    "subject_id": "5ff12028e6b281575462ddf6",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 659392
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "warm, fuzzy, bright",
    "row": 2164,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 513300
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "cool, light spotty",
    "row": 2165,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "13Klimt1.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 527752
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "cool, light clear",
    "row": 2166,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 535963
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "vibrant, hazy",
    "row": 2167,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13Kline2.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 547689
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "light, warm",
    "row": 2168,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "13MaxErnst.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 556756
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "hazy, warm, blurred",
    "row": 2169,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 565898
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "sharp, cool, light",
    "row": 2170,
    "subject_id": "5ec9d530f7f5db50c71639de",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 574246
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "grain, paint, soft",
    "row": 2131,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 436460
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "smooth, spectrum, light",
    "row": 2132,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 450553
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "pastel, soft, smooth, calm",
    "row": 2133,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 463663
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "sober, warm, light, inviting, calm",
    "row": 2134,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 485484
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "bold, loud, outstanding, noise",
    "row": 2135,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 504675
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "hard, bold, statement, cold, spectrum",
    "row": 2136,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "13Marquet.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 522795
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "noise, hard, big",
    "row": 2137,
    "subject_id": "60205f5ba5fe0165fa0e5e01",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 540088
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "abstract, blocky, monochromatic, cool, hallucination, cuboid",
    "row": 2098,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 423323
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "cool, blurry, dreamy, colourful, abstract,",
    "row": 2099,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 446194
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "defined, warm, sunset, evening,",
    "row": 2100,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 465833
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "defined, cool, evening, winter, clear",
    "row": 2101,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 477990
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "colourful, evening, dream, defined, cool",
    "row": 2102,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 503311
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "dreamy, colourful, warm, fire, sunset, abstract",
    "row": 2103,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 528646
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "dreamy, abstract, blocky, lines, colourful, evening",
    "row": 2104,
    "subject_id": "5fb99d0b21064d8a1bf8d227",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 542700
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "blurry, cool, pastel",
    "row": 2065,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 393638
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "blurry, pastel, spotted, bright",
    "row": 2066,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 414612
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "dark, dreary, cool",
    "row": 2067,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 432414
  },
  {
    "target_image": "13the-pink-candle-1910.jpg!Large.jpg",
    "responses": "warm, faded, pointed",
    "row": 2068,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13porch-ii-1947.jpg",
    "time_elapsed": 459615
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "bright, faded, swirly",
    "row": 2069,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 474805
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "melted, obscure, dark, dreary, cool",
    "row": 2070,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 498206
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "warm, faded, flowered",
    "row": 2071,
    "subject_id": "60061a522e88fb9734f4ee16",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 520803
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "muted, pop of colour, rainbow, dull",
    "row": 2032,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 403454
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "dull, dark, warped",
    "row": 2033,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13Kline2.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 437436
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "bright, sunny, painting",
    "row": 2034,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 463522
  },
  {
    "target_image": "13Chirico.jpg",
    "responses": "grungy, warped, dark, textured",
    "row": 2035,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 479679
  },
  {
    "target_image": "13ManRay.jpg",
    "responses": "pastel, colour blocking, warm, abstract",
    "row": 2036,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 506594
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "blurred, rainbow, bright",
    "row": 2037,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 518461
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "fire, passion, bright",
    "row": 2038,
    "subject_id": "602fd61f2b8e88d3dd9b100f",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 535565
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "warm",
    "row": 1999,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 388690
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "vivid",
    "row": 2000,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 404423
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "clear",
    "row": 2001,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 421024
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "negative",
    "row": 2002,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 435459
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "morning",
    "row": 2003,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 452333
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "vivid",
    "row": 2004,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 464496
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "vivid",
    "row": 2005,
    "subject_id": "5ea4273e16a0c73bcff9fcb0",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 475943
  },
  {
    "target_image": "13Marquet.jpg",
    "responses": "mixed, blended, fun, unique",
    "row": 1966,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13dd101419.jpg!Large.jpg",
    "time_elapsed": 297714
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "mossy, earthy",
    "row": 1967,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 312290
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "realistic,",
    "row": 1968,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "13Picasso.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 339226
  },
  {
    "target_image": "13ManRay.jpg",
    "responses": "abstract, blended, blocky",
    "row": 1969,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "13Burliuk.jpg",
    "time_elapsed": 362426
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "fun, blended, mixed,",
    "row": 1970,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 379410
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "earthy, faded, bland",
    "row": 1971,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 393858
  },
  {
    "target_image": "13Kline1.jpg",
    "responses": "patchy, mixed,",
    "row": 1972,
    "subject_id": "5c52481296b5130001776b83",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 419906
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "people power",
    "row": 1933,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 254542
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "sitting with the light",
    "row": 1934,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 269903
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "passion, solid",
    "row": 1935,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 299190
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "realistic, low",
    "row": 1936,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 316470
  },
  {
    "target_image": "13ManRay.jpg",
    "responses": "unfinished",
    "row": 1937,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 327670
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "banana dreams",
    "row": 1938,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13Burliuk.jpg",
    "time_elapsed": 340766
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "speckled",
    "row": 1939,
    "subject_id": "5db06709e8d5b50019c3bd88",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 353950
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "colorful",
    "row": 1900,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 344959
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "blurry",
    "row": 1901,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 348420
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "lines",
    "row": 1902,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 355866
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "lines",
    "row": 1903,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 368401
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "zigzag",
    "row": 1904,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 372342
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "designs",
    "row": 1905,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "13Rothko2.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 377186
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "lines",
    "row": 1906,
    "subject_id": "5f218e5462e3b6568de0f0e5",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 387265
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "flower",
    "row": 1867,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 262634
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "evening",
    "row": 1868,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 271486
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "wanting",
    "row": 1869,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 285185
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "mystery",
    "row": 1870,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 298084
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "much",
    "row": 1871,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "13Marquet.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 305605
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "slick",
    "row": 1872,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 313938
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "country",
    "row": 1873,
    "subject_id": "5ca6bbf13b5fcf00100996e9",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 319777
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "warm, abstract",
    "row": 1834,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 269009
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "linear, warm, multicolored, vibrant",
    "row": 1835,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 286867
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "dark, shaded, cool",
    "row": 1836,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 297201
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "dark, shaded, cool",
    "row": 1837,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 302406
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "warm, shaded, fuzzy",
    "row": 1838,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 318314
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "warm, jagged, sunset",
    "row": 1839,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 340319
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "cool, abstract, shadow",
    "row": 1840,
    "subject_id": "5e97af0bca82b6278c859323",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 354960
  },
  {
    "target_image": "13Kline1.jpg",
    "responses": "dark",
    "row": 1801,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 224539
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "pixelated, warm,",
    "row": 1802,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 243950
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "pastel, dreamy,",
    "row": 1803,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 255623
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "warm, fiery,",
    "row": 1804,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 262519
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "earthy",
    "row": 1805,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "13MaxErnst.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 268577
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "cool,",
    "row": 1806,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 276046
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "pastel, bright",
    "row": 1807,
    "subject_id": "601040ff9b33f0304c96a015",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 287060
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "plain",
    "row": 1768,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13madonna-casini.jpg",
    "time_elapsed": 150178
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "primary",
    "row": 1769,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 161521
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "mango",
    "row": 1770,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "13grablegung.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 169757
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "boring",
    "row": 1771,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13Klimt1.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 174969
  },
  {
    "target_image": "13the-row.jpg!Large.jpg",
    "responses": "prismatic",
    "row": 1772,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 185007
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "sandy",
    "row": 1773,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 202950
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "watermelon",
    "row": 1774,
    "subject_id": "601c4c5d32968172b3d4c780",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 207363
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "dreamy, vibrant, washed, dream-like",
    "row": 1735,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 5756834
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "soft, faded, retro, old",
    "row": 1736,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "13girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 5769431
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "growth, control, flushed",
    "row": 1737,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 5788691
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "soft, calm, dreamy",
    "row": 1738,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 5801821
  },
  {
    "target_image": "13Klee2.jpg",
    "responses": "energetic, stressful, buzzing, harsh, bright",
    "row": 1739,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 5815489
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "traditional, old, pastoral, calming, warm",
    "row": 1740,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "13grablegung.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 5830313
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "vibrant, energetic, moving, strong",
    "row": 1741,
    "subject_id": "5601683e77f33b0005cb3635",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 5843291
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "weird, distorted. dull but colourful, flowing",
    "row": 1702,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "13Picasso.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 819543
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "dark, weird, distorted, dull",
    "row": 1703,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 833453
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "weird, soft, boring, strange",
    "row": 1704,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 865157
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "strange, distorted, saturated",
    "row": 1705,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 896356
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "blurred, dark, artisitc",
    "row": 1706,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 927117
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "distorted, dark, weird, dense",
    "row": 1707,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 985406
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "fiery, complex, fascinating, mystical",
    "row": 1708,
    "subject_id": "5b387415b6b4410001610900",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 1050957
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "rough, sharp, bold, strong, lines",
    "row": 1669,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 618129
  },
  {
    "target_image": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "blurred, fire, burnt, warm, fuzzy,",
    "row": 1670,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 691822
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "crumpled, focused, bold, dark,",
    "row": 1671,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 761025
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "fuzzy, warm, soft, old, clear, calm,",
    "row": 1672,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 795269
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "bold, water, smooth, block, strong,",
    "row": 1673,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 862074
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "fuzzy, old, blurred, bright, static, warm, sunny,",
    "row": 1674,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 911433
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "warm, sunny, sun, soft, blurred, smooth,",
    "row": 1675,
    "subject_id": "602114dd0ba5fa02d3b042ee",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 959151
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "unlear image, rainbow variety left of center, bright,",
    "row": 1636,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 810012
  },
  {
    "target_image": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "dull dark but warm , dark sea, cloudy",
    "row": 1637,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 896961
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "dying embers, warm, hazy, defined outlines",
    "row": 1638,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13ManRay.jpg",
    "time_elapsed": 958468
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "photographic, blurry, washed out.",
    "row": 1639,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 990768
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "squares, washed, colourless",
    "row": 1640,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 1005860
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "hay, hazy, firey, some bold outlines",
    "row": 1641,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 1113724
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "sea, bright, bold, undefined",
    "row": 1642,
    "subject_id": "5eedecc6fc7dfe23001eaa76",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 1149427
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "smeared, colourful,",
    "row": 1603,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 336376
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "colourless, sharp light",
    "row": 1604,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 355144
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "watery, blurred, colourless",
    "row": 1605,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 371794
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "watery, blurred centre",
    "row": 1606,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 394650
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "shar, detailed, little colour",
    "row": 1607,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 410609
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "light, bright, very little dark",
    "row": 1608,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13dd101419.jpg!Large.jpg",
    "time_elapsed": 426140
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "colorful, unfinished, watery",
    "row": 1609,
    "subject_id": "5e39dfdc54fca708912dfab5",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 447604
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "blurry, limited colours, dull, not colourful",
    "row": 1570,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 511522
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "slightly blurred, colourful but not bright, limited colours",
    "row": 1571,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 591603
  },
  {
    "target_image": "13Marquet.jpg",
    "responses": "blurred, colourful, mashed up",
    "row": 1572,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 605914
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "colourful, blurred, primary colours",
    "row": 1573,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13porch-ii-1947.jpg",
    "time_elapsed": 626131
  },
  {
    "target_image": "13Klee2.jpg",
    "responses": "blurred, bright",
    "row": 1574,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 637740
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "dull, pastel colours, blurred",
    "row": 1575,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13Burliuk.jpg",
    "time_elapsed": 648892
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "bright colours, variety of colours, feminine colours",
    "row": 1576,
    "subject_id": "5f0495b8daebf80cd275a377",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 675003
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "warm, blury",
    "row": 1537,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13the-row.jpg!Large.jpg",
    "distractorThree": "13Ingleside.jpg",
    "time_elapsed": 649811
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "cold. soft",
    "row": 1538,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 1507355
  },
  {
    "target_image": "13portrait-of-daughter-1912.jpg",
    "responses": "warm, wet",
    "row": 1539,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 2809978
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "sandy, dry, plain",
    "row": 1540,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 2817573
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "dark, forest",
    "row": 1541,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 2964252
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "rainbow, vibrant. happy",
    "row": 1542,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "13girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 3610892
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "stone, dull",
    "row": 1543,
    "subject_id": "603675dd63dac0d18a52fa0f",
    "distractorOne": "13Rothko2.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13dd101419.jpg!Large.jpg",
    "time_elapsed": 3625481
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "heated, strong colours",
    "row": 1504,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13Burliuk.jpg",
    "time_elapsed": 1572299
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "pulled at the corners, focused",
    "row": 1507,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1701435
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "grainy, wheat-looking,",
    "row": 1508,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 1727966
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "baked, blurred",
    "row": 1509,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 1743411
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "dark, royal colours",
    "row": 1510,
    "subject_id": "5cf42528e7c1d1001b527bbc",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 1808038
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "plain, soft, light, ordinary",
    "row": 1471,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 1946917
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "grassy, monochrome, indistinct, blends together",
    "row": 1472,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 2044018
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "warm, simple, regular",
    "row": 1473,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 2142427
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "colourful, cool, blends well",
    "row": 1474,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 2242124
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "very ordinary, simple, lifelike, autumn",
    "row": 1475,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 2418653
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "soft, simple, mellow",
    "row": 1476,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 2450481
  },
  {
    "target_image": "13hoffmann.jpg",
    "responses": "dark, warm, strong",
    "row": 1477,
    "subject_id": "5edf8803c008532459792282",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 2497352
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "abstract, warm",
    "row": 1438,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 514186
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "cool, bright",
    "row": 1439,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 587480
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "blurry, pastel, murky",
    "row": 1440,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 610702
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "bright, pastel, abstract, cool",
    "row": 1441,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 627511
  },
  {
    "target_image": "13Moholy.jpg",
    "responses": "contrasting, vivid, sketchy",
    "row": 1442,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 659541
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "contrasting, vivid, central focus",
    "row": 1443,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13Kline2.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 680750
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "warm, contrasting focus,",
    "row": 1444,
    "subject_id": "5ea9c475ec2b531108f86a3f",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 709406
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "line drawing, defined, natural toned, realistic, clear",
    "row": 1405,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 1283167
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "faded, smudged, blurred, pastel,",
    "row": 1406,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 1304494
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "natural, dull, defined, earthy,",
    "row": 1407,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 1425434
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "bright,  vibrant, reflections, light, natural",
    "row": 1408,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 1481255
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "pastel, smudged, smudged",
    "row": 1409,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1526747
  },
  {
    "target_image": "13Klee2.jpg",
    "responses": "very blurred, smudged, unclear, undefined, blurry, unclear",
    "row": 1410,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 1591426
  },
  {
    "target_image": "13portrait-of-daughter-1912.jpg",
    "responses": "multi tonal, vibrant, colourful, unnatural, imaginative,",
    "row": 1411,
    "subject_id": "5d8cef3c28e183001a335ab0",
    "distractorOne": "13Picasso.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 1653441
  },
  {
    "target_image": "13EdgarDegas.jpg",
    "responses": "bark, wood, oil",
    "row": 1372,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 1868629
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "grass",
    "row": 1373,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1874829
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "sea,ocean",
    "row": 1374,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 1886407
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "forest",
    "row": 1375,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1892023
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "oily, smooth, bark",
    "row": 1376,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "13MaxErnst.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 1912904
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "dark, clear,",
    "row": 1377,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 1930687
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "rainbow, clear",
    "row": 1378,
    "subject_id": "6027dc9475730b07d3a684fd",
    "distractorOne": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 1952464
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "Ravishing, ideal, cool",
    "row": 1339,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 943578
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "fair, splendid, superb",
    "row": 1340,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 967205
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "Sublime",
    "row": 1341,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 981180
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "stunning, lovely, wonderful",
    "row": 1342,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 1004917
  },
  {
    "target_image": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "Ravishing, pleasing",
    "row": 1343,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 1033867
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "Marvelous, alluring, dazzling",
    "row": 1344,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 1043681
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "Symmetrical, well-formed",
    "row": 1345,
    "subject_id": "5f69c502d010ce02b6326b35",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 1070733
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "broad, deep, focused, alternative, blocky",
    "row": 1306,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 916892
  },
  {
    "target_image": "13Kline1.jpg",
    "responses": "linear, squared, blockish, streaky, colourful",
    "row": 1307,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 966034
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "Old, fine, detailed, oiled, soft",
    "row": 1308,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 998304
  },
  {
    "target_image": "13portrait-of-daughter-1912.jpg",
    "responses": "Intense, vivid, Kaleidoscopic, filtered, acidic",
    "row": 1309,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 1055564
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "Sketched, autumnal, faded, detailed, warm",
    "row": 1310,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1116958
  },
  {
    "target_image": "13gladiators-1940.jpg",
    "responses": "Scream, swirling, rouged, indicative, contrasted",
    "row": 1311,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 1215963
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "pastel, sketched, calm, light",
    "row": 1312,
    "subject_id": "600ff015cef0db1e965111d7",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 1275263
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "van gough, sunflower, pointy, dotty, grainy",
    "row": 1273,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 905444
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "smooth, natural, nature, lush",
    "row": 1274,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 959044
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "natural, little flowers instead of grass, bluebells, valentine",
    "row": 1275,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 1102655
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "camouflage, jagged, mazes",
    "row": 1276,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 1158403
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "contrast, lines, negative, dark and bright, neon lights at night",
    "row": 1277,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 1214014
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "smooth, dark, bendy, snow",
    "row": 1278,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 1258241
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "lines, contrast, crazy",
    "row": 1279,
    "subject_id": "5d4e97553ffde500189ad8a2",
    "distractorOne": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 1291823
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "smudgy, hazzy, accurate colouration",
    "row": 1240,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 885562
  },
  {
    "target_image": "13the-liver-is-the-cock-s-comb.jpg",
    "responses": "bold, hedonistic, angry, fire",
    "row": 1241,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 919628
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "depressing, fine detail",
    "row": 1242,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13still-life.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 960717
  },
  {
    "target_image": "13destroyed-place-1920(1).jpg!Large.jpg",
    "responses": "Afternoon light, smudgy but clear,",
    "row": 1243,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 1056515
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "sunny, wishy washy, bold, statement",
    "row": 1244,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 1108015
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "intricate, fine, flowery,",
    "row": 1245,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 1168157
  },
  {
    "target_image": "13EdgarDegas.jpg",
    "responses": "blurry, one dimensional,",
    "row": 1246,
    "subject_id": "56a8bb427f2472000b9522f6",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 1204261
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "Blured,cold,mass of colours.",
    "row": 1207,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 786302
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "Lush,natural colours.",
    "row": 1208,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "13Nay.jpg",
    "distractorTwo": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "13dd101419.jpg!Large.jpg",
    "time_elapsed": 824613
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "Dark,sad and lonely.",
    "row": 1209,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 856862
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "Chaotic,jumbled mix.",
    "row": 1210,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 892743
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "Calm,tranquil and serene.",
    "row": 1211,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13Klee1.jpg",
    "time_elapsed": 918649
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "Angry,menacing,unforgiving.",
    "row": 1212,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 949084
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "Blurred,cool and icy.",
    "row": 1213,
    "subject_id": "5eb7d8ea6b705a701c4c7ff7",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 1028622
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "pastel, fiery, passionate",
    "row": 1174,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 896514
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "blocky, neutral, colourless, bland",
    "row": 1175,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 905959
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "bright, colourful, oil, natural",
    "row": 1176,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 988387
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "fiery, loud, bright, passionate, smooth",
    "row": 1177,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "13grablegung.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 1037663
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "neutral, bland, colourless, dull",
    "row": 1178,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 1078518
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "fiery, dull smooth",
    "row": 1179,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 1157614
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "frantic, earthy, lively",
    "row": 1180,
    "subject_id": "601bef4596efd9620b3891dc",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 1221426
  },
  {
    "target_image": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "sketched, summer, hot",
    "row": 1141,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 790632
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "Autumn, contrasting, over sharp",
    "row": 1142,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 835673
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "blurred autumn sunset, warm, contrasting",
    "row": 1143,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 879888
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "mossy, forest floor, sunlight peeping through trees",
    "row": 1144,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 931489
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "pastel, soft, spring, floral",
    "row": 1145,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 953768
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "late winter sun, cool, rocky, old",
    "row": 1146,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 1007512
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "bright, spring, over exposed, blinding sun",
    "row": 1147,
    "subject_id": "5d1e7bb7de0c2b000198d2ab",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 1056272
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "hot, evening, sunset",
    "row": 1108,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 852570
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "abstract, blotchy",
    "row": 1109,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 879196
  },
  {
    "target_image": "13the-pink-candle-1910.jpg!Large.jpg",
    "responses": "drunk, realistic, wobbly",
    "row": 1110,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 943279
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "realistic, cool, frosty",
    "row": 1111,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13the-row.jpg!Large.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 970674
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "highly coloured, unusual",
    "row": 1112,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 1049110
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "realistic, colourful",
    "row": 1113,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 1089830
  },
  {
    "target_image": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "twilight, arora, romantic",
    "row": 1114,
    "subject_id": "5f54386d18bf9a7b62ba997a",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 1115969
  },
  {
    "target_image": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "Plain, Boring, Uninteresting",
    "row": 1075,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 1021118
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "Delightful, Imaginative, Funky",
    "row": 1076,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1050157
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "Plain, Blurred",
    "row": 1077,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 1075382
  },
  {
    "target_image": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "responses": "Okayish, Unclear",
    "row": 1078,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 1109523
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "Dislike, Boring, Dull",
    "row": 1079,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 1131660
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "Unique, Unusual",
    "row": 1080,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "13Matisse.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13Mondrian.jpg",
    "time_elapsed": 1157183
  },
  {
    "target_image": "13dd101419.jpg!Large.jpg",
    "responses": "Unclear, Dim",
    "row": 1081,
    "subject_id": "5ceac2dd06aa230001363420",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1173542
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "Monochromatic",
    "row": 1042,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 658453
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "Natural, bright",
    "row": 1043,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 696978
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "Geomtric, abstract",
    "row": 1044,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 727975
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "Linear",
    "row": 1045,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 776314
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "Monochromatic, abstract",
    "row": 1046,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 831289
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "Warm, ablaze, monochromatic",
    "row": 1047,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 858962
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "Cool, distorted",
    "row": 1048,
    "subject_id": "5f3f1c283b11702080d443bb",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13madonna-casini.jpg",
    "time_elapsed": 876852
  },
  {
    "target_image": "13the-row.jpg!Large.jpg",
    "responses": "rural, countryside, pretty, peaceful",
    "row": 1009,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 674526
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "late, quiet, darker, contemplative",
    "row": 1010,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 754071
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "countryside, rural, traditional, realistic",
    "row": 1011,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "13Pollock1.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 810518
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "blurred, colourful, modern, excessive",
    "row": 1012,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 856761
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "dark, obscured, blurred, sad",
    "row": 1013,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "13porch-ii-1947.jpg",
    "time_elapsed": 891090
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "light, focused, summer",
    "row": 1014,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 938838
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "autumnal, busy, rural",
    "row": 1015,
    "subject_id": "5e8753cc28aacd3abe3bc37a",
    "distractorOne": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 1003453
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "pastel, bright, sunny",
    "row": 976,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 920018
  },
  {
    "target_image": "13RobertCampin.jpg",
    "responses": "pastel, earthy, nature",
    "row": 977,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 975554
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "bright, sunny, primary",
    "row": 978,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 992732
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "dark, ominous, scary",
    "row": 979,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 1025343
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "earthy, drowned out, subdued",
    "row": 980,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "13Matisse.jpg",
    "distractorTwo": "13Pollock1.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 1062458
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "pastel, picassco, colourful",
    "row": 981,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 1088628
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "wavy, hazy, disorentating",
    "row": 982,
    "subject_id": "600af2831b39da0b9a116754",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 1112228
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "pastel, bright, oil paint",
    "row": 943,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 1154787
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "oil paint, acrylic paint",
    "row": 944,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 1163081
  },
  {
    "target_image": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "acrylic paint",
    "row": 945,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 1173349
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "pastel, bright",
    "row": 946,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 1189263
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "pastel",
    "row": 947,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 1197657
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "acrylic paint, oil paint",
    "row": 948,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 1203527
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "pastel",
    "row": 949,
    "subject_id": "5f02bbeb5ac5f8432d35fddd",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 1211873
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "warm, dry, October, parched",
    "row": 910,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 696013
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "chalk, cool , warm, icy",
    "row": 911,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 740530
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "clear, dense, warm",
    "row": 912,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 798633
  },
  {
    "target_image": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "impressionist, old, dutch,  van goch",
    "row": 913,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 845965
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "modern, crazy, blurred, striking, hot",
    "row": 914,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 870784
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "mixed, 1930's, conflicted, clear, science fiction",
    "row": 915,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 926252
  },
  {
    "target_image": "13Moholy.jpg",
    "responses": "cool, isolation, death,  clear, cold",
    "row": 916,
    "subject_id": "5951e4640dd7710001aebd33",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13Rauschenberg.jpg",
    "time_elapsed": 976654
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "pixelated appearance, autumn background, clear flowers, brush strokes at bottom right,",
    "row": 877,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 670228
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "abstract, horizontal smears, flourescent corner, pastel tones,",
    "row": 878,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13Pollock1.jpg",
    "distractorThree": "13Marquet.jpg",
    "time_elapsed": 711540
  },
  {
    "target_image": "13the-pink-candle-1910.jpg!Large.jpg",
    "responses": "blurred, dark bench side, bloody smears, dull colours",
    "row": 879,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 742645
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "dark, cool palette, brush strokes, flowers quite detailed,",
    "row": 880,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 784915
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "dark, multi coloured background, speckled look, autumnal",
    "row": 881,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 846222
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "very bright blotches, flowers not clear, horizontal bench smears, patches glow brightly,",
    "row": 882,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 890624
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "watercolour type flow of paint, most cool colours, two bright warm patches, swirly,",
    "row": 883,
    "subject_id": "5f40fe967e08c603bdadc7c2",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 936580
  },
  {
    "target_image": "13Marquet.jpg",
    "responses": "colorful,vivid,festive",
    "row": 844,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 708420
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "muddy, drab, blurry",
    "row": 845,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 767121
  },
  {
    "target_image": "13Chirico.jpg",
    "responses": "dark, cold, metallic",
    "row": 846,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 784571
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "blotchy, dark, unclear",
    "row": 847,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 833048
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "pastel, clear, shiny",
    "row": 848,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 857601
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "harsh, bleak, undefined",
    "row": 849,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 880740
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "unclear, muddy, dark",
    "row": 850,
    "subject_id": "5f09f9a38bf3690ea1c20c96",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 906106
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "warm, radioactive, blurry",
    "row": 811,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 546638
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "fuzzy",
    "row": 812,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13Klimt1.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 573182
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "clear, light",
    "row": 813,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 608549
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "distorted, glitchy",
    "row": 814,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 678205
  },
  {
    "target_image": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "responses": "warm, thermal",
    "row": 815,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 695181
  },
  {
    "target_image": "13portrait-of-daughter-1912.jpg",
    "responses": "glitchy, colourful",
    "row": 816,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 714973
  },
  {
    "target_image": "13Kline1.jpg",
    "responses": "digital",
    "row": 817,
    "subject_id": "60070418cbf817133cb398bc",
    "distractorOne": "13MaxErnst.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13ManRay.jpg",
    "time_elapsed": 822980
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "vivid colours, smeared, psychedelic",
    "row": 778,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13Burliuk.jpg",
    "time_elapsed": 424912
  },
  {
    "target_image": "13Moholy.jpg",
    "responses": "wavey, unclear, warm tones",
    "row": 779,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 452269
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "blurred, beach colours",
    "row": 780,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "13Mondrian3.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 469312
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "wavey, unclear, colder tones, trippy",
    "row": 781,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 488446
  },
  {
    "target_image": "13Chirico.jpg",
    "responses": "psychedelic, pastel, colour variety, dull, scenic, serene, peaceful",
    "row": 782,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 495996
  },
  {
    "target_image": "13Kline1.jpg",
    "responses": "abstract, bright colours, focus on the flowers over the scenary",
    "row": 783,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13Klee2.jpg",
    "time_elapsed": 521369
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "wartm tones, calm, peaceful, focus on flowers",
    "row": 784,
    "subject_id": "5f68bfd94119260329247f96",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 545901
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "angry,blury,pixelated",
    "row": 745,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 294615
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "pastels,colourful",
    "row": 746,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13dd101419.jpg!Large.jpg",
    "time_elapsed": 317495
  },
  {
    "target_image": "13Mondrian.jpg",
    "responses": "pastels,blury,hazey,washed out",
    "row": 747,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 351695
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "pixelated,grassy,paints",
    "row": 748,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13the-dream-1910.jpg!Large.jpg",
    "time_elapsed": 396067
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "contrast,dark",
    "row": 749,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 415369
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "defined,broken,autumn",
    "row": 750,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13still-life.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 431919
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "chalky,blocked,pastels,bright,defined",
    "row": 751,
    "subject_id": "56d2fdff321cae000d68d946",
    "distractorOne": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 468814
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "distorted, contorted, uglified,",
    "row": 712,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "13MaxErnst.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 416443
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "almost abstract, unlikeable, beautiful,",
    "row": 713,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 446012
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "dark, mysterious, meaningless,",
    "row": 714,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 470444
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "mashed up, without meaning, senseless,",
    "row": 715,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13Kline1.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 500886
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "sandy, vague, airy, vacuous,",
    "row": 716,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorTwo": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 532430
  },
  {
    "target_image": "13the-row.jpg!Large.jpg",
    "responses": "pointless, not worth looking at, stupid,",
    "row": 717,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 577031
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "pretty, beautiful, lovely,",
    "row": 718,
    "subject_id": "5f33f5c671dbfc2622aecda4",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 592375
  },
  {
    "target_image": "13Richter2.jpg",
    "responses": "blurry, watery, grayscale, dull",
    "row": 679,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 316021
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "light, airy, blurry, springtime",
    "row": 680,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 339548
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "blurry, light, sunny,",
    "row": 681,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 351383
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "dark, blurry, watery",
    "row": 682,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13ManRay.jpg",
    "time_elapsed": 369941
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "light, airy, sunny, blurry",
    "row": 683,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 397325
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "dark, nighttime, blurry, limited",
    "row": 684,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorTwo": "13self-portrait-with-brushes-1942.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 415230
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "dark, gloomy, blurry, messy",
    "row": 685,
    "subject_id": "602520a7131cb02a9887d9dc",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 428133
  },
  {
    "target_image": "13grablegung.jpg",
    "responses": "Soft, hazy, dreamy, warm",
    "row": 646,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 379027
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "Abstract, warm, pastels, soft, melt",
    "row": 647,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorTwo": "13Pollock2.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 414883
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "Evening, oil, contrast, soft",
    "row": 648,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13Kline2.jpg",
    "time_elapsed": 435237
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "Abstract, contrast, distinct, hard, lines,",
    "row": 649,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13EdgarDegas.jpg",
    "time_elapsed": 452868
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "Blur, merge, dusk, sketch",
    "row": 650,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 478860
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "Dim, oil, romantic, dark, suggestive",
    "row": 651,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "13mary-magdalene.jpg!Large.jpg",
    "distractorTwo": "13the-dream-1910.jpg!Large.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 497141
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "Blur, soft, dizzy,",
    "row": 652,
    "subject_id": "5e7b1d9e2113b21196d064cb",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 517038
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "bright,",
    "row": 613,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 373282
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "neutral, sunny",
    "row": 614,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 386548
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "rainbow, colourful",
    "row": 615,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "13Matisse.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 419932
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "dark, squiggly,",
    "row": 616,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 441226
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "dark, moody,",
    "row": 617,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 474924
  },
  {
    "target_image": "13Remebrandt.jpg",
    "responses": "abstract, dark, bright,",
    "row": 618,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13Klee1.jpg",
    "distractorThree": "13self-portrait-with-brushes-1942.jpg",
    "time_elapsed": 487869
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "dark, rainbow,",
    "row": 619,
    "subject_id": "58c3d3caabafb2000142055f",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 504828
  },
  {
    "target_image": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "responses": "centre-focused, abstract colours, odd edges",
    "row": 580,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13Pollock2.jpg",
    "time_elapsed": 401117
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "distored, hightened colours, abstract, blurred",
    "row": 581,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "13Picasso.jpg",
    "distractorTwo": "13Matisse.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 417936
  },
  {
    "target_image": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "responses": "bright, primary colours, blurred",
    "row": 582,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 435044
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "some defined lines, pencil-like style, nearly life-like colours",
    "row": 583,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13Kline2.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 473274
  },
  {
    "target_image": "13Kline1.jpg",
    "responses": "blurred, object in focus, odd squares, unusual colours",
    "row": 584,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 497426
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "distorted, somber colours, highlighted colour",
    "row": 585,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 530867
  },
  {
    "target_image": "13Moholy.jpg",
    "responses": "highly abstract, defined lines",
    "row": 586,
    "subject_id": "5fb65ead69a007166c3863c6",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 557532
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "dark, streaky, night, contrasting, fragmented",
    "row": 547,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13mary-magdalene.jpg!Large.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 425987
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "nature, realistic, calming, soothing",
    "row": 548,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 457261
  },
  {
    "target_image": "13Rothko.jpg",
    "responses": "realistic, earthy, calming",
    "row": 549,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 478903
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "streaky, blurry, hazy, bright, pastels, light, daytime, soothing",
    "row": 550,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 508171
  },
  {
    "target_image": "13Rodchenko1.jpg",
    "responses": "hot, warm, blurry, wavy, streaky",
    "row": 551,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13JeanDupas.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 522227
  },
  {
    "target_image": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "responses": "night, dark, dim, contrasting, filtered",
    "row": 552,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorThree": "13Rozanova2.jpg",
    "time_elapsed": 548818
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "blocky, jagged, jarring, odd, bright, technocoloured",
    "row": 553,
    "subject_id": "5ec175c35c6b2b09036f4158",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 578929
  },
  {
    "target_image": "13dd101419.jpg!Large.jpg",
    "responses": "dark, forbidding, ominous,oversaturated,unclear",
    "row": 514,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "13Klee1.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 361255
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "bright,hyperreal,abstract,vivid",
    "row": 515,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 376547
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "muddy,unclear,uncertain",
    "row": 516,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13kateryna-1951.jpg!Large.jpg",
    "time_elapsed": 402980
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "very abstract,unclear,vivid,muted",
    "row": 517,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 429930
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "false colour,aged,unclear,abstract",
    "row": 518,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13JohnsJasper.jpg",
    "time_elapsed": 459957
  },
  {
    "target_image": "13the-liver-is-the-cock-s-comb.jpg",
    "responses": "totally unclear,abstract,headache-inducing,overbright,twisted",
    "row": 519,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 485212
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "oil painting,muted,muddy,unclear",
    "row": 520,
    "subject_id": "5ea0bddad95b720af8176b58",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13Kline2.jpg",
    "distractorThree": "13Nay.jpg",
    "time_elapsed": 500469
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "two dimensional, colourful, like abstract art,",
    "row": 481,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "13Marquet.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13machine-man-with-spiral-turn-1930.jpg",
    "time_elapsed": 368690
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "reminds me of the scream by van gogh, colour dominant in social media logos",
    "row": 482,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 398554
  },
  {
    "target_image": "13dd101419.jpg!Large.jpg",
    "responses": "dark, foreboding, bouquent in focus",
    "row": 483,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "13girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "13Richter2.jpg",
    "distractorThree": "13ManRay.jpg",
    "time_elapsed": 425011
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "blurry, bright, summer",
    "row": 484,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 454339
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "busy, texture like that of plants",
    "row": 485,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13EdgarDegas.jpg",
    "distractorThree": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "time_elapsed": 477011
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "like a watercolour painting",
    "row": 486,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "13Klimt1.jpg",
    "distractorTwo": "13Remebrandt.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 488452
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "lots of primary colours, bold, blurry",
    "row": 487,
    "subject_id": "5eb4396df04311266e7b5110",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 505468
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "UV, contrasting, muted,",
    "row": 448,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "13girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "13hoffmann.jpg",
    "distractorThree": "13madonna-casini.jpg",
    "time_elapsed": 285392
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "flat, cold, bland,",
    "row": 449,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13Klimt1.jpg",
    "time_elapsed": 297991
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "bold, sharp, dark, deep, dingy, posterise,",
    "row": 450,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13Mondrian.jpg",
    "distractorThree": "13the-pink-candle-1910.jpg!Large.jpg",
    "time_elapsed": 321796
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "disco, soft, cold, dark, lights",
    "row": 451,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 335532
  },
  {
    "target_image": "13dd101419.jpg!Large.jpg",
    "responses": "deep, cold, muted",
    "row": 452,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13portrait-of-daughter-1912.jpg",
    "distractorThree": "13city-of-churches-1918(1).jpg!Large.jpg",
    "time_elapsed": 392814
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "clingfilm, plastic wrap, cold, sharp",
    "row": 453,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 407137
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "sharp, muted, rainbow",
    "row": 454,
    "subject_id": "60267f9883e25930ddac4e5c",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 423100
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "warm, soft, faded, light,",
    "row": 415,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 275157
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "lightest, soft, blurred, faded, dull",
    "row": 416,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "13RobertCampin.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 284712
  },
  {
    "target_image": "13dd101419.jpg!Large.jpg",
    "responses": "darkest, dull, cool, vidid tones, blurred, soft",
    "row": 417,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "13pissaro.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13grablegung.jpg",
    "time_elapsed": 305586
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "dull, dark, stippled, detailed, textured, light.",
    "row": 418,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 359145
  },
  {
    "target_image": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "responses": "warm, stippled, hummed, detailed,",
    "row": 419,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13destroyed-place-1920(1).jpg!Large.jpg",
    "distractorThree": "13hoffmann.jpg",
    "time_elapsed": 395285
  },
  {
    "target_image": "13MaxErnst.jpg",
    "responses": "light, vidid, multi tonal but warm, detailed.",
    "row": 420,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13Ingleside.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 413514
  },
  {
    "target_image": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "responses": "soft, hazy, multi tonal. warm.",
    "row": 421,
    "subject_id": "5f6b3ba9c6e2f22337d854bc",
    "distractorOne": "13Rodchenko1.jpg",
    "distractorTwo": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorThree": "13still-life.jpg",
    "time_elapsed": 429250
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "Sharp, central focus, blended",
    "row": 382,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13Kline2.jpg",
    "distractorThree": "13Moholy.jpg",
    "time_elapsed": 252563
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "overbright, oil, clown",
    "row": 383,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 267844
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "soft, grentle, smudged",
    "row": 384,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 276420
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "dark, ominous, crescendo to right",
    "row": 385,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 289760
  },
  {
    "target_image": "13the-snow-maiden.jpg!Large.jpg",
    "responses": "Monet-esque, dotted, soft colours",
    "row": 386,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "time_elapsed": 306049
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "Abstract, rectangular, blurry",
    "row": 387,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "13Rauschenberg.jpg",
    "distractorTwo": "13still-life.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 318129
  },
  {
    "target_image": "13ballad-of-epona-1900.jpg!Large.jpg",
    "responses": "gentle, creamy, autumnal",
    "row": 388,
    "subject_id": "59df5d5a0fb3a90001bd932b",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 330030
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "fuzzy",
    "row": 349,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "13JohnsJasper.jpg",
    "distractorTwo": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 285293
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "pasteral",
    "row": 350,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13ballad-of-epona-1900.jpg!Large.jpg",
    "time_elapsed": 294710
  },
  {
    "target_image": "13moscow-i-1916.jpg!Large.jpg",
    "responses": "messy,",
    "row": 351,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 309743
  },
  {
    "target_image": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "responses": "bloody",
    "row": 352,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13the-row.jpg!Large.jpg",
    "distractorThree": "13Mondrian3.jpg",
    "time_elapsed": 323168
  },
  {
    "target_image": "13the-dream-1910.jpg!Large.jpg",
    "responses": "plants",
    "row": 353,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "13Kline2.jpg",
    "distractorTwo": "13Kline1.jpg",
    "distractorThree": "13dd101419.jpg!Large.jpg",
    "time_elapsed": 351283
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "light",
    "row": 354,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorTwo": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 364332
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "dull",
    "row": 355,
    "subject_id": "5e9b60ab511e7a0650994050",
    "distractorOne": "13the-day-dream-1880.jpg!Large.jpg",
    "distractorTwo": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 381798
  },
  {
    "target_image": "13Mucha.jpg",
    "responses": "warm",
    "row": 316,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13gladiators-1940.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 292351
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "realistic",
    "row": 317,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "13Mondrian3.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13ManRay.jpg",
    "time_elapsed": 311838
  },
  {
    "target_image": "13machine-man-with-spiral-turn-1930.jpg",
    "responses": "blocked, dull",
    "row": 318,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13Pollock1.jpg",
    "time_elapsed": 321647
  },
  {
    "target_image": "13Pollock2.jpg",
    "responses": "shaded",
    "row": 319,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "13the-row.jpg!Large.jpg",
    "distractorTwo": "13Kline1.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 332837
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "the flowers are the focus",
    "row": 320,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "13girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 359535
  },
  {
    "target_image": "13Cezanne.jpg",
    "responses": "warm",
    "row": 321,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 367037
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "great use of shades",
    "row": 322,
    "subject_id": "5a5f8c02acc75b00017ab214",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 382595
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "psychedelic, colourful, melancholic",
    "row": 283,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "13girl-s-head-in-a-shawl.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 1069028
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "dark, blurry, sad",
    "row": 284,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 1095458
  },
  {
    "target_image": "13Ingleside.jpg",
    "responses": "bright, hopeful",
    "row": 285,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorThree": "13porch-ii-1947.jpg",
    "time_elapsed": 1139962
  },
  {
    "target_image": "13Klee1.jpg",
    "responses": "blurry, submerging, tranquil",
    "row": 286,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 1189811
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "distorted, intimidating",
    "row": 287,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13Kline1.jpg",
    "distractorThree": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "time_elapsed": 1233716
  },
  {
    "target_image": "13les-musiciens-1952.jpg",
    "responses": "colourful, bright, burning",
    "row": 288,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 1278619
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "blurry, distorted, colourful",
    "row": 289,
    "subject_id": "5f3c5d4c9168ccad270ddb36",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "time_elapsed": 1337778
  },
  {
    "target_image": "13Marquet.jpg",
    "responses": "abstract, modernism, colourful, sick",
    "row": 250,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13madonna-casini.jpg",
    "distractorThree": "13the-day-dream-1880.jpg!Large.jpg",
    "time_elapsed": 699810
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "discoloration, sick, blury",
    "row": 251,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13Rozanova2.jpg",
    "distractorThree": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "time_elapsed": 724652
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "cool, sad, dark",
    "row": 252,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13Cezanne.jpg",
    "distractorThree": "13Ingleside.jpg",
    "time_elapsed": 758743
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "blurred, noise, colorful",
    "row": 253,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "13JeanDupas.jpg",
    "distractorTwo": "13Rothko2.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 768237
  },
  {
    "target_image": "13Matisse.jpg",
    "responses": "feeling sick, chaotic, jelly beans, modernism",
    "row": 254,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13girl-s-head-in-a-shawl.jpg",
    "distractorThree": "13Klee1.jpg",
    "time_elapsed": 790154
  },
  {
    "target_image": "13dd101419.jpg!Large.jpg",
    "responses": "dark, sad, night",
    "row": 255,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "13EdgarDegas.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13MaxErnst.jpg",
    "time_elapsed": 808898
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "cubism, abstractism, colorful",
    "row": 256,
    "subject_id": "5f7627b46c029a08e8ca87a1",
    "distractorOne": "13Mondrian3.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13Rothko.jpg",
    "time_elapsed": 823478
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "animated colours, blurred, abstract",
    "row": 217,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "13dd101419.jpg!Large.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "time_elapsed": 856895
  },
  {
    "target_image": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "responses": "hazy, warm and sunny, calm and quiet",
    "row": 218,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "13les-musiciens-1952.jpg",
    "distractorTwo": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "distractorThree": "13Cezanne.jpg",
    "time_elapsed": 885803
  },
  {
    "target_image": "13porch-ii-1947.jpg",
    "responses": "blurred, warm palette, still",
    "row": 219,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "13Remebrandt.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13Richter.jpg",
    "time_elapsed": 926849
  },
  {
    "target_image": "13Moholy.jpg",
    "responses": "across between warm and cool, abstract feeling, everything merged into one",
    "row": 220,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13Mucha.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 967063
  },
  {
    "target_image": "13Pollock1.jpg",
    "responses": "gloomy, still, grey colours, not uplifting to the spirit",
    "row": 221,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "13Burliuk.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13the-row.jpg!Large.jpg",
    "time_elapsed": 1030804
  },
  {
    "target_image": "13the-memory-of-the-golden-apse-2009.jpg",
    "responses": "dark colours, negative, not sharp",
    "row": 222,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "13portrait-of-daughter-1912.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13Ingleside.jpg",
    "time_elapsed": 1132398
  },
  {
    "target_image": "13Mondrian3.jpg",
    "responses": "warm palette, peaceful hazy day",
    "row": 223,
    "subject_id": "5e889f1ee6a72c0009e4e69b",
    "distractorOne": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13RobertCampin.jpg",
    "time_elapsed": 1159325
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "dashing, racing, dynamic",
    "row": 184,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 731650
  },
  {
    "target_image": "13city-of-churches-1918(1).jpg!Large.jpg",
    "responses": "lifeless, dank, death",
    "row": 185,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "13Pollock2.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13the-snow-maiden.jpg!Large.jpg",
    "time_elapsed": 756717
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "pastel, soft, gentle",
    "row": 186,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "13kateryna-1951.jpg!Large.jpg",
    "distractorTwo": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 797650
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "sunshine, morning, birdsong, hope",
    "row": 187,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "13early-moonrise-florida-1893.jpg!Large.jpg",
    "distractorTwo": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorThree": "13moscow-i-1916.jpg!Large.jpg",
    "time_elapsed": 820266
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "bold, bright, confrontational",
    "row": 188,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13Mondrian3.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 834840
  },
  {
    "target_image": "13Rothko2.jpg",
    "responses": "exciting, dynamic, contrasting",
    "row": 189,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "13the-annunciation-from-altar-of-philip-the-bold-1399.jpg!Large.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13Mucha.jpg",
    "time_elapsed": 864175
  },
  {
    "target_image": "13madonna-casini.jpg",
    "responses": "faded, old, soft",
    "row": 190,
    "subject_id": "5e332dec41d1cd30b905bdfe",
    "distractorOne": "13Chirico.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13girl-s-head-in-a-shawl.jpg",
    "time_elapsed": 895815
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "calm, simple, quiet",
    "row": 151,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "distractorTwo": "13ManRay.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 361922
  },
  {
    "target_image": "13still-life.jpg",
    "responses": "fiery",
    "row": 152,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "13Kline1.jpg",
    "distractorTwo": "13MaxErnst.jpg",
    "distractorThree": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "time_elapsed": 420152
  },
  {
    "target_image": "13Picasso.jpg",
    "responses": "alone, autumn",
    "row": 153,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "13Ingleside.jpg",
    "distractorTwo": "13disks-of-newton-study-for-fugue-in-two-colors.jpg!PinterestSmall.jpg",
    "distractorThree": "13mary-magdalene.jpg!Large.jpg",
    "time_elapsed": 461774
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "spring, flowery, pretty",
    "row": 154,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "time_elapsed": 487024
  },
  {
    "target_image": "13girl-s-head-in-a-shawl.jpg",
    "responses": "hazy, epastel",
    "row": 155,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "13porch-ii-1947.jpg",
    "distractorTwo": "13Chirico.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 518882
  },
  {
    "target_image": "13kateryna-1951.jpg!Large.jpg",
    "responses": "country, soft, floating",
    "row": 156,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "13grablegung.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 563850
  },
  {
    "target_image": "13pissaro.jpg",
    "responses": "shadows, fuzzy,",
    "row": 157,
    "subject_id": "5e9f568ed526b20e76977cad",
    "distractorOne": "13Cezanne.jpg",
    "distractorTwo": "13portrait-of-a-lady-with-a-book-1888.jpg!Large.jpg",
    "distractorThree": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "time_elapsed": 588262
  },
  {
    "target_image": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "responses": "calm",
    "row": 118,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "13Klee2.jpg",
    "distractorTwo": "13the-liver-is-the-cock-s-comb.jpg",
    "distractorThree": "13Rodchenko1.jpg",
    "time_elapsed": 197617
  },
  {
    "target_image": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "responses": "colourful",
    "row": 119,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "13Rothko.jpg",
    "distractorTwo": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "13JeanDupas.jpg",
    "time_elapsed": 205369
  },
  {
    "target_image": "13JohnsJasper.jpg",
    "responses": "chill",
    "row": 120,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "13the-snow-maiden.jpg!Large.jpg",
    "distractorTwo": "13grablegung.jpg",
    "distractorThree": "13the-memory-of-the-golden-apse-2009.jpg",
    "time_elapsed": 210897
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "sandy",
    "row": 121,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "13MaxErnst.jpg",
    "distractorTwo": "13still-life.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 216057
  },
  {
    "target_image": "13Chirico.jpg",
    "responses": "blurry",
    "row": 122,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "13ManRay.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13Matisse.jpg",
    "time_elapsed": 222105
  },
  {
    "target_image": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "responses": "watery",
    "row": 123,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "13the-dream-1910.jpg!Large.jpg",
    "distractorTwo": "13les-musiciens-1952.jpg",
    "distractorThree": "13portrait-of-daughter-1912.jpg",
    "time_elapsed": 246657
  },
  {
    "target_image": "13the-day-dream-1880.jpg!Large.jpg",
    "responses": "naturalistic",
    "row": 124,
    "subject_id": "599c1da9a954a50001ef1cb7",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13pissaro.jpg",
    "distractorThree": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "time_elapsed": 254593
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "textured, warm, cool",
    "row": 85,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "13gladiators-1940.jpg",
    "distractorTwo": "13kateryna-1951.jpg!Large.jpg",
    "distractorThree": "13the-cast-off-doll-1921.jpg!Large.jpg",
    "time_elapsed": 193174
  },
  {
    "target_image": "13Kline2.jpg",
    "responses": "soft, blurred, warm",
    "row": 86,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "13Mucha.jpg",
    "distractorTwo": "13dd101419.jpg!Large.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 211035
  },
  {
    "target_image": "13Rozanova2.jpg",
    "responses": "swirly, light, cool",
    "row": 87,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "13the-memory-of-the-golden-apse-2009.jpg",
    "distractorTwo": "13mrs-chase-in-prospect-park.jpg!Large.jpg",
    "distractorThree": "13Kline1.jpg",
    "time_elapsed": 219925
  },
  {
    "target_image": "13Klimt1.jpg",
    "responses": "harsh, bright, overexposed",
    "row": 88,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "distractorTwo": "13Picasso.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 233913
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "mixed, strange, blurred",
    "row": 89,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13Marquet.jpg",
    "distractorThree": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "time_elapsed": 250878
  },
  {
    "target_image": "13Rauschenberg.jpg",
    "responses": "blurred, lines, light, pastel, cool",
    "row": 90,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "13Richter2.jpg",
    "distractorTwo": "13Klee2.jpg",
    "distractorThree": "13destroyed-place-1920(1).jpg!Large.jpg",
    "time_elapsed": 263098
  },
  {
    "target_image": "13Richter.jpg",
    "responses": "dark, difficult to see, cool",
    "row": 91,
    "subject_id": "5d8caf1a8aa1580017e4ece3",
    "distractorOne": "13Mondrian.jpg",
    "distractorTwo": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 284041
  },
  {
    "target_image": "13mary-magdalene.jpg!Large.jpg",
    "responses": "soft, cool, clear",
    "row": 52,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "13self-portrait-with-brushes-1942.jpg",
    "distractorTwo": "13Moholy.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 279048
  },
  {
    "target_image": "13Nay.jpg",
    "responses": "sharp, constrat, bright",
    "row": 53,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "13city-of-churches-1918(1).jpg!Large.jpg",
    "distractorTwo": "13RobertCampin.jpg",
    "distractorThree": "13les-musiciens-1952.jpg",
    "time_elapsed": 306787
  },
  {
    "target_image": "13JeanDupas.jpg",
    "responses": "cool,  pastel",
    "row": 54,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorTwo": "13the-snow-maiden.jpg!Large.jpg",
    "distractorThree": "13Remebrandt.jpg",
    "time_elapsed": 327420
  },
  {
    "target_image": "13lilacs-in-a-purse-on-the-floor-1955.jpg!Large.jpg",
    "responses": "blurred, dull, distant",
    "row": 55,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "13Richter.jpg",
    "distractorTwo": "13Rothko.jpg",
    "distractorThree": "13the-virgin-and-child-enthroned-with-saints-jerome-and-francis-1458.jpg!Large.jpg",
    "time_elapsed": 334538
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "creative, cool, soft",
    "row": 56,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "13reclining-nude-on-a-blue-cushion-red-nude.jpg!Large.jpg",
    "distractorTwo": "13Burliuk.jpg",
    "distractorThree": "13Richter2.jpg",
    "time_elapsed": 342759
  },
  {
    "target_image": "13the-liver-is-the-cock-s-comb.jpg",
    "responses": "blurred, dull,",
    "row": 57,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "13machine-man-with-spiral-turn-1930.jpg",
    "distractorTwo": "13Rodchenko1.jpg",
    "distractorThree": "13Picasso.jpg",
    "time_elapsed": 354765
  },
  {
    "target_image": "13Klee2.jpg",
    "responses": "blurred, harsh,",
    "row": 58,
    "subject_id": "5b2bb00bfc75870001983add",
    "distractorOne": "13Rozanova2.jpg",
    "distractorTwo": "13moscow-i-1916.jpg!Large.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 367412
  },
  {
    "target_image": "13the-row.jpg!Large.jpg",
    "responses": "cool, blurred",
    "row": 19,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "13still-life.jpg",
    "distractorTwo": "13ballad-of-epona-1900.jpg!Large.jpg",
    "distractorThree": "13Rothko2.jpg",
    "time_elapsed": 335553
  },
  {
    "target_image": "13portrait-of-daughter-1912.jpg",
    "responses": "neon, psycadelic, funky, bright",
    "row": 20,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "13moscow-i-1916.jpg!Large.jpg",
    "distractorTwo": "13Richter.jpg",
    "distractorThree": "13portrait-of-miss-scobell-in-a-bathchair-the-convalescent.jpg",
    "time_elapsed": 347839
  },
  {
    "target_image": "13self-portrait-with-brushes-1942.jpg",
    "responses": "pastel,",
    "row": 21,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "13Moholy.jpg",
    "distractorTwo": "13Rauschenberg.jpg",
    "distractorThree": "13the-liver-is-the-cock-s-comb.jpg",
    "time_elapsed": 362035
  },
  {
    "target_image": "13Klee2.jpg",
    "responses": "hazy, warm, simple",
    "row": 22,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "13hoffmann.jpg",
    "distractorTwo": "13JohnsJasper.jpg",
    "distractorThree": "13gladiators-1940.jpg",
    "time_elapsed": 375090
  },
  {
    "target_image": "13oberstdorf-mountains-1912.jpg!Large.jpg",
    "responses": "cool, water, flowing",
    "row": 23,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "13madonna-casini.jpg",
    "distractorTwo": "13samuel-palmera-hilly-scene-1828.jpg!Large.jpg",
    "distractorThree": "13einek-nstlergemeinschaft.jpg!Large.jpg",
    "time_elapsed": 390017
  },
  {
    "target_image": "13d-apr-s-el-greco-1965(1).jpg!Large.jpg",
    "responses": "neutral, dull",
    "row": 24,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "13portrait-of-miss-dora-wheeler-1.jpg!Large.jpg",
    "distractorTwo": "13porch-ii-1947.jpg",
    "distractorThree": "13Chirico.jpg",
    "time_elapsed": 400474
  },
  {
    "target_image": "13Burliuk.jpg",
    "responses": "havoc, cool",
    "row": 25,
    "subject_id": "5f50e3d60305bb088998b766",
    "distractorOne": "13the-pink-candle-1910.jpg!Large.jpg",
    "distractorTwo": "13Nay.jpg",
    "distractorThree": "13pissaro.jpg",
    "time_elapsed": 419572
  }
]